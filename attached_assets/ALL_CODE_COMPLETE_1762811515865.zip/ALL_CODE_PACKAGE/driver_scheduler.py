#!/usr/bin/env python3.11
"""
AUTOMATED DRIVER SCHEDULING SYSTEM
Weekly block assignment with CSP solver and pattern analysis

Created for: Weekly Friday scheduling workflow
Date: Nov 2025
"""

import pandas as pd
import json
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Dict, List, Tuple, Optional

class DriverScheduler:
    """Main scheduling system with CSP solver"""
    
    def __init__(self):
        self.blocks = None
        self.drivers_last_week = {}
        self.constraints = {
            'call_offs': {},
            'time_off': {},
            'availability_changes': {},
            'must_have': {},
            'only': {},
            'preferences': {},
            'new_drivers': []
        }
        self.assignments = {}
        self.low_confidence = []
        
    def load_blocks(self, csv_path: str, start_date: str, end_date: str):
        """
        Load and validate blocks from Amazon CSV
        
        Args:
            csv_path: Path to Amazon block CSV file
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
        """
        print("="*80)
        print("STEP 1: LOADING BLOCKS FROM CSV")
        print("="*80)
        
        # Read CSV
        df = pd.read_csv(csv_path)
        
        # Filter for Block type only
        blocks = df[df['Block/Trip'] == 'Block'].copy()
        
        # Parse start datetime
        blocks['start_datetime'] = pd.to_datetime(
            blocks['Stop 1 Planned Arrival Date'].astype(str) + ' ' + 
            blocks['Stop 1 Planned Arrival Time'].astype(str),
            format='%m/%d/%Y %H:%M',
            errors='coerce'
        )
        
        # Filter for date range
        blocks = blocks[
            (blocks['start_datetime'] >= start_date) & 
            (blocks['start_datetime'] < end_date)
        ]
        
        # Extract key attributes
        blocks['start_day'] = blocks['start_datetime'].dt.strftime('%a')
        blocks['start_time'] = blocks['start_datetime'].dt.strftime('%H:%M')
        blocks['solo_type'] = blocks['Operator ID'].apply(
            lambda x: 'Solo2' if 'Solo2' in str(x) else 'Solo1' if 'Solo1' in str(x) else 'Unknown'
        )
        
        # Sort chronologically
        blocks = blocks.sort_values('start_datetime')
        
        self.blocks = blocks
        
        # Print summary
        total = len(blocks)
        assigned = blocks['Driver Name'].notna().sum()
        unassigned = blocks['Driver Name'].isna().sum()
        
        print(f"\n📊 BLOCKS LOADED:")
        print(f"   Total: {total}")
        print(f"   Already assigned: {assigned}")
        print(f"   Unassigned: {unassigned}")
        
        # Breakdown by day
        print(f"\n📅 BY DAY:")
        for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']:
            count = len(blocks[blocks['start_day'] == day])
            if count > 0:
                print(f"   {day}: {count} blocks")
        
        # Breakdown by type
        print(f"\n🚛 BY TYPE:")
        for solo_type in ['Solo1', 'Solo2']:
            count = len(blocks[blocks['solo_type'] == solo_type])
            if count > 0:
                print(f"   {solo_type}: {count} blocks")
        
        print("\n" + "="*80)
        return unassigned
    
    def load_last_week_patterns(self, last_week_csv: str):
        """
        Load last week's assignments for pattern analysis
        
        Args:
            last_week_csv: Path to last week's assignment CSV
        """
        print("\nSTEP 2: LOADING LAST WEEK'S PATTERNS")
        print("="*80)
        
        try:
            df = pd.read_csv(last_week_csv)
            
            # Parse datetime
            df['start_datetime'] = pd.to_datetime(df['start_datetime'])
            df['start_day'] = df['start_datetime'].dt.strftime('%a')
            df['start_time'] = df['start_datetime'].dt.strftime('%H:%M')
            
            # Group by driver
            for driver in df['assigned_driver'].unique():
                driver_blocks = df[df['assigned_driver'] == driver]
                self.drivers_last_week[driver] = driver_blocks[
                    ['start_day', 'start_time', 'solo_type']
                ].to_dict('records')
            
            print(f"✅ Loaded patterns for {len(self.drivers_last_week)} drivers")
            print(f"✅ Total blocks from last week: {len(df)}")
            
        except FileNotFoundError:
            print("⚠️  No last week data found - will use constraints only")
        
        print("="*80)
    
    def parse_constraints(self, constraints_text: str):
        """
        Parse special requests from user input
        
        Args:
            constraints_text: Multi-line text with constraints
        """
        print("\nSTEP 3: PARSING SPECIAL REQUESTS")
        print("="*80)
        
        current_section = None
        
        for line in constraints_text.strip().split('\n'):
            line = line.strip()
            
            if not line or line == 'NONE':
                continue
            
            # Section headers
            if 'CALL-OFFS:' in line:
                current_section = 'call_offs'
            elif 'TIME-OFF REQUESTS:' in line:
                current_section = 'time_off'
            elif 'AVAILABILITY CHANGES:' in line:
                current_section = 'availability_changes'
            elif 'MUST-HAVE ASSIGNMENTS:' in line:
                current_section = 'must_have'
            elif 'DRIVER PREFERENCES:' in line:
                current_section = 'preferences'
            elif 'NEW DRIVERS:' in line:
                current_section = 'new_drivers'
            elif line.startswith('-') and current_section:
                # Parse constraint line
                line = line[1:].strip()
                
                if ':' in line:
                    parts = line.split(':', 1)
                    driver = parts[0].strip()
                    details = parts[1].strip()
                    
                    if current_section == 'new_drivers':
                        self.constraints['new_drivers'].append({
                            'driver': driver,
                            'details': details
                        })
                    else:
                        self.constraints[current_section][driver] = details
        
        # Print summary
        print(f"\n📋 CONSTRAINTS PARSED:")
        for key, value in self.constraints.items():
            if value:
                count = len(value) if isinstance(value, (list, dict)) else 1
                print(f"   {key.replace('_', ' ').title()}: {count}")
        
        print("="*80)
    
    def calculate_pattern_score(self, driver: str, block: dict) -> int:
        """
        Calculate pattern match score (0-100)
        
        Args:
            driver: Driver name
            block: Block dictionary with start_day, start_time, solo_type
        
        Returns:
            Score from 0-100
        """
        if driver not in self.drivers_last_week:
            return 0  # No historical data
        
        score = 0
        last_week_blocks = self.drivers_last_week[driver]
        
        for last_block in last_week_blocks:
            # Same START DAY
            if last_block['start_day'] == block['start_day']:
                score += 30
            
            # Same START TIME
            if last_block['start_time'] == block['start_time']:
                score += 40
            
            # Same SOLO TYPE
            if last_block['solo_type'] == block['solo_type']:
                score += 20
            
            # BONUS: Exact match
            if (last_block['start_day'] == block['start_day'] and
                last_block['start_time'] == block['start_time'] and
                last_block['solo_type'] == block['solo_type']):
                score += 10
        
        return min(score, 100)
    
    def check_hard_constraints(self, driver: str, block: dict) -> Tuple[bool, str]:
        """
        Check if driver satisfies all hard constraints for this block
        
        Returns:
            (is_valid, reason)
        """
        # Check call-offs
        if driver in self.constraints['call_offs']:
            return False, f"On call-off: {self.constraints['call_offs'][driver]}"
        
        # Check time-off requests
        if driver in self.constraints['time_off']:
            time_off = self.constraints['time_off'][driver]
            if block['start_day'] in time_off:
                return False, f"Time-off request: {time_off}"
        
        # Check availability changes (e.g., "Starts Thu Nov 13")
        if driver in self.constraints.get('availability_changes', {}):
            avail = self.constraints['availability_changes'][driver]
            if 'Starts Thu' in avail or 'starts Thu' in avail:
                # Driver can only work Thu/Fri/Sat
                if block['start_day'] not in ['Thu', 'Fri', 'Sat']:
                    return False, f"Availability: {avail}"
            if 'Must end by Wed' in avail:
                # Driver can only work Sun/Mon/Tue/Wed
                if block['start_day'] not in ['Sun', 'Mon', 'Tue', 'Wed']:
                    return False, f"Availability: {avail}"
        
        # Check "ONLY" restrictions in must_have (hard constraint)
        if driver in self.constraints.get('must_have', {}):
            must_have = self.constraints['must_have'][driver]
            if 'ONLY' in must_have:
                if not self._matches_must_have(block, must_have):
                    return False, f"ONLY restriction: {must_have}"
        
        # Check "ONLY" restrictions in preferences (treat as hard for ONLY keyword)
        if driver in self.constraints.get('preferences', {}):
            pref = self.constraints['preferences'][driver]
            if 'ONLY' in pref:
                if not self._matches_preference(block, pref):
                    return False, f"ONLY restriction: {pref}"
        
        return True, ""
    
    def _matches_only_restriction(self, block: dict, restriction: str) -> bool:
        """Check if block matches ONLY restriction"""
        # Simple parser for "ONLY Sat @ 20:30" format
        if '@' in restriction:
            parts = restriction.replace('ONLY', '').strip().split('@')
            req_day = parts[0].strip()
            req_time = parts[1].strip() if len(parts) > 1 else None
            
            if req_day and block['start_day'] not in req_day:
                return False
            if req_time and block['start_time'] != req_time:
                return False
        
        return True
    
    def calculate_total_score(self, driver: str, block: dict, current_assignments: dict, assigned_drivers_count: dict) -> int:
        """
        Calculate total CSP score for driver-block pairing
        
        Returns:
            Score from 0-100
        """
        # Pattern match (35%)
        pattern_score = self.calculate_pattern_score(driver, block) * 0.35
        
        # Load balance (25%) - Heavily penalize overloaded drivers
        driver_block_count = assigned_drivers_count.get(driver, 0)
        avg_blocks = 3  # Typical average
        
        if driver_block_count == 0:
            load_score = 100  # Prefer unassigned drivers
        elif driver_block_count < avg_blocks:
            load_score = 90
        elif driver_block_count == avg_blocks:
            load_score = 60
        elif driver_block_count == avg_blocks + 1:
            load_score = 30
        else:
            load_score = max(0, 10 - (driver_block_count - avg_blocks) * 10)
        
        load_score *= 0.25
        
        # Preference match (20%)
        pref_score = 50  # Default neutral
        if driver in self.constraints.get('must_have', {}):
            must_have = self.constraints['must_have'][driver]
            if self._matches_must_have(block, must_have):
                pref_score = 100
        elif driver in self.constraints.get('preferences', {}):
            pref = self.constraints['preferences'][driver]
            if self._matches_preference(block, pref):
                pref_score = 70
        pref_score *= 0.20
        
        # HOS quality (10%) - Assume blocks have built-in 10+ hour rest
        hos_score = 80 * 0.10
        
        # Consistency (10%)
        consistency_score = 50
        if driver in self.drivers_last_week:
            # Bonus for working same block type
            consistency_score = 70
        consistency_score *= 0.10
        
        return int(pattern_score + load_score + pref_score + hos_score + consistency_score)
    
    def _matches_must_have(self, block: dict, must_have: str) -> bool:
        """Check if block matches MUST-HAVE assignment"""
        # Handle "ONLY Sat @ 18:30" format
        if 'ONLY' in must_have:
            must_have_clean = must_have.replace('ONLY', '').strip()
            
            # Parse "Sat @ 18:30" or "Sun Nov 9 OR Sat Nov 15"
            if '@' in must_have_clean:
                parts = must_have_clean.split('@')
                req_day = parts[0].strip()
                req_time = parts[1].strip() if len(parts) > 1 else None
                
                day_match = req_day in block['start_day'] or block['start_day'] in req_day
                time_match = req_time is None or block['start_time'] == req_time
                
                return day_match and time_match
            elif 'OR' in must_have_clean:
                # Handle "Sun Nov 9 OR Sat Nov 15"
                options = must_have_clean.split('OR')
                for option in options:
                    if block['start_day'] in option.strip():
                        return True
                return False
        
        # Handle "Sun-Wed + Sat @ 20:30" format
        if '@' in must_have:
            parts = must_have.split('@')
            days_part = parts[0].strip()
            time_part = parts[1].strip() if len(parts) > 1 else None
            
            # Check if block day is in the days part
            day_match = block['start_day'] in days_part
            time_match = time_part is None or block['start_time'] == time_part
            
            return day_match and time_match
        
        # Fallback: simple substring match
        if block['start_day'] in must_have and block['start_time'] in must_have:
            return True
        return False
    
    def _matches_preference(self, block: dict, preference: str) -> bool:
        """Check if block matches preference"""
        # Handle "ONLY" restrictions
        if 'ONLY' in preference:
            pref_clean = preference.replace('ONLY', '').strip()
            
            # Parse "Sat/Sun/Mon @ 16:30 ONLY"
            if '@' in pref_clean:
                parts = pref_clean.split('@')
                days_part = parts[0].strip()
                time_part = parts[1].strip() if len(parts) > 1 else None
                
                # Check if block day is in allowed days
                day_match = any(day in days_part for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] if day == block['start_day'])
                time_match = time_part is None or block['start_time'] == time_part
                
                return day_match and time_match
            elif '/' in pref_clean:
                # Handle "Sat/Sun/Mon @ 16:30"
                allowed_days = [d.strip() for d in pref_clean.split('/')]
                return block['start_day'] in allowed_days
        
        # Handle "Tue-Sat @ 16:30" format
        if '@' in preference:
            parts = preference.split('@')
            days_part = parts[0].strip()
            time_part = parts[1].strip() if len(parts) > 1 else None
            
            day_match = block['start_day'] in days_part
            time_match = time_part is None or block['start_time'] == time_part
            
            return day_match and time_match
        
        # Handle time ranges like "16:30 OR 17:30 OR 18:30"
        if 'OR' in preference:
            times = [t.strip() for t in preference.split('OR')]
            return block['start_time'] in times
        
        # Fallback
        if block['start_day'] in preference or block['start_time'] in preference:
            return True
        return False
    
    def assign_drivers(self):
        """
        Main CSP solver - assign drivers to all unassigned blocks
        """
        print("\nSTEP 4: ASSIGNING DRIVERS (CSP SOLVER)")
        print("="*80)
        
        # Get unassigned blocks
        unassigned = self.blocks[self.blocks['Driver Name'].isna()].copy()
        
        # Get all available drivers
        all_drivers = set(self.drivers_last_week.keys())
        all_drivers.update(d['driver'] for d in self.constraints.get('new_drivers', []))
        
        # PHASE 1: Assign must-have drivers first
        print("\n📌 PHASE 1: Assigning MUST-HAVE drivers...")
        must_have_assigned = 0
        
        for driver, must_have_spec in self.constraints.get('must_have', {}).items():
            print(f"   Processing {driver}: {must_have_spec}")
            
            # Find matching blocks
            for idx, block_row in unassigned.iterrows():
                if block_row['Block ID'] in self.assignments:
                    continue  # Already assigned
                
                block = {
                    'block_id': block_row['Block ID'],
                    'start_day': block_row['start_day'],
                    'start_time': block_row['start_time'],
                    'solo_type': block_row['solo_type']
                }
                
                # Check if block matches must-have spec
                if self._matches_must_have(block, must_have_spec):
                    # Check hard constraints
                    is_valid, reason = self.check_hard_constraints(driver, block)
                    if is_valid:
                        # Check if driver already has a block on this day
                        driver_days = set()
                        for assigned_block_id, assigned_driver in self.assignments.items():
                            if assigned_driver == driver:
                                assigned_block_info = self.blocks[self.blocks['Block ID'] == assigned_block_id].iloc[0]
                                driver_days.add(assigned_block_info['start_day'])
                        
                        if block['start_day'] not in driver_days:
                            self.assignments[block['block_id']] = driver
                            must_have_assigned += 1
                            print(f"      ✅ Assigned {block['start_day']} {block['start_time']} - {block['solo_type']}")
        
        print(f"\n   ✅ Must-have assignments: {must_have_assigned}")
        print("\n📊 PHASE 2: Running CSP solver for remaining blocks...")
        
        # Calculate scores for all valid pairings
        valid_pairings = []
        
        for idx, block_row in unassigned.iterrows():
            block = {
                'block_id': block_row['Block ID'],
                'start_day': block_row['start_day'],
                'start_time': block_row['start_time'],
                'solo_type': block_row['solo_type']
            }
            
            for driver in all_drivers:
                # Check hard constraints
                is_valid, reason = self.check_hard_constraints(driver, block)
                
                if is_valid:
                    score = self.calculate_total_score(driver, block, self.assignments, {})
                    valid_pairings.append((block['block_id'], driver, score))
        
        # Sort by score (highest first)
        valid_pairings.sort(key=lambda x: x[2], reverse=True)
        
        # Iterative assignment with dynamic scoring
        assigned_blocks = set()
        assigned_drivers_count = defaultdict(int)
        max_blocks_per_driver = 6  # Maximum blocks per driver
        
        # Track driver-day assignments to prevent multiple blocks per day
        driver_days_worked = defaultdict(set)  # driver -> set of days
        
        # Initialize tracking with Phase 1 assignments
        for block_id, driver in self.assignments.items():
            assigned_blocks.add(block_id)
            assigned_drivers_count[driver] += 1
            block_info = self.blocks[self.blocks['Block ID'] == block_id].iloc[0]
            driver_days_worked[driver].add(block_info['start_day'])
        
        # Recalculate scores dynamically as we assign
        while len(assigned_blocks) < len(unassigned):
            best_pairing = None
            best_score = -1
            
            for idx, block_row in unassigned.iterrows():
                block_id = block_row['Block ID']
                
                # Skip blocks already assigned in Phase 1
                if block_id in self.assignments or block_id in assigned_blocks:
                    continue
                
                block = {
                    'block_id': block_id,
                    'start_day': block_row['start_day'],
                    'start_time': block_row['start_time'],
                    'solo_type': block_row['solo_type']
                }
                
                for driver in all_drivers:
                    if assigned_drivers_count[driver] >= max_blocks_per_driver:
                        continue
                    
                    # Check if driver already has a block on this day
                    if block['start_day'] in driver_days_worked[driver]:
                        continue  # Driver already working on this day
                    
                    is_valid, reason = self.check_hard_constraints(driver, block)
                    if not is_valid:
                        continue
                    
                    score = self.calculate_total_score(driver, block, self.assignments, assigned_drivers_count)
                    
                    if score > best_score:
                        best_score = score
                        best_pairing = (block_id, driver, score, block)
            
            if best_pairing:
                block_id, driver, score, block = best_pairing
                self.assignments[block_id] = driver
                assigned_blocks.add(block_id)
                assigned_drivers_count[driver] += 1
                
                # Track this day for the driver
                driver_days_worked[driver].add(block['start_day'])
                
                if score < 60:
                    self.low_confidence.append((block_id, driver, score))
            else:
                # No valid pairing found
                break
        
        print(f"\n✅ ASSIGNED: {len(self.assignments)} blocks")
        print(f"⚠️  LOW CONFIDENCE: {len(self.low_confidence)} blocks")
        print("="*80)
    
    def generate_summary_report(self):
        """Generate pre-approval summary with conflict detection"""
        print("\n" + "="*80)
        print("📋 PRE-APPROVAL SUMMARY")
        print("="*80)
        
        # Store blocks_df for later use
        self.blocks_df = self.blocks
        
        # Organize by driver
        driver_schedules = defaultdict(list)
        for block_id, driver in self.assignments.items():
            block_info = self.blocks[self.blocks['Block ID'] == block_id].iloc[0]
            driver_schedules[driver].append({
                'block_id': block_id,
                'day': block_info['start_day'],
                'time': block_info['start_time'],
                'solo': block_info['solo_type']
            })
        
        # Sort each driver's schedule by day and time
        day_order = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
        for driver in driver_schedules:
            driver_schedules[driver].sort(key=lambda x: (day_order.index(x['day']), x['time']))
        
        # Check for conflicts (same driver, same time)
        conflicts = []
        for driver, schedule in driver_schedules.items():
            time_slots = set()
            for block in schedule:
                time_slot = (block['day'], block['time'])
                if time_slot in time_slots:
                    conflicts.append(f"❌ {driver}: Multiple blocks at {block['day']} {block['time']}")
                time_slots.add(time_slot)
        
        if conflicts:
            print("\n🚨 CONFLICTS DETECTED:")
            for conflict in conflicts:
                print(f"  {conflict}")
            print("\n⚠️  SCHEDULE HAS ERRORS - DO NOT APPROVE")
            return False
        
        print("\n✅ NO CONFLICTS DETECTED")
        
        # Show driver distribution
        print("\n👥 DRIVER WORKLOAD:")
        block_counts = defaultdict(int)
        for driver in driver_schedules:
            count = len(driver_schedules[driver])
            block_counts[count] += 1
        
        for count in sorted(block_counts.keys(), reverse=True):
            print(f"  {count} blocks: {block_counts[count]} drivers")
        
        # Show sample schedules
        print("\n📅 SAMPLE DRIVER SCHEDULES (first 5):")
        for i, (driver, schedule) in enumerate(sorted(driver_schedules.items())[:5]):
            print(f"\n  {driver} ({len(schedule)} blocks):")
            for block in schedule:
                print(f"    {block['day']} {block['time']} - {block['solo']} - {block['block_id']}")
        
        # Check must-haves and preferences
        if self.constraints.get('must_have') or self.constraints.get('preferences'):
            print("\n✅ SPECIAL REQUESTS STATUS:")
            
            # Must-haves
            for driver, must_have in self.constraints.get('must_have', {}).items():
                driver_blocks = driver_schedules.get(driver, [])
                matched = any((b['day'] in must_have and b['time'] in must_have) for b in driver_blocks)
                status = "✅" if matched else "❌"
                print(f"  {status} {driver}: {must_have}")
            
            # Preferences
            for driver, pref in self.constraints.get('preferences', {}).items():
                driver_blocks = driver_schedules.get(driver, [])
                matched = any((b['day'] in pref or b['time'] in pref) for b in driver_blocks)
                status = "✅" if matched else "⚠️"
                print(f"  {status} {driver}: {pref} (preference)")
        
        print("\n" + "="*80)
        print("👉 Review the summary above")
        print("👉 Type 'APPROVE' to generate final CSV, or describe changes needed")
        print("="*80)
        
        return True
    
    def generate_output(self, output_path: str):
        """
        Generate final output file for manual entry
        
        Args:
            output_path: Path to save output CSV
        """
        print("\nSTEP 5: GENERATING OUTPUT")
        print("="*80)
        
        # Apply assignments to blocks
        self.blocks['assigned_driver'] = self.blocks['Block ID'].map(
            lambda x: self.assignments.get(x, self.blocks[self.blocks['Block ID'] == x]['Driver Name'].iloc[0])
        )
        
        # Create output dataframe
        output = self.blocks[[
            'Block ID', 'start_day', 'start_time', 'solo_type', 'assigned_driver'
        ]].copy()
        
        output.columns = ['Block_ID', 'Day', 'Time', 'Type', 'Driver']
        
        # Save to CSV
        output.to_csv(output_path, index=False)
        
        print(f"✅ Output saved to: {output_path}")
        
        # Print summary
        print(f"\n📊 SUMMARY:")
        print(f"   Total blocks: {len(output)}")
        print(f"   Assigned: {output['Driver'].notna().sum()}")
        print(f"   Unassigned: {output['Driver'].isna().sum()}")
        
        # Driver block counts
        print(f"\n👥 BLOCKS PER DRIVER:")
        driver_counts = output['Driver'].value_counts()
        for driver, count in driver_counts.head(20).items():
            print(f"   {driver}: {count} blocks")
        
        print("="*80)
        
        return output_path

# Main execution function
def run_weekly_scheduling(
    csv_path: str,
    start_date: str,
    end_date: str,
    last_week_csv: Optional[str] = None,
    constraints_text: str = "",
    output_path: str = "/home/ubuntu/final_assignments.csv"
):
    """
    Run the complete weekly scheduling workflow
    
    Args:
        csv_path: Path to Amazon block CSV
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        last_week_csv: Path to last week's assignments (optional)
        constraints_text: Special requests text
        output_path: Where to save final assignments
    
    Returns:
        Path to output file
    """
    scheduler = DriverScheduler()
    
    # Step 1: Load blocks
    unassigned_count = scheduler.load_blocks(csv_path, start_date, end_date)
    
    print(f"\n❓ I found {unassigned_count} unassigned blocks.")
    print("   Does this match your Amazon screen?")
    print("   (Type 'YES' to continue or provide corrections)")
    
    # Step 2: Load last week's patterns
    if last_week_csv:
        scheduler.load_last_week_patterns(last_week_csv)
    
    # Step 3: Parse constraints
    if constraints_text:
        scheduler.parse_constraints(constraints_text)
    
    # Step 4: Assign drivers
    scheduler.assign_drivers()
    
    # Step 5: Generate output
    output_file = scheduler.generate_output(output_path)
    
    return output_file

if __name__ == "__main__":
    print("Driver Scheduler - Ready for use")
    print("Import this module and call run_weekly_scheduling()")
