# Operator ID Patch - Critical Fix for Mixed Data Types

## Problem Statement

**CRITICAL ISSUE**: On Fridays, Amazon's schedule file contains mixed data types:
- **Block-level data** (next week): Closed blocks with generic start times
- **Trip-level data** (current week): Opened blocks showing actual route times

The system was incorrectly using the `start_datetime` column from CSV, which represents different things depending on data type. This caused incorrect time calculations and DOT compliance validation failures.

## Solution

**Parse Operator ID to determine contract times** instead of using CSV `start_datetime` column.

Every row (block-level or trip-level) has an `Operator ID` field that contains the contract information:
- Format: `FTIM_MKC_{Solo1|Solo2}_Tractor_{N}_d{1|2}`
- Example: `FTIM_MKC_Solo1_Tractor_9_d2`

By parsing this field, we can:
1. Extract Solo type (Solo1 or Solo2)
2. Extract Tractor number (Tractor_1 through Tractor_10)
3. Look up the contract in `base_time_contracts.json`
4. Get the correct start time regardless of data type

## What Changed

### New Functions Added to `schedule_utils.py`

#### 1. `parse_operator_id(operator_id)`
Extracts Solo type and Tractor from Operator ID string.

```python
parsed = parse_operator_id("FTIM_MKC_Solo1_Tractor_9_d2")
# Returns: {'solo_type': 'Solo1', 'tractor': 'Tractor_9'}
```

#### 2. `get_contract_from_operator_id(operator_id)`
Looks up contract details from Operator ID.

```python
contract = get_contract_from_operator_id("FTIM_MKC_Solo1_Tractor_9_d2")
# Returns: {
#   'contract_id': 'SOLO1_16:30_T9',
#   'start_time': '16:30',
#   'tractor': 'Tractor_9',
#   'type': 'Solo1',
#   'duration_hours': 14
# }
```

#### 3. `get_block_times_from_operator_id(operator_id, date_str)`
Calculates block start and end times from Operator ID and date.

```python
start, end = get_block_times_from_operator_id(
    "FTIM_MKC_Solo1_Tractor_9_d2",
    "2025-11-09"
)
# Returns: (2025-11-09 16:30:00, 2025-11-10 06:30:00)
```

### Updated Functions

#### `get_block_times(df_row)` - NOW USES OPERATOR ID
The main validation function now:
1. **First tries** to use Operator ID (NEW METHOD)
2. **Falls back** to legacy method if Operator ID not available

This ensures backward compatibility while fixing the Friday data issue.

## How It Works

### Before (INCORRECT)
```
CSV Row → Read start_datetime column → Calculate end time
Problem: start_datetime means different things for block vs trip data
```

### After (CORRECT)
```
CSV Row → Parse Operator ID → Look up contract → Get start time → Calculate end time
Benefit: Works uniformly for both block-level and trip-level data
```

## Usage Examples

### Example 1: Basic Usage
```python
import pandas as pd
from schedule_utils import get_block_times

# Load schedule (works for both block and trip data)
df = pd.read_csv('schedule.csv')

# Process each row
for _, row in df.iterrows():
    start, end = get_block_times(row)
    print(f"{row['Driver Name']}: {start} → {end}")
```

### Example 2: Validation
```python
from schedule_validator import ScheduleValidator

# Validate schedule (now uses Operator ID internally)
validator = ScheduleValidator('last_week.csv', 'this_week.csv')

# Check 34-hour reset
violations = validator.validate_34hour_cross_week()

# Check rolling 6-day pattern
violations = validator.validate_rolling_6day()
```

### Example 3: Direct Contract Lookup
```python
from schedule_utils import get_contract_from_operator_id

# Get contract details
contract = get_contract_from_operator_id("FTIM_MKC_Solo2_Tractor_4_d1")

print(f"Contract: {contract['contract_id']}")
print(f"Start Time: {contract['start_time']}")
print(f"Duration: {contract['duration_hours']} hours")
```

## Testing Results

All tests passed successfully:

### Test 1: Solo1 Parsing
```
Operator ID: FTIM_MKC_Solo1_Tractor_9_d2
Start: 2025-11-09 16:30:00
End: 2025-11-10 06:30:00
Duration: 14.0h ✓
```

### Test 2: Solo2 Parsing
```
Operator ID: FTIM_MKC_Solo2_Tractor_4_d1
Start: 2025-11-09 08:30:00
End: 2025-11-10 22:30:00
Duration: 38.0h ✓
```

### Test 3: Different Date Formats
```
Works with both:
- '2025-11-09' format
- '11/09/2025' format ✓
```

## Key Benefits

1. **Uniform Handling**: Works for both block-level and trip-level data
2. **Accurate Times**: Uses contract times from `base_time_contracts.json`
3. **Backward Compatible**: Falls back to legacy method if Operator ID not available
4. **DOT Compliant**: Ensures correct 34-hour reset and 6-day pattern validation
5. **Ignores d1/d2**: Correctly ignores Amazon internal codes in Operator ID

## Important Notes

- **d1/d2 suffixes are ignored**: These are Amazon internal codes, not relevant for contract lookup
- **Each tractor/time is a separate contract**: Never group by time alone
- **Contract times have 10-hour rest built in**: No need to add rest separately
- **All 17 base contracts tracked**: 10 Solo1 + 7 Solo2 contracts

## Files Modified

- `/home/ubuntu/schedule_utils.py`: Added 3 new functions, updated `get_block_times()`
- `/home/ubuntu/schedule_validator.py`: No changes needed (uses `get_block_times()` internally)

## Files Reference

- `/home/ubuntu/base_time_contracts.json`: Source of truth for all 17 contract times
- `/home/ubuntu/CONTRACT_TIMES_SUMMARY.md`: Documentation of contract times
- `/home/ubuntu/OPERATOR_ID_PATCH_README.md`: This file

## Next Steps

1. Test with actual Friday schedule file containing mixed data
2. Verify all DOT compliance validations work correctly
3. Update any custom scripts to use new functions
4. Consider removing legacy method after full testing

## Support

For questions about this patch, refer to:
- `CONTRACT_TIMES_SUMMARY.md` for contract time details
- `schedule_utils.py` for function documentation
- `schedule_validator.py` for validation logic
