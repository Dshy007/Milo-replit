# Contract Times Summary

**Week:** Nov 9-15, 2025  
**Total Contracts:** 87 (60 Solo1 + 27 Solo2)

---

## 🚛 SOLO1 CONTRACTS (10 Tractors)

| # | Start Time | Tractor | Days Per Week | Total Blocks |
|---|------------|---------|---------------|--------------|
| 1 | 00:30 CT | Tractor_8 | 6 days | 6 blocks |
| 2 | 01:30 CT | Tractor_6 | 6 days | 6 blocks |
| 3 | 16:30 CT | Tractor_1 | 6 days | 6 blocks |
| 4 | 16:30 CT | Tractor_9 | 6 days | 6 blocks |
| 5 | 17:30 CT | Tractor_4 | 6 days | 6 blocks |
| 6 | 18:30 CT | Tractor_7 | 6 days | 6 blocks |
| 7 | 20:30 CT | Tractor_10 | 6 days | 6 blocks |
| 8 | 20:30 CT | Tractor_2 | 6 days | 6 blocks |
| 9 | 20:30 CT | Tractor_3 | 6 days | 6 blocks |
| 10 | 21:30 CT | Tractor_5 | 6 days | 6 blocks |

**Subtotal:** 60 blocks

---

## 🚛🚛 SOLO2 CONTRACTS (8 Tractor Assignments)

| # | Start Time | Tractor | Days Per Week | Total Blocks |
|---|------------|---------|---------------|--------------|
| 1 | 08:30 CT | Tractor_4 | 4 days | 4 blocks |
| 2 | 09:40 CT | Tractor_2 | 1 day | 1 block |
| 3 | 11:30 CT | Tractor_6 | 4 days | 4 blocks |
| 4 | 15:30 CT | Tractor_5 | 4 days | 4 blocks |
| 5 | 16:30 CT | Tractor_7 | 3 days | 3 blocks |
| 6 | 18:30 CT | Tractor_1 | 4 days | 4 blocks |
| 7 | 21:30 CT | Tractor_3 | 4 days | 4 blocks |
| 8 | 23:30 CT | Tractor_2 | 3 days | 3 blocks |

**Subtotal:** 27 blocks

---

## 📊 BREAKDOWN BY START TIME

### Solo1:
| Start Time | # of Tractors | Total Blocks |
|------------|---------------|--------------|
| 00:30 CT | 1 (Tractor_8) | 6 |
| 01:30 CT | 1 (Tractor_6) | 6 |
| 16:30 CT | 2 (Tractor_1, 9) | 12 |
| 17:30 CT | 1 (Tractor_4) | 6 |
| 18:30 CT | 1 (Tractor_7) | 6 |
| 20:30 CT | 3 (Tractor_10, 2, 3) | 18 |
| 21:30 CT | 1 (Tractor_5) | 6 |

### Solo2:
| Start Time | # of Tractors | Total Blocks |
|------------|---------------|--------------|
| 08:30 CT | 1 (Tractor_4) | 4 |
| 09:40 CT | 1 (Tractor_2) | 1 |
| 11:30 CT | 1 (Tractor_6) | 4 |
| 15:30 CT | 1 (Tractor_5) | 4 |
| 16:30 CT | 1 (Tractor_7) | 3 |
| 18:30 CT | 1 (Tractor_1) | 4 |
| 21:30 CT | 1 (Tractor_3) | 4 |
| 23:30 CT | 1 (Tractor_2) | 3 |

---

## 🎯 KEY INSIGHTS

**Most Common Solo1 Times:**
- 20:30 CT: 3 tractors (18 blocks)
- 16:30 CT: 2 tractors (12 blocks)

**Solo2 Coverage:**
- Most contracts run 4 days/week
- One special contract: Tractor_2 @ 09:40 CT (1 day only)

**Total Weekly Capacity:**
- 87 blocks per week
- 60 Solo1 blocks (14-hour runs)
- 27 Solo2 blocks (38-hour runs)

---

**Note:** Each tractor/time combination is a SEPARATE contract. Never group by time alone.
