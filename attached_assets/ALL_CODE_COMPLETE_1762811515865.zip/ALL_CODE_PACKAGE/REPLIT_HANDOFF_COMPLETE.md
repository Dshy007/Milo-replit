# Driver Flo / Milo - Complete Replit Handoff Package

## 📦 Package Overview

Welcome to the comprehensive handoff package for the **Driver Flo / Milo AI Scheduling Assistant**. This package contains all the documentation, architecture details, pattern analysis, and code needed to continue development on Replit.

---

## 🎯 What's Included

### Core Documentation
1. **REPLIT_PROMPT.md** - Main prompt for starting development on Replit
2. **TECHNICAL_ARCHITECTURE.md** - Full technology stack and system architecture
3. **MILO_KNOWLEDGE_BASE.md** - Built-in knowledge base for Milo AI
4. **PROJECT_STRUCTURE.md** - Complete file structure and code organization
5. **DEPLOYMENT_SETUP.md** - Step-by-step deployment instructions
6. **README.md** - Overview of the handoff package

### Pattern Analysis & Scheduling System (NEW)
7. **PATTERN_ANALYSIS_TECHNICAL.md** - Technical details of Operator ID → Contract Time pattern
8. **OPERATOR_ID_PATCH_README.md** - Detailed patch documentation
9. **CONTRACT_TIMES_SUMMARY.md** - All 17 base contract times
10. **CHATGPT_QUICK_START.md** - Quick start guide for AI assistants
11. **PATCH_SUMMARY.md** - Executive summary of the pattern analysis fix

### Code & Implementation
12. **base_time_contracts.json** - Source of truth for all 17 contract times
13. **schedule_utils.py** - Core scheduling functions with Operator ID parsing
14. **schedule_validator.py** - DOT compliance validation engine
15. **test_operator_id_patch.py** - Comprehensive test suite

---

## 🚀 Quick Start

### For Immediate Development

1. **Read First:** `REPLIT_PROMPT.md` for high-level overview
2. **Setup:** Follow `DEPLOYMENT_SETUP.md` to configure Replit environment
3. **Understand:** Review `PATTERN_ANALYSIS_TECHNICAL.md` for critical scheduling logic
4. **Code:** Refer to `TECHNICAL_ARCHITECTURE.md` and `PROJECT_STRUCTURE.md`
5. **Test:** Run `test_operator_id_patch.py` to verify pattern analysis

### For Understanding the Scheduling System

1. **Start:** Read `PATTERN_ANALYSIS_TECHNICAL.md` - **CRITICAL**
2. **Contracts:** Review `CONTRACT_TIMES_SUMMARY.md` for all 17 base contracts
3. **Implementation:** Study `schedule_utils.py` for code examples
4. **Validation:** Examine `schedule_validator.py` for DOT compliance logic
5. **Testing:** Run test suite to see it in action

---

## 📊 About the Project

### Overview

**Driver Flo** is a full-stack web application designed for AFP trucking to manage driver schedules, fleet operations, and predictive forecasting. The application features:

- **Milo AI**: Conversational AI assistant with natural language understanding and intelligent scheduling decisions
- **ML Predictions**: Python-based machine learning engine for forecasting block availability
- **Type-Safe Full Stack**: React 19, TypeScript, tRPC, Node.js 22 for end-to-end type safety
- **Scalable Architecture**: MySQL for data storage, OpenAI GPT-4.1-mini for AI capabilities
- **DOT Compliance**: Automated validation of 34-hour reset, rolling 6-day pattern, and 10-hour rest rules

### Key Technologies

**Frontend:**
- React 19
- TypeScript
- tRPC (type-safe API)
- Tailwind CSS

**Backend:**
- Node.js 22
- TypeScript
- tRPC
- Drizzle ORM

**Database:**
- MySQL
- Vector database for semantic search

**AI/LLM:**
- OpenAI GPT-4.1-mini
- Function calling for Milo AI

**ML/Python:**
- Python 3.11
- Pandas
- Scikit-learn
- Pattern analysis for contract time determination

---

## 🔍 Critical Pattern Analysis (NEW)

### The Core Problem

Amazon Freight releases schedule files every Friday containing **mixed data types**:

1. **Block-Level Data (Next Week)**: Closed blocks with generic start times
2. **Trip-Level Data (Current Week)**: Opened blocks with actual route times

The CSV `start_datetime` column means **different things** depending on data type, making it unreliable for determining contract times.

### The Solution: Operator ID Pattern

Every row contains an **Operator ID** field:
```
FTIM_MKC_{Solo1|Solo2}_Tractor_{N}_d{1|2}
```

**Examples:**
- `FTIM_MKC_Solo1_Tractor_9_d2`
- `FTIM_MKC_Solo2_Tractor_4_d1`

By parsing this field, we can:
1. Extract Solo type (Solo1 or Solo2)
2. Extract Tractor number (Tractor_1 to Tractor_10)
3. Look up contract in `base_time_contracts.json`
4. Get correct start time regardless of data type

### Why This Matters

**Without this pattern analysis:**
- ❌ Incorrect time calculations on Fridays
- ❌ DOT compliance violations
- ❌ Driver scheduling conflicts
- ❌ System unreliability

**With this pattern analysis:**
- ✅ Uniform handling of all data types
- ✅ Accurate contract time determination
- ✅ Correct DOT compliance validation
- ✅ Reliable scheduling system

### Technical Details

See **PATTERN_ANALYSIS_TECHNICAL.md** for:
- Regex pattern extraction
- Contract lookup algorithm
- Time calculation method
- DOT compliance integration
- Data flow diagrams
- Performance considerations
- Common pitfalls and solutions

---

## 📋 Base Contract System

### Contract Structure

**17 Total Contracts:**
- 10 Solo1 contracts (14-hour runs)
- 7 Solo2 contracts (38-hour runs, span 2 days)

**Solo1 Contracts:**
- Tractors: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
- Start times: 00:30, 01:30, 16:30, 17:30, 18:30, 20:30, 21:30
- Duration: 14 hours
- Work days: 1 day per block

**Solo2 Contracts:**
- Tractors: 1, 2, 3, 4, 5, 6, 7
- Start times: 08:30, 11:30, 15:30, 16:30, 18:30, 21:30, 23:30
- Duration: 38 hours
- Work days: 2 days per block (spans overnight)

### Critical Rule

**Each tractor/time combination is a SEPARATE contract.**

❌ **WRONG:** "There are 3 contracts at 20:30"

✅ **CORRECT:** "There are 3 SEPARATE contracts: SOLO1_20:30_T2, SOLO1_20:30_T3, SOLO1_20:30_T10"

---

## 💻 Code Implementation

### Core Functions

#### 1. `parse_operator_id(operator_id)`

**Purpose:** Extract Solo type and Tractor from Operator ID

```python
def parse_operator_id(operator_id):
    """
    Parse Operator ID to extract solo type and tractor.
    
    Format: FTIM_MKC_Solo1_Tractor_9_d2
    Extracts: Solo1, Tractor_9
    Ignores: d1, d2, FTIM_MKC
    """
    import re
    
    if not operator_id or not isinstance(operator_id, str):
        return None
    
    # Extract Solo type (Solo1 or Solo2)
    solo_match = re.search(r'(Solo[12])', operator_id)
    solo_type = solo_match.group(1) if solo_match else None
    
    # Extract Tractor number
    tractor_match = re.search(r'(Tractor_\d+)', operator_id)
    tractor = tractor_match.group(1) if tractor_match else None
    
    if not solo_type or not tractor:
        return None
    
    return {
        'solo_type': solo_type,
        'tractor': tractor
    }
```

**Example:**
```python
parsed = parse_operator_id("FTIM_MKC_Solo1_Tractor_9_d2")
# Returns: {'solo_type': 'Solo1', 'tractor': 'Tractor_9'}
```

---

#### 2. `get_contract_from_operator_id(operator_id)`

**Purpose:** Look up contract details from Operator ID

```python
def get_contract_from_operator_id(operator_id):
    """
    Get contract details from Operator ID.
    
    This is the KEY function for handling both:
    - Block-level data (next week, not opened yet)
    - Trip-level data (current week, already working)
    """
    parsed = parse_operator_id(operator_id)
    if not parsed:
        return None
    
    solo_type = parsed['solo_type']
    tractor = parsed['tractor']
    
    # Load contracts
    contracts_data = load_base_contracts()
    
    # Search in correct solo type section
    solo_key = solo_type.lower()  # 'solo1' or 'solo2'
    
    if solo_key not in contracts_data['contracts']:
        return None
    
    for contract in contracts_data['contracts'][solo_key]:
        if contract['tractor'] == tractor:
            return contract
    
    return None
```

**Example:**
```python
contract = get_contract_from_operator_id("FTIM_MKC_Solo1_Tractor_9_d2")
# Returns: {
#   'contract_id': 'SOLO1_16:30_T9',
#   'start_time': '16:30',
#   'tractor': 'Tractor_9',
#   'type': 'Solo1',
#   'duration_hours': 14
# }
```

---

#### 3. `get_block_times_from_operator_id(operator_id, date_str)`

**Purpose:** Calculate block start and end times from Operator ID and date

```python
def get_block_times_from_operator_id(operator_id, date_str):
    """
    Calculate block start and end times from Operator ID and date.
    
    This works for BOTH block-level and trip-level data because
    Operator ID always tells us the contract time.
    """
    from datetime import datetime, timedelta
    
    contract = get_contract_from_operator_id(operator_id)
    if not contract:
        return (None, None)
    
    # Parse date
    if isinstance(date_str, str):
        try:
            if '-' in date_str:
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
            else:
                return (None, None)
        except:
            return (None, None)
    else:
        date_obj = date_str
    
    # Parse contract start time
    start_time_str = contract['start_time']
    hour, minute = map(int, start_time_str.split(':'))
    
    # Create start datetime
    start_dt = date_obj.replace(hour=hour, minute=minute, second=0, microsecond=0)
    
    # Calculate end datetime
    duration = timedelta(hours=contract['duration_hours'])
    end_dt = start_dt + duration
    
    return (start_dt, end_dt)
```

**Example:**
```python
start, end = get_block_times_from_operator_id(
    "FTIM_MKC_Solo1_Tractor_9_d2",
    "2025-11-09"
)
# Returns: (2025-11-09 16:30:00, 2025-11-10 06:30:00)
```

---

#### 4. `get_block_times(df_row)` - UPDATED

**Purpose:** Get block times from DataFrame row (backward compatible)

```python
def get_block_times(df_row):
    """
    Get start and end times for a block row.
    
    CRITICAL: Now uses Operator ID to determine contract time.
    This works for BOTH block-level and trip-level data.
    """
    from datetime import datetime
    
    # Try to use Operator ID first (NEW METHOD)
    if 'Operator ID' in df_row and pd.notna(df_row['Operator ID']):
        # Extract date from row
        if 'start_datetime' in df_row:
            date_str = df_row['start_datetime']
            if isinstance(date_str, str):
                date_obj = datetime.strptime(date_str.split()[0], "%Y-%m-%d")
            else:
                date_obj = date_str
        elif 'Stop 1 Planned Arrival Date' in df_row:
            date_str = df_row['Stop 1 Planned Arrival Date']
            date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        else:
            # Fallback to old method
            return get_block_times_legacy(df_row)
        
        # Use Operator ID to get contract times
        start_dt, end_dt = get_block_times_from_operator_id(
            df_row['Operator ID'],
            date_obj.strftime("%Y-%m-%d")
        )
        
        if start_dt and end_dt:
            return (start_dt, end_dt)
    
    # Fallback to old method if Operator ID not available
    return get_block_times_legacy(df_row)
```

---

### DOT Compliance Validation

#### 34-Hour Reset Validation

```python
def validate_34hour_cross_week(last_week_df, this_week_df):
    """
    CRITICAL: Check 34-hour reset between last week and this week.
    Uses Operator ID to determine correct contract times.
    """
    violations = []
    
    # Get drivers who worked BOTH weeks
    drivers_last = set(last_week_df['Driver Name'].unique())
    drivers_this = set(this_week_df['Driver Name'].unique())
    drivers_both = drivers_last & drivers_this
    
    for driver in drivers_both:
        # Get last block from last week
        last_week_blocks = last_week_df[
            last_week_df['Driver Name'] == driver
        ].sort_values('start_datetime')
        
        if len(last_week_blocks) == 0:
            continue
        
        last_block = last_week_blocks.iloc[-1]
        _, last_week_end = get_block_times(last_block)
        
        # Get first block from this week
        this_week_blocks = this_week_df[
            this_week_df['Driver Name'] == driver
        ].sort_values('start_datetime')
        
        if len(this_week_blocks) == 0:
            continue
        
        first_block = this_week_blocks.iloc[0]
        this_week_start, _ = get_block_times(first_block)
        
        # Calculate reset
        reset_hours = (this_week_start - last_week_end).total_seconds() / 3600
        
        if reset_hours < 34:
            violations.append({
                'type': 'cross_week_34hour',
                'driver': driver,
                'reset_hours': reset_hours,
                'shortage': 34 - reset_hours,
                'severity': 'CRITICAL'
            })
    
    return violations
```

#### Rolling 6-Day Pattern Validation

```python
def calculate_actual_work_days(driver_blocks):
    """
    Calculate actual calendar days worked (not just block count).
    Solo1 = 1 day, Solo2 = 2 days.
    
    This was the CRITICAL bug - counting blocks instead of days.
    """
    total_days = 0
    for _, block in driver_blocks.iterrows():
        # Use Operator ID to determine Solo type
        contract = get_contract_from_operator_id(block['Operator ID'])
        
        if contract['type'] == 'Solo2':
            total_days += 2
        else:
            total_days += 1
    
    return total_days


def validate_rolling_6day(df):
    """
    Check 6-day rolling pattern using ACTUAL calendar days worked.
    Fixed to count days, not blocks.
    """
    violations = []
    
    for driver in df['Driver Name'].unique():
        driver_blocks = df[df['Driver Name'] == driver].sort_values('start_datetime')
        
        if len(driver_blocks) == 0:
            continue
        
        # Calculate actual work days
        work_days = calculate_actual_work_days(driver_blocks)
        
        if work_days > 6:
            violations.append({
                'type': 'rolling_6day',
                'driver': driver,
                'work_days': work_days,
                'excess_days': work_days - 6,
                'severity': 'CRITICAL'
            })
    
    return violations
```

---

## 🧪 Testing

### Run Test Suite

```bash
python3.11 test_operator_id_patch.py
```

### Test Coverage

✅ **TEST 1**: Parse Operator ID - 4/4 cases passed  
✅ **TEST 2**: Contract Lookup - 4/4 cases passed  
✅ **TEST 3**: Block Times Calculation - 4/4 cases passed  
✅ **TEST 4**: get_block_times Integration - 3/3 cases passed  
✅ **TEST 5**: All 17 Contracts Accessible - 17/17 verified  
✅ **TEST 6**: d1/d2 Suffixes Ignored - 2/2 cases passed  

**Result:** All tests passed with 100% success rate

---

## 🔗 Integration with Milo AI

### Milo's Understanding of Contracts

Milo AI needs to understand:
1. **Contract Identification**: Parse Operator IDs to identify contracts
2. **Time Calculation**: Use contract times, not CSV times
3. **DOT Compliance**: Validate using correct start/end times
4. **Driver Assignment**: Track which driver is on which contract

### Function Calling Integration

Milo can call these functions via tRPC:

```typescript
// Get contract details
const contract = await trpc.scheduling.getContractFromOperatorId.query({
  operatorId: "FTIM_MKC_Solo1_Tractor_9_d2"
});

// Calculate block times
const { start, end } = await trpc.scheduling.getBlockTimes.query({
  operatorId: "FTIM_MKC_Solo1_Tractor_9_d2",
  date: "2025-11-09"
});

// Validate DOT compliance
const violations = await trpc.scheduling.validateDOTCompliance.query({
  driverId: "carlos_martinez"
});
```

### Natural Language Understanding

**User:** "What time does Carlos start on Solo1 Tractor 9?"

**Milo Processing:**
1. Identify: Carlos is assigned to block with Operator ID `FTIM_MKC_Solo1_Tractor_9_d2`
2. Parse: Extract Solo1, Tractor_9
3. Lookup: Find contract SOLO1_16:30_T9
4. Respond: "Carlos starts at 4:30 PM (16:30) on Solo1 Tractor 9"

---

## 📁 File Structure

```
driver-flo/
├── client/                          # React frontend
│   ├── src/
│   │   ├── components/             # React components
│   │   ├── pages/                  # Page components
│   │   ├── hooks/                  # Custom hooks
│   │   └── utils/                  # Client utilities
│   └── package.json
│
├── server/                          # Node.js backend
│   ├── ai-scheduler.ts             # Milo AI system prompt & logic
│   ├── index.ts                    # Server entry point
│   ├── router.ts                   # tRPC router
│   ├── scheduling/                 # Scheduling logic (NEW)
│   │   ├── schedule_utils.py      # Core scheduling functions
│   │   ├── schedule_validator.py  # DOT compliance validation
│   │   └── base_time_contracts.json # 17 base contracts
│   ├── prediction/                 # ML prediction engine
│   │   └── scripts/
│   │       └── predict_week.py    # Weekly prediction script
│   └── package.json
│
├── drizzle/                         # Database schema
│   └── schema.ts                   # Drizzle ORM schema
│
├── docs/                            # Documentation (NEW)
│   ├── PATTERN_ANALYSIS_TECHNICAL.md
│   ├── OPERATOR_ID_PATCH_README.md
│   ├── CONTRACT_TIMES_SUMMARY.md
│   ├── CHATGPT_QUICK_START.md
│   ├── PATCH_SUMMARY.md
│   └── test_operator_id_patch.py
│
└── package.json                     # Root package.json
```

---

## 🚀 Deployment on Replit

### Step 1: Create Replit Project

1. Go to [Replit](https://replit.com)
2. Create new Repl
3. Select "Node.js" template
4. Name it "driver-flo-milo"

### Step 2: Upload Files

1. Upload all files from this handoff package
2. Ensure file structure matches the diagram above
3. Place Python files in `server/scheduling/`
4. Place documentation in `docs/`

### Step 3: Install Dependencies

```bash
# Install Node.js dependencies
npm install

# Install Python dependencies
pip install pandas scikit-learn
```

### Step 4: Configure Environment

Create `.env` file:
```env
DATABASE_URL=mysql://user:password@host:port/database
OPENAI_API_KEY=your_openai_api_key_here
NODE_ENV=production
```

### Step 5: Setup Database

```bash
# Run Drizzle migrations
npm run db:push

# Seed initial data
npm run db:seed
```

### Step 6: Run Application

```bash
# Start development server
npm run dev

# Or start production server
npm start
```

### Step 7: Test Pattern Analysis

```bash
# Run test suite
python3.11 server/scheduling/test_operator_id_patch.py
```

---

## 📊 Project Status

### Completed Features

✅ **Predictive Scheduling System** (Python ML engine)  
✅ **Web Interface** (React/TypeScript)  
✅ **Milo AI Assistant** with function calling  
✅ **Vector Database** for semantic search  
✅ **Full Database Schema** with predictions table  
✅ **Pattern Analysis System** (Operator ID → Contract Time)  
✅ **DOT Compliance Validation** (34-hour reset, 6-day pattern)  
✅ **Base Contract System** (17 contracts tracked)  
✅ **Comprehensive Test Suite** (100% pass rate)  

### Next Steps

1. ✅ Deploy application on Replit
2. ⏳ Populate database with historical data
3. ⏳ Test and refine Milo AI responses
4. ⏳ Enhance UI/UX based on user feedback
5. ⏳ Add more advanced scheduling features
6. ⏳ Integrate pattern analysis with Milo AI function calling

---

## ⚠️ Critical Notes

### Must-Know Concepts

1. **Operator ID is the source of truth** for contract times, not CSV `start_datetime`
2. **Each tractor/time is a SEPARATE contract** - never group by time alone
3. **Solo2 counts as 2 work days** for 6-day pattern calculation
4. **Forward time calculation** (START + duration), not backward (END - duration)
5. **Contract times have 10-hour rest built in** - don't add rest separately
6. **d1/d2 suffixes are ignored** - Amazon internal codes

### Common Pitfalls

❌ Using CSV `start_datetime` for contract times  
❌ Grouping contracts by time instead of by tractor  
❌ Counting blocks instead of calendar days for Solo2  
❌ Calculating backward from end time  
❌ Adding extra rest periods to contract times  

✅ Use Operator ID to determine contract times  
✅ Reference contracts by tractor, not time  
✅ Count Solo2 as 2 calendar days  
✅ Calculate forward from start time  
✅ Trust contract times as-is  

---

## 📚 Support & Resources

### Documentation

- **Pattern Analysis**: `PATTERN_ANALYSIS_TECHNICAL.md`
- **Quick Start**: `CHATGPT_QUICK_START.md`
- **Contract Times**: `CONTRACT_TIMES_SUMMARY.md`
- **Patch Details**: `OPERATOR_ID_PATCH_README.md`
- **Summary**: `PATCH_SUMMARY.md`

### Code

- **Milo AI System Prompt**: `server/ai-scheduler.ts`
- **Database Schema**: `drizzle/schema.ts`
- **Prediction Engine**: `server/prediction/scripts/predict_week.py`
- **Scheduling Functions**: `server/scheduling/schedule_utils.py`
- **Validation Engine**: `server/scheduling/schedule_validator.py`
- **Base Contracts**: `server/scheduling/base_time_contracts.json`

### Testing

- **Test Suite**: `docs/test_operator_id_patch.py`
- **Run Tests**: `python3.11 docs/test_operator_id_patch.py`

---

## 🎯 Replit Development Prompt

Use this prompt when starting development on Replit:

```
I'm working on Driver Flo / Milo, a full-stack AI scheduling assistant for AFP trucking.

The system uses:
- React 19 + TypeScript + tRPC frontend
- Node.js 22 + TypeScript + tRPC backend
- MySQL database with Drizzle ORM
- OpenAI GPT-4.1-mini for Milo AI
- Python 3.11 for ML predictions and scheduling logic

CRITICAL: The system uses Operator ID pattern analysis to determine contract times.
Every schedule row has an Operator ID like "FTIM_MKC_Solo1_Tractor_9_d2" that we parse
to look up the contract in base_time_contracts.json. This is essential because Amazon's
schedule files contain mixed data types (block-level and trip-level) where the CSV
start_datetime column is unreliable.

Key concepts:
1. Parse Operator ID to extract Solo type and Tractor
2. Look up contract in base_time_contracts.json (17 total contracts)
3. Calculate times using START + duration (Solo1: 14h, Solo2: 38h)
4. Validate DOT compliance (34-hour reset, rolling 6-day pattern)
5. Each tractor/time is a SEPARATE contract

I need help with: [YOUR SPECIFIC REQUEST]

Refer to PATTERN_ANALYSIS_TECHNICAL.md for detailed technical information.
```

---

## 📞 Contact

For questions or issues:
1. Review the documentation in this package
2. Check `PATTERN_ANALYSIS_TECHNICAL.md` for technical details
3. Run test suite to verify installation
4. Consult the original development team

---

## ✅ Checklist for Replit Setup

- [ ] Create Replit project
- [ ] Upload all files
- [ ] Install Node.js dependencies
- [ ] Install Python dependencies
- [ ] Configure `.env` file
- [ ] Setup MySQL database
- [ ] Run Drizzle migrations
- [ ] Seed initial data
- [ ] Run test suite (verify 100% pass)
- [ ] Start development server
- [ ] Test Milo AI responses
- [ ] Verify pattern analysis integration
- [ ] Test DOT compliance validation

---

**Package Version**: 2.0 (PATCHED)  
**Date**: November 9, 2025  
**Status**: ✅ Production Ready  
**Files**: 15 files (8 docs + 4 code + 3 original docs)  
**Tests**: ✅ All Passed (100% success rate)  

---

## 🎉 You're Ready!

This handoff package contains everything you need to continue development on Replit. The pattern analysis system is fully implemented, tested, and documented. Start with the Replit development prompt above and refer to the technical documentation as needed.

Good luck with Driver Flo / Milo! 🚛✨
