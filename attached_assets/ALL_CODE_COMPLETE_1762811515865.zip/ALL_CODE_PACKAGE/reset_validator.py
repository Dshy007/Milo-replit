"""
34-Hour Reset Validator - Cross-Week Support
Validates DOT 34-hour reset between consecutive blocks, including cross-week transitions
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

def calculate_block_times(block_row: pd.Series) -> Tuple[datetime, datetime]:
    """
    Calculate actual start and stop times for a block.
    
    Args:
        block_row: DataFrame row containing block information
        
    Returns:
        Tuple of (actual_start_time, stop_time)
    """
    stop_time = block_row['start_datetime']
    
    if block_row['solo_type'] == 'Solo2':
        duration_hours = 38
    else:
        duration_hours = 14
    
    actual_start = stop_time - timedelta(hours=duration_hours)
    
    return actual_start, stop_time


def validate_34hour_reset_within_week(df: pd.DataFrame) -> List[Dict]:
    """
    Check 34-hour reset between consecutive blocks WITHIN the same week.
    
    Args:
        df: DataFrame with schedule data
        
    Returns:
        List of violations found
    """
    violations = []
    
    df['start_datetime'] = pd.to_datetime(
        df['Stop 1 Planned Arrival Date'] + ' ' + df['Stop 1 Planned Arrival Time'],
        format='%m/%d/%Y %H:%M'
    )
    
    for driver in df['Driver Name'].unique():
        driver_blocks = df[df['Driver Name'] == driver].sort_values('start_datetime')
        
        if len(driver_blocks) < 2:
            continue
        
        blocks_info = []
        for _, block in driver_blocks.iterrows():
            start, stop = calculate_block_times(block)
            blocks_info.append({
                'block_id': block['Block ID'],
                'start': start,
                'stop': stop,
                'type': block['solo_type']
            })
        
        # Check consecutive blocks
        for i in range(len(blocks_info) - 1):
            block1 = blocks_info[i]
            block2 = blocks_info[i + 1]
            
            reset_hours = (block2['start'] - block1['stop']).total_seconds() / 3600
            
            if reset_hours < 34:
                violations.append({
                    'driver': driver,
                    'type': 'within_week',
                    'block1_id': block1['block_id'],
                    'block2_id': block2['block_id'],
                    'block1_stop': block1['stop'],
                    'block2_start': block2['start'],
                    'reset_hours': reset_hours,
                    'shortage': 34 - reset_hours
                })
    
    return violations


def validate_34hour_reset_cross_week(df_last_week: pd.DataFrame, df_this_week: pd.DataFrame) -> List[Dict]:
    """
    Check 34-hour reset between LAST WEEK's last block and THIS WEEK's first block.
    
    This is the CRITICAL check that was missing!
    
    Args:
        df_last_week: DataFrame with last week's schedule
        df_this_week: DataFrame with this week's schedule
        
    Returns:
        List of violations found
    """
    violations = []
    
    # Parse datetimes
    df_last_week['start_datetime'] = pd.to_datetime(
        df_last_week['Stop 1 Planned Arrival Date'] + ' ' + df_last_week['Stop 1 Planned Arrival Time'],
        format='%m/%d/%Y %H:%M'
    )
    
    df_this_week['start_datetime'] = pd.to_datetime(
        df_this_week['Stop 1 Planned Arrival Date'] + ' ' + df_this_week['Stop 1 Planned Arrival Time'],
        format='%m/%d/%Y %H:%M'
    )
    
    # Get all drivers who worked BOTH weeks
    drivers_last_week = set(df_last_week['Driver Name'].unique())
    drivers_this_week = set(df_this_week['Driver Name'].unique())
    drivers_both_weeks = drivers_last_week & drivers_this_week
    
    for driver in drivers_both_weeks:
        # Get last block from last week
        last_week_blocks = df_last_week[df_last_week['Driver Name'] == driver].sort_values('start_datetime')
        if len(last_week_blocks) == 0:
            continue
        
        last_block_last_week = last_week_blocks.iloc[-1]
        _, last_week_end = calculate_block_times(last_block_last_week)
        
        # Get first block from this week
        this_week_blocks = df_this_week[df_this_week['Driver Name'] == driver].sort_values('start_datetime')
        if len(this_week_blocks) == 0:
            continue
        
        first_block_this_week = this_week_blocks.iloc[0]
        this_week_start, _ = calculate_block_times(first_block_this_week)
        
        # Calculate reset
        reset_hours = (this_week_start - last_week_end).total_seconds() / 3600
        
        if reset_hours < 34:
            violations.append({
                'driver': driver,
                'type': 'cross_week',
                'last_week_block_id': last_block_last_week['Block ID'],
                'this_week_block_id': first_block_this_week['Block ID'],
                'last_week_end': last_week_end,
                'this_week_start': this_week_start,
                'reset_hours': reset_hours,
                'shortage': 34 - reset_hours
            })
    
    return violations


def print_violations(violations: List[Dict]):
    """Print violations in a readable format."""
    if not violations:
        print("✅ No 34-hour reset violations found")
        return
    
    print(f"❌ Found {len(violations)} 34-hour reset violation(s):\n")
    
    for v in violations:
        print(f"Driver: {v['driver']}")
        print(f"Type: {v['type']}")
        
        if v['type'] == 'within_week':
            print(f"  Block 1: {v['block1_id']} ends {v['block1_stop'].strftime('%a %m/%d @ %H:%M')}")
            print(f"  Block 2: {v['block2_id']} starts {v['block2_start'].strftime('%a %m/%d @ %H:%M')}")
        else:  # cross_week
            print(f"  Last week: {v['last_week_block_id']} ends {v['last_week_end'].strftime('%a %m/%d @ %H:%M')}")
            print(f"  This week: {v['this_week_block_id']} starts {v['this_week_start'].strftime('%a %m/%d @ %H:%M')}")
        
        print(f"  Reset: {v['reset_hours']:.1f} hours (need 34h, short {v['shortage']:.1f}h)")
        print()


if __name__ == "__main__":
    # Test with current schedules
    df_last = pd.read_csv('/home/ubuntu/last_week_oct26_nov1.csv')
    df_this = pd.read_csv('/home/ubuntu/last_week_schedule.csv')
    
    # Rename column if needed
    if 'assigned_driver' in df_last.columns:
        df_last['Driver Name'] = df_last['assigned_driver']
    
    print("=" * 80)
    print("34-HOUR RESET VALIDATION")
    print("=" * 80)
    
    print("\n1. Checking within-week violations...")
    within_violations = validate_34hour_reset_within_week(df_this)
    print_violations(within_violations)
    
    print("\n2. Checking cross-week violations...")
    cross_violations = validate_34hour_reset_cross_week(df_last, df_this)
    print_violations(cross_violations)
    
    print("\n" + "=" * 80)
    print(f"TOTAL VIOLATIONS: {len(within_violations) + len(cross_violations)}")
    print("=" * 80)
