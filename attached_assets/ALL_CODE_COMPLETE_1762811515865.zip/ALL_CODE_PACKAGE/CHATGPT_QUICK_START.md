# ChatGPT Quick Start Guide - Driver Scheduling System

## What This System Does

Validates Amazon Freight driver schedules for DOT compliance:
- **34-hour reset rule**: Minimum rest between work periods
- **Rolling 6-day pattern**: Maximum consecutive work days
- **10-hour rest**: Minimum rest between shifts
- **One block per day**: No double-booking

## Critical Concept: Operator ID → Contract Time

**IMPORTANT**: The system now uses **Operator ID parsing** to determine contract times, not the CSV `start_datetime` column.

### Why?
On Fridays, schedule files contain mixed data:
- **Block-level data** (next week): Closed blocks with generic times
- **Trip-level data** (current week): Opened blocks with actual route times

The `start_datetime` column means different things for each type. **Operator ID is the single source of truth.**

## Quick Usage

### 1. Load the System
```python
from schedule_utils import (
    get_contract_from_operator_id,
    get_block_times,
    display_base_times
)
from schedule_validator import ScheduleValidator
```

### 2. View All Contract Times
```python
# Show all 17 base contracts (10 Solo1 + 7 Solo2)
display_base_times()
```

### 3. Look Up a Contract
```python
# Parse Operator ID to get contract
contract = get_contract_from_operator_id("FTIM_MKC_Solo1_Tractor_9_d2")

print(f"Contract ID: {contract['contract_id']}")
print(f"Start Time: {contract['start_time']}")
print(f"Duration: {contract['duration_hours']} hours")
print(f"Type: {contract['type']}")
```

### 4. Calculate Block Times
```python
import pandas as pd

# Load schedule
df = pd.read_csv('schedule.csv')

# Get times for each block (uses Operator ID automatically)
for _, row in df.iterrows():
    start, end = get_block_times(row)
    print(f"{row['Driver Name']}: {start} → {end}")
```

### 5. Validate Schedule
```python
# Create validator
validator = ScheduleValidator('last_week.csv', 'this_week.csv')

# Check 34-hour reset between weeks
violations = validator.validate_34hour_cross_week()
for v in violations:
    print(f"❌ {v['driver']}: {v['reset_hours']:.1f}h reset (need 34h)")

# Check rolling 6-day pattern
violations = validator.validate_rolling_6day()
for v in violations:
    print(f"❌ {v['driver']}: {v['consecutive_days']} consecutive days (max 6)")
```

## Key Files

1. **base_time_contracts.json**: All 17 contract times (source of truth)
2. **schedule_utils.py**: Core functions (parsing, lookup, calculation)
3. **schedule_validator.py**: DOT compliance validation
4. **CONTRACT_TIMES_SUMMARY.md**: Human-readable contract documentation
5. **OPERATOR_ID_PATCH_README.md**: Detailed patch documentation

## Contract Structure

### Solo1 Contracts (14 hours)
- 10 contracts total
- Tractors: 1, 2, 3, 5, 6, 7, 8, 9, 10, 11
- Start times: 16:30 (all same time, but SEPARATE contracts)
- Duration: 14 hours
- End time: START + 14h = 06:30 next day

### Solo2 Contracts (38 hours, spans 2 days)
- 7 contracts total
- Tractors: 1, 2, 3, 4, 5, 6, 7
- Start times: 08:30 (all same time, but SEPARATE contracts)
- Duration: 38 hours
- End time: START + 38h = 22:30 next day

## Important Rules

1. **Each tractor/time is a SEPARATE contract**: Never group by time alone
2. **Ignore d1/d2 suffixes**: These are Amazon internal codes
3. **Contract times have 10-hour rest built in**: No need to add rest separately
4. **Use START + duration**: Not END - duration
5. **Solo2 counts as 2 work days**: For 6-day pattern calculation

## Common Operator ID Formats

```
FTIM_MKC_Solo1_Tractor_9_d2   → Solo1, Tractor_9, 16:30 start
FTIM_MKC_Solo2_Tractor_4_d1   → Solo2, Tractor_4, 08:30 start
FTIM_MKC_Solo1_Tractor_1_d1   → Solo1, Tractor_1, 16:30 start
```

## Example: Full Validation Workflow

```python
from schedule_validator import ScheduleValidator

# Initialize
validator = ScheduleValidator('last_week.csv', 'this_week.csv')

# Run all validations
print("=" * 70)
print("DOT COMPLIANCE VALIDATION")
print("=" * 70)

# 1. Cross-week 34-hour reset
print("\n1. Cross-Week 34-Hour Reset:")
violations = validator.validate_34hour_cross_week()
if violations:
    for v in violations:
        print(f"  ❌ {v['driver']}: {v['reset_hours']:.1f}h (need 34h)")
else:
    print("  ✅ All drivers have proper 34-hour reset")

# 2. Within-week 34-hour reset
print("\n2. Within-Week 34-Hour Reset:")
violations = validator.validate_34hour_within_week()
if violations:
    for v in violations:
        print(f"  ❌ {v['driver']}: {v['reset_hours']:.1f}h between blocks")
else:
    print("  ✅ All blocks have proper 34-hour reset")

# 3. Rolling 6-day pattern
print("\n3. Rolling 6-Day Pattern:")
violations = validator.validate_rolling_6day()
if violations:
    for v in violations:
        print(f"  ❌ {v['driver']}: {v['consecutive_days']} consecutive days")
else:
    print("  ✅ No 6-day violations")

# 4. One block per day
print("\n4. One Block Per Day:")
violations = validator.validate_one_block_per_day()
if violations:
    for v in violations:
        print(f"  ❌ {v['driver']}: {v['block_count']} blocks on {v['date']}")
else:
    print("  ✅ No double-booking")
```

## Troubleshooting

### Issue: "Contract not found"
**Solution**: Check Operator ID format. Must match pattern `FTIM_MKC_{Solo1|Solo2}_Tractor_{N}_d{1|2}`

### Issue: "Wrong start time"
**Solution**: Verify tractor number in Operator ID matches contract in `base_time_contracts.json`

### Issue: "Duration incorrect"
**Solution**: Check Solo type. Solo1 = 14h, Solo2 = 38h

### Issue: "Validation shows violations but schedule looks correct"
**Solution**: Ensure you're using the PATCHED version with Operator ID parsing

## Version Information

- **System Version**: v2.0 (PATCHED)
- **Patch Date**: November 2025
- **Key Fix**: Operator ID parsing for mixed data types
- **Files**: 5 core files in ZIP package

## Next Steps

1. Extract ZIP package
2. Load your schedule CSV files
3. Run validations using examples above
4. Review violations and adjust schedule
5. Re-run validation until all checks pass

## Support

For detailed information:
- **Patch details**: See `OPERATOR_ID_PATCH_README.md`
- **Contract times**: See `CONTRACT_TIMES_SUMMARY.md`
- **Function docs**: See docstrings in `schedule_utils.py`
