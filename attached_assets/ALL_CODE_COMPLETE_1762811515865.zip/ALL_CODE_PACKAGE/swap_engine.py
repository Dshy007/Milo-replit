"""
Intelligent Swap Engine with Cascading Impact Analysis
Analyzes all effects before making any schedule changes
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from schedule_validator import ScheduleValidator

class SwapEngine:
    """
    Intelligent engine for analyzing and executing driver swaps.
    Validates all constraints and cascading effects before making changes.
    """
    
    def __init__(self, validator: ScheduleValidator):
        """
        Initialize swap engine with a validator.
        
        Args:
            validator: ScheduleValidator instance with loaded schedules
        """
        self.validator = validator
        self.schedule_df = validator.this_week_df.copy()
    
    def analyze_swap(self, block_id: str, from_driver: str, to_driver: str) -> Dict:
        """
        Analyze the complete impact of swapping a block between drivers.
        
        Args:
            block_id: Block ID to swap
            from_driver: Current driver
            to_driver: New driver
            
        Returns:
            Dict with analysis results and validation status
        """
        print(f"\n{'=' * 80}")
        print(f"ANALYZING SWAP: {block_id}")
        print(f"FROM: {from_driver} → TO: {to_driver}")
        print("=" * 80)
        
        # Create simulated schedule with the swap
        simulated_df = self.schedule_df.copy()
        simulated_df.loc[
            simulated_df['Block ID'] == block_id,
            'Driver Name'
        ] = to_driver
        
        # Create temporary validator with simulated schedule
        temp_validator = ScheduleValidator.__new__(ScheduleValidator)
        temp_validator.last_week_df = self.validator.last_week_df
        temp_validator.this_week_df = simulated_df
        temp_validator.violations = []
        
        # Run validations on simulated schedule
        print("\n🔍 Running validations on simulated schedule...")
        sim_results = temp_validator.run_all_validations()
        
        # Compare with current violations
        current_results = self.validator.run_all_validations()
        
        analysis = {
            'block_id': block_id,
            'from_driver': from_driver,
            'to_driver': to_driver,
            'current_violations': current_results['summary']['total_violations'],
            'simulated_violations': sim_results['summary']['total_violations'],
            'violation_delta': sim_results['summary']['total_violations'] - current_results['summary']['total_violations'],
            'safe_to_execute': sim_results['summary']['total_violations'] <= current_results['summary']['total_violations'],
            'new_violations': [],
            'fixed_violations': []
        }
        
        # Identify new violations
        for vtype in ['cross_week_34hour', 'within_week_34hour', 'rolling_6day', 'one_block_per_day', '10hour_rest']:
            current_drivers = {v['driver'] for v in current_results[vtype]}
            sim_drivers = {v['driver'] for v in sim_results[vtype]}
            
            new_drivers = sim_drivers - current_drivers
            fixed_drivers = current_drivers - sim_drivers
            
            if new_drivers:
                analysis['new_violations'].extend([
                    {'type': vtype, 'driver': d} for d in new_drivers
                ])
            
            if fixed_drivers:
                analysis['fixed_violations'].extend([
                    {'type': vtype, 'driver': d} for d in fixed_drivers
                ])
        
        # Print analysis
        print(f"\n{'=' * 80}")
        print("IMPACT ANALYSIS:")
        print("=" * 80)
        print(f"\nCurrent violations: {analysis['current_violations']}")
        print(f"After swap: {analysis['simulated_violations']}")
        print(f"Delta: {analysis['violation_delta']:+d}")
        
        if analysis['new_violations']:
            print(f"\n⚠️  NEW VIOLATIONS ({len(analysis['new_violations'])}):")
            for v in analysis['new_violations']:
                print(f"   • {v['driver']}: {v['type']}")
        
        if analysis['fixed_violations']:
            print(f"\n✅ FIXED VIOLATIONS ({len(analysis['fixed_violations'])}):")
            for v in analysis['fixed_violations']:
                print(f"   • {v['driver']}: {v['type']}")
        
        if analysis['safe_to_execute']:
            print(f"\n✅ SAFE TO EXECUTE (no increase in violations)")
        else:
            print(f"\n❌ NOT SAFE (would create {analysis['violation_delta']} new violations)")
        
        return analysis
    
    def find_valid_swap_options(self, block_id: str, current_driver: str, 
                                 candidate_drivers: List[str] = None) -> List[Dict]:
        """
        Find all valid swap options for a block that don't create new violations.
        
        Args:
            block_id: Block to reassign
            current_driver: Current driver of the block
            candidate_drivers: Optional list of drivers to consider (default: all)
            
        Returns:
            List of valid swap options sorted by quality score
        """
        if candidate_drivers is None:
            # Get all drivers from schedule
            candidate_drivers = self.schedule_df['Driver Name'].unique().tolist()
            # Remove current driver
            candidate_drivers = [d for d in candidate_drivers if d != current_driver]
        
        print(f"\n{'=' * 80}")
        print(f"FINDING VALID SWAP OPTIONS FOR: {block_id}")
        print(f"Current driver: {current_driver}")
        print(f"Candidates: {len(candidate_drivers)} drivers")
        print("=" * 80)
        
        valid_options = []
        
        for candidate in candidate_drivers:
            analysis = self.analyze_swap(block_id, current_driver, candidate)
            
            if analysis['safe_to_execute']:
                # Calculate quality score
                score = self._calculate_swap_score(analysis)
                analysis['quality_score'] = score
                valid_options.append(analysis)
        
        # Sort by quality score (descending)
        valid_options.sort(key=lambda x: x['quality_score'], reverse=True)
        
        print(f"\n{'=' * 80}")
        print(f"FOUND {len(valid_options)} VALID OPTIONS")
        print("=" * 80)
        
        if valid_options:
            print("\nTop 5 options:")
            for i, opt in enumerate(valid_options[:5], 1):
                print(f"\n{i}. {opt['to_driver']}")
                print(f"   Score: {opt['quality_score']:.1f}/100")
                print(f"   Violations: {opt['current_violations']} → {opt['simulated_violations']} ({opt['violation_delta']:+d})")
                if opt['fixed_violations']:
                    print(f"   Fixes: {len(opt['fixed_violations'])} violations")
        
        return valid_options
    
    def _calculate_swap_score(self, analysis: Dict) -> float:
        """
        Calculate quality score for a swap (0-100).
        
        Scoring factors:
        - Reduces violations: +50 points
        - No new violations: +30 points
        - Maintains balance: +20 points
        """
        score = 0.0
        
        # Reduces violations
        if analysis['violation_delta'] < 0:
            score += 50 * min(abs(analysis['violation_delta']) / 5, 1.0)
        
        # No new violations
        if len(analysis['new_violations']) == 0:
            score += 30
        
        # Fixes violations
        if len(analysis['fixed_violations']) > 0:
            score += 20 * min(len(analysis['fixed_violations']) / 3, 1.0)
        
        return score
    
    def execute_swap(self, block_id: str, from_driver: str, to_driver: str, 
                     force: bool = False) -> bool:
        """
        Execute a swap after validation.
        
        Args:
            block_id: Block to swap
            from_driver: Current driver
            to_driver: New driver
            force: If True, execute even if not safe (use with caution)
            
        Returns:
            True if swap was executed, False otherwise
        """
        # Analyze first
        analysis = self.analyze_swap(block_id, from_driver, to_driver)
        
        if not analysis['safe_to_execute'] and not force:
            print(f"\n❌ SWAP NOT EXECUTED: Would create new violations")
            return False
        
        # Execute the swap
        self.schedule_df.loc[
            self.schedule_df['Block ID'] == block_id,
            'Driver Name'
        ] = to_driver
        
        # Update validator's schedule
        self.validator.this_week_df = self.schedule_df.copy()
        
        print(f"\n✅ SWAP EXECUTED: {block_id}")
        print(f"   {from_driver} → {to_driver}")
        
        return True
    
    def save_schedule(self, filepath: str):
        """Save the current schedule to file."""
        self.schedule_df.to_csv(filepath, index=False)
        print(f"\n✅ Schedule saved to: {filepath}")


if __name__ == "__main__":
    # Test with current schedule
    print("=" * 80)
    print("SWAP ENGINE TEST")
    print("=" * 80)
    
    # Initialize validator
    validator = ScheduleValidator(
        last_week_file='/home/ubuntu/last_week_oct26_nov1.csv',
        this_week_file='/home/ubuntu/last_week_schedule.csv'
    )
    
    # Initialize swap engine
    engine = SwapEngine(validator)
    
    # Test: Find valid options for Carlos's Sunday block
    print("\n\nTEST CASE: Carlos's Sunday @ 11:30 Solo2")
    print("Issue: 10-hour reset violation with Tuesday block")
    print("Solution: Find driver who can take Sunday without violations")
    
    options = engine.find_valid_swap_options(
        block_id='B-DCKW7TQQ6',
        current_driver='Carlos goforth'
    )
    
    if options:
        print(f"\n\n✅ Found {len(options)} valid swap options")
        print(f"Best option: {options[0]['to_driver']} (score: {options[0]['quality_score']:.1f})")
    else:
        print("\n\n❌ No valid swap options found")
