"""
Scheduling utility functions to prevent counting errors
"""

import pandas as pd

def calculate_actual_work_days(df, driver_name=None):
    """
    Calculate ACTUAL work days for drivers, accounting for Solo1/Solo2 differences.
    
    Solo1 = 1 block = 1 work day (~14 hours)
    Solo2 = 1 block = 2 work days (~38 hours)
    
    Args:
        df: DataFrame with schedule data
        driver_name: Optional - specific driver to calculate for
        
    Returns:
        If driver_name provided: int (actual work days)
        If driver_name None: dict {driver: actual_work_days}
    """
    if driver_name:
        # Calculate for specific driver
        driver_blocks = df[df['Driver Name'] == driver_name]
        total_days = 0
        for _, row in driver_blocks.iterrows():
            if row['solo_type'] == 'Solo1':
                total_days += 1
            elif row['solo_type'] == 'Solo2':
                total_days += 2
        return total_days
    else:
        # Calculate for all drivers
        result = {}
        for driver in df['Driver Name'].unique():
            driver_blocks = df[df['Driver Name'] == driver]
            total_days = 0
            for _, row in driver_blocks.iterrows():
                if row['solo_type'] == 'Solo1':
                    total_days += 1
                elif row['solo_type'] == 'Solo2':
                    total_days += 2
            result[driver] = total_days
        return result


def check_6day_violation(df, driver_name):
    """
    Check if driver violates 6-day rolling pattern rule.
    
    Returns:
        (bool, int): (is_violation, actual_days)
    """
    actual_days = calculate_actual_work_days(df, driver_name)
    return (actual_days > 6, actual_days)


def get_drivers_by_work_days(df, target_days=None, max_days=None):
    """
    Get drivers filtered by actual work days.
    
    Args:
        df: DataFrame with schedule data
        target_days: Optional - return drivers with exactly this many days
        max_days: Optional - return drivers with at most this many days
        
    Returns:
        dict {driver: actual_work_days}
    """
    all_days = calculate_actual_work_days(df)
    
    if target_days is not None:
        return {d: days for d, days in all_days.items() if days == target_days}
    elif max_days is not None:
        return {d: days for d, days in all_days.items() if days <= max_days}
    else:
        return all_days


def validate_schedule(df):
    """
    Validate entire schedule for common violations.
    
    Returns:
        list of violation strings (empty if valid)
    """
    violations = []
    
    # Check 6-day rule for all drivers
    work_days = calculate_actual_work_days(df)
    for driver, days in work_days.items():
        if days > 6:
            violations.append(f"{driver}: {days} work days (exceeds 6-day limit)")
    
    # Check one block per day rule
    for driver in df['Driver Name'].unique():
        driver_blocks = df[df['Driver Name'] == driver]
        days_worked = driver_blocks['start_day'].value_counts()
        for day, count in days_worked.items():
            if count > 1:
                violations.append(f"{driver}: {count} blocks on {day} (max 1 per day)")
    
    return violations


# Example usage:
if __name__ == "__main__":
    # Test with sample data
    df = pd.read_csv('/home/ubuntu/last_week_schedule.csv')
    
    print("=" * 80)
    print("SCHEDULE VALIDATION")
    print("=" * 80)
    
    violations = validate_schedule(df)
    if violations:
        print("\n❌ VIOLATIONS FOUND:")
        for v in violations:
            print(f"  • {v}")
    else:
        print("\n✅ No violations found")
    
    print("\n" + "=" * 80)
    print("ACTUAL WORK DAYS BY DRIVER:")
    print("=" * 80)
    
    work_days = calculate_actual_work_days(df)
    for driver, days in sorted(work_days.items(), key=lambda x: x[1], reverse=True):
        status = "⚠️" if days > 6 else "✅"
        print(f"{status} {driver:30} {days} days")


# ============================================================================
# BASE TIME CONTRACT FUNCTIONS
# ============================================================================

def load_base_contracts(contracts_file='base_time_contracts.json'):
    """
    Load base contract times from JSON file.
    
    Returns:
        dict: Contract data with solo1 and solo2 contracts
    """
    import json
    import os
    
    if not os.path.exists(contracts_file):
        print(f"Warning: {contracts_file} not found")
        return None
    
    with open(contracts_file, 'r') as f:
        return json.load(f)


def get_all_base_times():
    """
    Get all base contract times as a simple list.
    
    Returns:
        list: List of dicts with contract info
    """
    contracts = load_base_contracts()
    if not contracts:
        return []
    
    all_contracts = []
    
    # Solo1 contracts
    for contract in contracts['contracts']['solo1']:
        all_contracts.append({
            'contract_id': contract['contract_id'],
            'start_time': contract['start_time'],
            'tractor': contract['tractor'],
            'type': 'Solo1',
            'duration_hours': 14
        })
    
    # Solo2 contracts
    for contract in contracts['contracts']['solo2']:
        all_contracts.append({
            'contract_id': contract['contract_id'],
            'start_time': contract['start_time'],
            'tractor': contract['tractor'],
            'type': 'Solo2',
            'duration_hours': 38
        })
    
    return all_contracts


def display_base_times():
    """
    Display all base contract times in table format.
    """
    contracts = load_base_contracts()
    if not contracts:
        print("No base contracts found")
        return
    
    print("=" * 70)
    print("BASE CONTRACT TIMES")
    print("=" * 70)
    
    # Solo1
    print("\n🚛 SOLO1 CONTRACTS (10 contracts):")
    print("-" * 70)
    print(f"{'#':<4} {'Start Time':<12} {'Tractor':<15} {'Duration'}")
    print("-" * 70)
    
    for idx, contract in enumerate(contracts['contracts']['solo1'], 1):
        print(f"{idx:<4} {contract['start_time']:<12} {contract['tractor']:<15} {contract['duration_hours']}h")
    
    # Solo2
    print("\n" + "=" * 70)
    print("\n🚛🚛 SOLO2 CONTRACTS (8 contracts):")
    print("-" * 70)
    print(f"{'#':<4} {'Start Time':<12} {'Tractor':<15} {'Duration'}")
    print("-" * 70)
    
    for idx, contract in enumerate(contracts['contracts']['solo2'], 1):
        print(f"{idx:<4} {contract['start_time']:<12} {contract['tractor']:<15} {contract['duration_hours']}h")
    
    print("\n" + "=" * 70)
    print(f"TOTAL: {contracts['total_contracts']} base contracts")
    print("=" * 70)


def get_contract_by_time_and_tractor(start_time, tractor):
    """
    Find a specific contract by start time and tractor.
    
    Args:
        start_time (str): Start time (e.g., "16:30")
        tractor (str): Tractor name (e.g., "Tractor_1")
    
    Returns:
        dict: Contract info or None if not found
    """
    all_contracts = get_all_base_times()
    
    for contract in all_contracts:
        if contract['start_time'] == start_time and contract['tractor'] == tractor:
            return contract
    
    return None


def get_contracts_by_time(start_time):
    """
    Get all contracts at a specific start time.
    IMPORTANT: Returns a LIST because multiple tractors can have same time.
    
    Args:
        start_time (str): Start time (e.g., "20:30")
    
    Returns:
        list: List of contracts at that time
    """
    all_contracts = get_all_base_times()
    
    return [c for c in all_contracts if c['start_time'] == start_time]


def get_contracts_by_type(solo_type):
    """
    Get all contracts of a specific type.
    
    Args:
        solo_type (str): "Solo1" or "Solo2"
    
    Returns:
        list: List of contracts of that type
    """
    all_contracts = get_all_base_times()
    
    return [c for c in all_contracts if c['type'] == solo_type]



def calculate_block_end_time(start_datetime, solo_type):
    """
    Calculate block end time from start time + duration.
    
    Solo1: START + 14 hours
    Solo2: START + 38 hours
    
    Args:
        start_datetime: datetime object or string "YYYY-MM-DD HH:MM:SS"
        solo_type: "Solo1" or "Solo2"
    
    Returns:
        datetime: End time
    """
    from datetime import datetime, timedelta
    
    # Convert string to datetime if needed
    if isinstance(start_datetime, str):
        start_datetime = datetime.strptime(start_datetime, "%Y-%m-%d %H:%M:%S")
    
    # Add duration
    if solo_type == "Solo1":
        duration = timedelta(hours=14)
    elif solo_type == "Solo2":
        duration = timedelta(hours=38)
    else:
        raise ValueError(f"Unknown solo_type: {solo_type}")
    
    return start_datetime + duration


def get_block_times(df_row):
    """
    Get start and end times for a block row.
    
    CRITICAL: Now uses Operator ID to determine contract time.
    This works for BOTH block-level and trip-level data.
    
    Args:
        df_row: DataFrame row with 'Operator ID' and date info
    
    Returns:
        tuple: (start_datetime, end_datetime)
    """
    from datetime import datetime
    
    # Try to use Operator ID first (NEW METHOD)
    if 'Operator ID' in df_row and pd.notna(df_row['Operator ID']):
        # Extract date from row
        if 'start_datetime' in df_row:
            date_str = df_row['start_datetime']
            if isinstance(date_str, str):
                date_obj = datetime.strptime(date_str.split()[0], "%Y-%m-%d")
            else:
                date_obj = date_str
        elif 'Stop 1 Planned Arrival Date' in df_row:
            date_str = df_row['Stop 1 Planned Arrival Date']
            date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        else:
            # Fallback to old method
            return get_block_times_legacy(df_row)
        
        # Use Operator ID to get contract times
        start_dt, end_dt = get_block_times_from_operator_id(
            df_row['Operator ID'],
            date_obj.strftime("%Y-%m-%d")
        )
        
        if start_dt and end_dt:
            return (start_dt, end_dt)
    
    # Fallback to old method if Operator ID not available
    return get_block_times_legacy(df_row)


def get_block_times_legacy(df_row):
    """
    LEGACY: Get start and end times using start_datetime column.
    
    This is the OLD method that doesn't work correctly on Fridays
    when schedule contains mixed block/trip data.
    
    Args:
        df_row: DataFrame row with 'start_datetime' and 'solo_type'
    
    Returns:
        tuple: (start_datetime, end_datetime)
    """
    from datetime import datetime
    
    start_dt = df_row['start_datetime']
    if isinstance(start_dt, str):
        start_dt = datetime.strptime(start_dt, "%Y-%m-%d %H:%M:%S")
    
    end_dt = calculate_block_end_time(start_dt, df_row['solo_type'])
    
    return (start_dt, end_dt)



def parse_operator_id(operator_id):
    """
    Parse Operator ID to extract solo type and tractor.
    
    Format: FTIM_MKC_Solo1_Tractor_9_d2
    Extracts: Solo1, Tractor_9
    Ignores: d1, d2, FTIM_MKC
    
    Args:
        operator_id: String like "FTIM_MKC_Solo1_Tractor_9_d2"
    
    Returns:
        dict: {'solo_type': 'Solo1', 'tractor': 'Tractor_9'}
        or None if parsing fails
    """
    import re
    
    if not operator_id or not isinstance(operator_id, str):
        return None
    
    # Extract Solo type (Solo1 or Solo2)
    solo_match = re.search(r'(Solo[12])', operator_id)
    solo_type = solo_match.group(1) if solo_match else None
    
    # Extract Tractor number
    tractor_match = re.search(r'(Tractor_\d+)', operator_id)
    tractor = tractor_match.group(1) if tractor_match else None
    
    if not solo_type or not tractor:
        return None
    
    return {
        'solo_type': solo_type,
        'tractor': tractor
    }


def get_contract_from_operator_id(operator_id):
    """
    Get contract details from Operator ID.
    
    This is the KEY function for handling both:
    - Block-level data (next week, not opened yet)
    - Trip-level data (current week, already working)
    
    Both have Operator ID, so we can always find the contract time.
    
    Args:
        operator_id: String like "FTIM_MKC_Solo1_Tractor_9_d2"
    
    Returns:
        dict: Contract details including start_time, duration, etc.
        or None if not found
    
    Example:
        contract = get_contract_from_operator_id("FTIM_MKC_Solo1_Tractor_9_d2")
        # Returns: {
        #   'contract_id': 'SOLO1_16:30_T9',
        #   'start_time': '16:30',
        #   'tractor': 'Tractor_9',
        #   'type': 'Solo1',
        #   'duration_hours': 14
        # }
    """
    parsed = parse_operator_id(operator_id)
    if not parsed:
        return None
    
    solo_type = parsed['solo_type']
    tractor = parsed['tractor']
    
    # Load contracts
    contracts_data = load_base_contracts()
    
    # Search in correct solo type section
    solo_key = solo_type.lower()  # 'solo1' or 'solo2'
    
    if solo_key not in contracts_data['contracts']:
        return None
    
    for contract in contracts_data['contracts'][solo_key]:
        if contract['tractor'] == tractor:
            return contract
    
    return None


def get_block_times_from_operator_id(operator_id, date_str):
    """
    Calculate block start and end times from Operator ID and date.
    
    This works for BOTH block-level and trip-level data because
    Operator ID always tells us the contract time.
    
    Args:
        operator_id: String like "FTIM_MKC_Solo1_Tractor_9_d2"
        date_str: Date string like "2025-11-09" or "Sunday"
    
    Returns:
        tuple: (start_datetime, end_datetime)
        or (None, None) if contract not found
    
    Example:
        start, end = get_block_times_from_operator_id(
            "FTIM_MKC_Solo1_Tractor_9_d2",
            "2025-11-09"
        )
        # Returns: (2025-11-09 16:30:00, 2025-11-10 06:30:00)
    """
    from datetime import datetime, timedelta
    
    contract = get_contract_from_operator_id(operator_id)
    if not contract:
        return (None, None)
    
    # Parse date
    if isinstance(date_str, str):
        # Try parsing as date
        try:
            if '-' in date_str:
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
            else:
                # Day name like "Sunday" - need more context
                # For now, return None
                return (None, None)
        except:
            return (None, None)
    else:
        date_obj = date_str
    
    # Parse contract start time
    start_time_str = contract['start_time']
    hour, minute = map(int, start_time_str.split(':'))
    
    # Create start datetime
    start_dt = date_obj.replace(hour=hour, minute=minute, second=0, microsecond=0)
    
    # Calculate end datetime
    duration = timedelta(hours=contract['duration_hours'])
    end_dt = start_dt + duration
    
    return (start_dt, end_dt)
