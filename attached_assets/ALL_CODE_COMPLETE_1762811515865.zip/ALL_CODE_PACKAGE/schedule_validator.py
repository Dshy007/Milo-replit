"""
Master Schedule Validation Engine
Comprehensive DOT compliance checking with cross-week support
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import json

class ScheduleValidator:
    """
    Master validation engine for driver schedules.
    Checks all DOT regulations including cross-week transitions.
    """
    
    def __init__(self, last_week_file: str, this_week_file: str):
        """
        Initialize validator with schedule files.
        
        Args:
            last_week_file: Path to last week's schedule CSV
            this_week_file: Path to this week's schedule CSV
        """
        self.last_week_df = self._load_schedule(last_week_file, 'last_week')
        self.this_week_df = self._load_schedule(this_week_file, 'this_week')
        self.violations = []
        
    def _load_schedule(self, filepath: str, week_label: str) -> pd.DataFrame:
        """Load and standardize schedule file."""
        df = pd.read_csv(filepath)
        
        # Standardize driver column name
        if 'assigned_driver' in df.columns:
            df['Driver Name'] = df['assigned_driver']
        
        # Parse datetime if needed
        if 'start_datetime' not in df.columns:
            if 'Stop 1 Planned Arrival Date' in df.columns:
                df['start_datetime'] = pd.to_datetime(
                    df['Stop 1 Planned Arrival Date'] + ' ' + df['Stop 1 Planned Arrival Time'],
                    format='%m/%d/%Y %H:%M'
                )
            else:
                df['start_datetime'] = pd.to_datetime(df['start_datetime'])
        
        return df
    
    def calculate_block_times(self, block_row: pd.Series) -> Tuple[datetime, datetime]:
        """
        Calculate actual start and stop times for a block.
        
        Returns:
            (actual_start_time, scheduled_stop_time)
        """
        # Use START + duration (not END - duration)
        # Each contract time has 10-hour rest BUILT IN
        from schedule_utils import get_block_times
        return get_block_times(block_row)
    
    def calculate_actual_work_days(self, driver_blocks: pd.DataFrame) -> int:
        """
        Calculate actual calendar days worked (not just block count).
        Solo1 = 1 day, Solo2 = 2 days.
        
        This was the CRITICAL bug - counting blocks instead of days.
        """
        total_days = 0
        for _, block in driver_blocks.iterrows():
            if block['solo_type'] == 'Solo2':
                total_days += 2
            else:
                total_days += 1
        return total_days
    
    def get_calendar_days_worked(self, driver_blocks: pd.DataFrame) -> List[datetime]:
        """
        Get list of unique calendar days a driver works.
        Accounts for Solo2 spanning 2 days.
        """
        days_worked = set()
        
        for _, block in driver_blocks.iterrows():
            start, stop = self.calculate_block_times(block)
            
            # Add all calendar days between start and stop
            current_day = start.date()
            end_day = stop.date()
            
            while current_day <= end_day:
                days_worked.add(current_day)
                current_day += timedelta(days=1)
        
        return sorted(list(days_worked))
    
    def validate_34hour_cross_week(self) -> List[Dict]:
        """
        CRITICAL: Check 34-hour reset between last week and this week.
        This was the missing validation that caused Carlos's violation.
        """
        violations = []
        
        # Get drivers who worked BOTH weeks
        drivers_last = set(self.last_week_df['Driver Name'].unique())
        drivers_this = set(self.this_week_df['Driver Name'].unique())
        drivers_both = drivers_last & drivers_this
        
        for driver in drivers_both:
            # Get last block from last week
            last_week_blocks = self.last_week_df[
                self.last_week_df['Driver Name'] == driver
            ].sort_values('start_datetime')
            
            if len(last_week_blocks) == 0:
                continue
            
            last_block = last_week_blocks.iloc[-1]
            _, last_week_end = self.calculate_block_times(last_block)
            
            # Get first block from this week
            this_week_blocks = self.this_week_df[
                self.this_week_df['Driver Name'] == driver
            ].sort_values('start_datetime')
            
            if len(this_week_blocks) == 0:
                continue
            
            first_block = this_week_blocks.iloc[0]
            this_week_start, _ = self.calculate_block_times(first_block)
            
            # Calculate reset
            reset_hours = (this_week_start - last_week_end).total_seconds() / 3600
            
            if reset_hours < 34:
                violations.append({
                    'type': 'cross_week_34hour',
                    'driver': driver,
                    'last_week_block': last_block['Block ID'],
                    'this_week_block': first_block['Block ID'],
                    'last_week_end': last_week_end,
                    'this_week_start': this_week_start,
                    'reset_hours': reset_hours,
                    'shortage': 34 - reset_hours,
                    'severity': 'CRITICAL'
                })
        
        return violations
    
    def validate_34hour_within_week(self) -> List[Dict]:
        """Check 34-hour reset between consecutive blocks within the same week."""
        violations = []
        
        for driver in self.this_week_df['Driver Name'].unique():
            driver_blocks = self.this_week_df[
                self.this_week_df['Driver Name'] == driver
            ].sort_values('start_datetime')
            
            if len(driver_blocks) < 2:
                continue
            
            blocks_info = []
            for _, block in driver_blocks.iterrows():
                start, stop = self.calculate_block_times(block)
                blocks_info.append({
                    'block_id': block['Block ID'],
                    'start': start,
                    'stop': stop,
                    'type': block['solo_type']
                })
            
            # Check consecutive blocks
            for i in range(len(blocks_info) - 1):
                block1 = blocks_info[i]
                block2 = blocks_info[i + 1]
                
                reset_hours = (block2['start'] - block1['stop']).total_seconds() / 3600
                
                if reset_hours < 34:
                    violations.append({
                        'type': 'within_week_34hour',
                        'driver': driver,
                        'block1_id': block1['block_id'],
                        'block2_id': block2['block_id'],
                        'block1_stop': block1['stop'],
                        'block2_start': block2['start'],
                        'reset_hours': reset_hours,
                        'shortage': 34 - reset_hours,
                        'severity': 'HIGH'
                    })
        
        return violations
    
    def validate_rolling_6day(self) -> List[Dict]:
        """
        Check 6-day rolling pattern using ACTUAL calendar days worked.
        Fixed to count days, not blocks.
        """
        violations = []
        
        for driver in self.this_week_df['Driver Name'].unique():
            driver_blocks = self.this_week_df[
                self.this_week_df['Driver Name'] == driver
            ].sort_values('start_datetime')
            
            if len(driver_blocks) == 0:
                continue
            
            # Get all calendar days worked
            days_worked = self.get_calendar_days_worked(driver_blocks)
            
            if len(days_worked) == 0:
                continue
            
            # Check for consecutive streaks
            max_streak = 1
            current_streak = 1
            
            for i in range(1, len(days_worked)):
                if (days_worked[i] - days_worked[i-1]).days == 1:
                    current_streak += 1
                    max_streak = max(max_streak, current_streak)
                else:
                    current_streak = 1
            
            if max_streak > 6:
                violations.append({
                    'type': 'rolling_6day',
                    'driver': driver,
                    'consecutive_days': max_streak,
                    'days_worked': [d.strftime('%a %m/%d') for d in days_worked],
                    'excess_days': max_streak - 6,
                    'severity': 'CRITICAL'
                })
        
        return violations
    
    def validate_one_block_per_day(self) -> List[Dict]:
        """Check that no driver has multiple blocks on the same calendar day."""
        violations = []
        
        for driver in self.this_week_df['Driver Name'].unique():
            driver_blocks = self.this_week_df[
                self.this_week_df['Driver Name'] == driver
            ].sort_values('start_datetime')
            
            day_counts = {}
            
            for _, block in driver_blocks.iterrows():
                start, stop = self.calculate_block_times(block)
                
                # Check all days this block covers
                current_day = start.date()
                end_day = stop.date()
                
                while current_day <= end_day:
                    if current_day not in day_counts:
                        day_counts[current_day] = []
                    day_counts[current_day].append(block['Block ID'])
                    current_day += timedelta(days=1)
            
            # Find days with multiple blocks
            for day, blocks in day_counts.items():
                if len(blocks) > 1:
                    violations.append({
                        'type': 'multiple_blocks_per_day',
                        'driver': driver,
                        'date': day,
                        'block_ids': blocks,
                        'block_count': len(blocks),
                        'severity': 'CRITICAL'
                    })
        
        return violations
    
    def validate_10hour_reset(self) -> List[Dict]:
        """Check 10-hour minimum rest between blocks."""
        violations = []
        
        for driver in self.this_week_df['Driver Name'].unique():
            driver_blocks = self.this_week_df[
                self.this_week_df['Driver Name'] == driver
            ].sort_values('start_datetime')
            
            if len(driver_blocks) < 2:
                continue
            
            blocks_info = []
            for _, block in driver_blocks.iterrows():
                start, stop = self.calculate_block_times(block)
                blocks_info.append({
                    'block_id': block['Block ID'],
                    'start': start,
                    'stop': stop
                })
            
            for i in range(len(blocks_info) - 1):
                block1 = blocks_info[i]
                block2 = blocks_info[i + 1]
                
                rest_hours = (block2['start'] - block1['stop']).total_seconds() / 3600
                
                if rest_hours < 10:
                    violations.append({
                        'type': '10hour_rest',
                        'driver': driver,
                        'block1_id': block1['block_id'],
                        'block2_id': block2['block_id'],
                        'rest_hours': rest_hours,
                        'shortage': 10 - rest_hours,
                        'severity': 'CRITICAL'
                    })
        
        return violations
    
    def run_all_validations(self) -> Dict:
        """Run all validation checks and return comprehensive report."""
        print("=" * 80)
        print("RUNNING COMPREHENSIVE SCHEDULE VALIDATION")
        print("=" * 80)
        
        results = {}
        
        # 1. Cross-week 34-hour (CRITICAL - was missing)
        print("\n1. Checking cross-week 34-hour resets...")
        results['cross_week_34hour'] = self.validate_34hour_cross_week()
        print(f"   Found {len(results['cross_week_34hour'])} violations")
        
        # 2. Within-week 34-hour
        print("\n2. Checking within-week 34-hour resets...")
        results['within_week_34hour'] = self.validate_34hour_within_week()
        print(f"   Found {len(results['within_week_34hour'])} violations")
        
        # 3. Rolling 6-day (FIXED - now counts days not blocks)
        print("\n3. Checking rolling 6-day pattern...")
        results['rolling_6day'] = self.validate_rolling_6day()
        print(f"   Found {len(results['rolling_6day'])} violations")
        
        # 4. One block per day
        print("\n4. Checking one block per day rule...")
        results['one_block_per_day'] = self.validate_one_block_per_day()
        print(f"   Found {len(results['one_block_per_day'])} violations")
        
        # 5. 10-hour rest
        print("\n5. Checking 10-hour minimum rest...")
        results['10hour_rest'] = self.validate_10hour_reset()
        print(f"   Found {len(results['10hour_rest'])} violations")
        
        # Calculate totals
        total_violations = sum(len(v) for v in results.values())
        critical_violations = sum(
            len([x for x in v if x.get('severity') == 'CRITICAL'])
            for v in results.values()
        )
        
        results['summary'] = {
            'total_violations': total_violations,
            'critical_violations': critical_violations,
            'by_type': {k: len(v) for k, v in results.items() if k != 'summary'}
        }
        
        return results
    
    def print_violations_report(self, results: Dict):
        """Print human-readable violations report."""
        print("\n" + "=" * 80)
        print("VALIDATION REPORT")
        print("=" * 80)
        
        summary = results['summary']
        print(f"\nTotal Violations: {summary['total_violations']}")
        print(f"Critical Violations: {summary['critical_violations']}")
        
        print("\nBreakdown by Type:")
        for vtype, count in summary['by_type'].items():
            print(f"  • {vtype}: {count}")
        
        # Print details for each violation type
        for vtype, violations in results.items():
            if vtype == 'summary' or len(violations) == 0:
                continue
            
            print(f"\n{'=' * 80}")
            print(f"{vtype.upper().replace('_', ' ')} VIOLATIONS:")
            print("=" * 80)
            
            for v in violations:
                print(f"\n❌ Driver: {v['driver']}")
                print(f"   Severity: {v.get('severity', 'MEDIUM')}")
                
                if vtype == 'cross_week_34hour':
                    print(f"   Last week ended: {v['last_week_end'].strftime('%a %m/%d @ %H:%M')}")
                    print(f"   This week starts: {v['this_week_start'].strftime('%a %m/%d @ %H:%M')}")
                    print(f"   Reset: {v['reset_hours']:.1f}h (need 34h, short {v['shortage']:.1f}h)")
                
                elif vtype == 'within_week_34hour':
                    print(f"   Block 1: {v['block1_id']} ends {v['block1_stop'].strftime('%a @ %H:%M')}")
                    print(f"   Block 2: {v['block2_id']} starts {v['block2_start'].strftime('%a @ %H:%M')}")
                    print(f"   Reset: {v['reset_hours']:.1f}h (need 34h, short {v['shortage']:.1f}h)")
                
                elif vtype == 'rolling_6day':
                    print(f"   Consecutive days: {v['consecutive_days']} (limit: 6)")
                    print(f"   Days worked: {', '.join(v['days_worked'])}")
                
                elif vtype == 'one_block_per_day':
                    print(f"   Date: {v['date'].strftime('%a %m/%d')}")
                    print(f"   Blocks: {', '.join(v['block_ids'])}")
                
                elif vtype == '10hour_rest':
                    print(f"   Rest: {v['rest_hours']:.1f}h (need 10h, short {v['shortage']:.1f}h)")
        
        print("\n" + "=" * 80)
        
        if summary['total_violations'] == 0:
            print("✅ ALL VALIDATIONS PASSED")
        else:
            print(f"⚠️  {summary['total_violations']} VIOLATIONS FOUND")
        
        print("=" * 80)


if __name__ == "__main__":
    # Test with current schedules
    validator = ScheduleValidator(
        last_week_file='/home/ubuntu/last_week_oct26_nov1.csv',
        this_week_file='/home/ubuntu/last_week_schedule.csv'
    )
    
    results = validator.run_all_validations()
    validator.print_violations_report(results)
    
    # Save results to JSON
    with open('/home/ubuntu/validation_results.json', 'w') as f:
        # Convert datetime objects to strings for JSON serialization
        json_results = {}
        for key, violations in results.items():
            if key == 'summary':
                json_results[key] = violations
            else:
                json_results[key] = []
                for v in violations:
                    v_copy = v.copy()
                    for k, val in v_copy.items():
                        if isinstance(val, (datetime, pd.Timestamp)):
                            v_copy[k] = val.isoformat()
                        elif hasattr(val, 'isoformat'):  # date objects
                            v_copy[k] = val.isoformat()
                        elif isinstance(val, list) and len(val) > 0:
                            v_copy[k] = [d.isoformat() if hasattr(d, 'isoformat') else str(d) for d in val]
                    json_results[key].append(v_copy)
        
        json.dump(json_results, f, indent=2)
    
    print("\n✅ Results saved to validation_results.json")
