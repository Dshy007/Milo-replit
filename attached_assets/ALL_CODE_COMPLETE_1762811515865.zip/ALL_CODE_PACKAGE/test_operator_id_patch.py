#!/usr/bin/env python3.11
"""
Comprehensive test suite for Operator ID patch
Tests all new functions and validates the fix
"""

import pandas as pd
from datetime import datetime
from schedule_utils import (
    parse_operator_id,
    get_contract_from_operator_id,
    get_block_times_from_operator_id,
    get_block_times,
    display_base_times
)

def test_parse_operator_id():
    """Test Operator ID parsing"""
    print("=" * 70)
    print("TEST 1: Parse Operator ID")
    print("=" * 70)
    
    test_cases = [
        "FTIM_MKC_Solo1_Tractor_9_d2",
        "FTIM_MKC_Solo2_Tractor_4_d1",
        "FTIM_MKC_Solo1_Tractor_1_d1",
        "FTIM_MKC_Solo2_Tractor_7_d2",
    ]
    
    for op_id in test_cases:
        parsed = parse_operator_id(op_id)
        print(f"  {op_id}")
        print(f"    → Solo: {parsed['solo_type']}, Tractor: {parsed['tractor']}")
    
    print("  ✅ All parsing tests passed\n")


def test_contract_lookup():
    """Test contract lookup from Operator ID"""
    print("=" * 70)
    print("TEST 2: Contract Lookup")
    print("=" * 70)
    
    test_cases = [
        ("FTIM_MKC_Solo1_Tractor_9_d2", "SOLO1_16:30_T9", "16:30", 14),
        ("FTIM_MKC_Solo2_Tractor_4_d1", "SOLO2_08:30_T4", "08:30", 38),
        ("FTIM_MKC_Solo1_Tractor_1_d1", "SOLO1_16:30_T1", "16:30", 14),
        ("FTIM_MKC_Solo2_Tractor_7_d2", "SOLO2_16:30_T7", "16:30", 38),
    ]
    
    for op_id, expected_id, expected_start, expected_duration in test_cases:
        contract = get_contract_from_operator_id(op_id)
        
        assert contract is not None, f"Contract not found for {op_id}"
        assert contract['contract_id'] == expected_id, f"Wrong contract ID for {op_id}"
        assert contract['start_time'] == expected_start, f"Wrong start time for {op_id}"
        assert contract['duration_hours'] == expected_duration, f"Wrong duration for {op_id}"
        
        print(f"  {op_id}")
        print(f"    → {contract['contract_id']}, {contract['start_time']}, {contract['duration_hours']}h")
    
    print("  ✅ All contract lookup tests passed\n")


def test_block_times_calculation():
    """Test block time calculation from Operator ID"""
    print("=" * 70)
    print("TEST 3: Block Times Calculation")
    print("=" * 70)
    
    test_cases = [
        ("FTIM_MKC_Solo1_Tractor_9_d2", "2025-11-09", "2025-11-09 16:30:00", "2025-11-10 06:30:00", 14),
        ("FTIM_MKC_Solo2_Tractor_4_d1", "2025-11-09", "2025-11-09 08:30:00", "2025-11-10 22:30:00", 38),
        ("FTIM_MKC_Solo1_Tractor_1_d1", "2025-11-10", "2025-11-10 16:30:00", "2025-11-11 06:30:00", 14),
        ("FTIM_MKC_Solo2_Tractor_7_d2", "2025-11-11", "2025-11-11 16:30:00", "2025-11-13 06:30:00", 38),
    ]
    
    for op_id, date, expected_start, expected_end, expected_duration in test_cases:
        start, end = get_block_times_from_operator_id(op_id, date)
        
        assert start is not None, f"Start time not calculated for {op_id}"
        assert end is not None, f"End time not calculated for {op_id}"
        
        duration = (end - start).total_seconds() / 3600
        assert duration == expected_duration, f"Wrong duration for {op_id}: {duration}h"
        
        print(f"  {op_id} on {date}")
        print(f"    → {start} to {end} ({duration}h)")
    
    print("  ✅ All block times calculation tests passed\n")


def test_get_block_times_integration():
    """Test get_block_times with DataFrame rows"""
    print("=" * 70)
    print("TEST 4: get_block_times Integration")
    print("=" * 70)
    
    # Simulate CSV rows
    test_rows = [
        {
            'Operator ID': 'FTIM_MKC_Solo1_Tractor_9_d2',
            'start_datetime': '2025-11-09 16:30:00',
            'solo_type': 'Solo1',
            'Driver Name': 'John Doe'
        },
        {
            'Operator ID': 'FTIM_MKC_Solo2_Tractor_4_d1',
            'start_datetime': '2025-11-09 08:30:00',
            'solo_type': 'Solo2',
            'Driver Name': 'Jane Smith'
        },
        {
            'Operator ID': 'FTIM_MKC_Solo1_Tractor_1_d1',
            'Stop 1 Planned Arrival Date': '11/09/2025',
            'solo_type': 'Solo1',
            'Driver Name': 'Bob Johnson'
        }
    ]
    
    for row_dict in test_rows:
        row = pd.Series(row_dict)
        start, end = get_block_times(row)
        
        assert start is not None, f"Start time not calculated for {row['Operator ID']}"
        assert end is not None, f"End time not calculated for {row['Operator ID']}"
        
        duration = (end - start).total_seconds() / 3600
        expected_duration = 14 if row['solo_type'] == 'Solo1' else 38
        assert duration == expected_duration, f"Wrong duration: {duration}h"
        
        print(f"  {row['Driver Name']} ({row['Operator ID']})")
        print(f"    → {start} to {end} ({duration}h)")
    
    print("  ✅ All integration tests passed\n")


def test_all_contracts_accessible():
    """Test that all 17 contracts are accessible"""
    print("=" * 70)
    print("TEST 5: All 17 Contracts Accessible")
    print("=" * 70)
    
    # Solo1: Tractors 1,2,3,4,5,6,7,8,9,10 (10 total)
    solo1_tractors = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    # Solo2: Tractors 1,2,3,4,5,6,7 (7 total)
    solo2_tractors = [1, 2, 3, 4, 5, 6, 7]
    
    print(f"  Testing {len(solo1_tractors)} Solo1 contracts...")
    for tractor_num in solo1_tractors:
        op_id = f"FTIM_MKC_Solo1_Tractor_{tractor_num}_d1"
        contract = get_contract_from_operator_id(op_id)
        assert contract is not None, f"Solo1 Tractor_{tractor_num} not found"
        assert contract['type'] == 'Solo1', f"Wrong type for Tractor_{tractor_num}"
        assert contract['duration_hours'] == 14, f"Wrong duration for Solo1 Tractor_{tractor_num}"
    
    print(f"  ✅ All {len(solo1_tractors)} Solo1 contracts found")
    
    print(f"  Testing {len(solo2_tractors)} Solo2 contracts...")
    for tractor_num in solo2_tractors:
        op_id = f"FTIM_MKC_Solo2_Tractor_{tractor_num}_d1"
        contract = get_contract_from_operator_id(op_id)
        assert contract is not None, f"Solo2 Tractor_{tractor_num} not found"
        assert contract['type'] == 'Solo2', f"Wrong type for Tractor_{tractor_num}"
        assert contract['duration_hours'] == 38, f"Wrong duration for Solo2 Tractor_{tractor_num}"
    
    print(f"  ✅ All {len(solo2_tractors)} Solo2 contracts found")
    print(f"  ✅ Total: {len(solo1_tractors) + len(solo2_tractors)} contracts verified\n")


def test_d1_d2_ignored():
    """Test that d1/d2 suffixes are properly ignored"""
    print("=" * 70)
    print("TEST 6: d1/d2 Suffixes Ignored")
    print("=" * 70)
    
    # Same tractor with different d1/d2 should return same contract
    test_pairs = [
        ("FTIM_MKC_Solo1_Tractor_9_d1", "FTIM_MKC_Solo1_Tractor_9_d2"),
        ("FTIM_MKC_Solo2_Tractor_4_d1", "FTIM_MKC_Solo2_Tractor_4_d2"),
    ]
    
    for op_id1, op_id2 in test_pairs:
        contract1 = get_contract_from_operator_id(op_id1)
        contract2 = get_contract_from_operator_id(op_id2)
        
        assert contract1['contract_id'] == contract2['contract_id'], \
            f"d1/d2 not ignored: {op_id1} vs {op_id2}"
        
        print(f"  {op_id1}")
        print(f"  {op_id2}")
        print(f"    → Both return: {contract1['contract_id']} ✓")
    
    print("  ✅ d1/d2 suffixes properly ignored\n")


def run_all_tests():
    """Run all tests"""
    print("\n")
    print("*" * 70)
    print("OPERATOR ID PATCH - COMPREHENSIVE TEST SUITE")
    print("*" * 70)
    print("\n")
    
    try:
        test_parse_operator_id()
        test_contract_lookup()
        test_block_times_calculation()
        test_get_block_times_integration()
        test_all_contracts_accessible()
        test_d1_d2_ignored()
        
        print("=" * 70)
        print("✅ ALL TESTS PASSED")
        print("=" * 70)
        print("\nThe Operator ID patch is working correctly!")
        print("System is ready to handle both block-level and trip-level data.\n")
        
    except AssertionError as e:
        print("\n" + "=" * 70)
        print("❌ TEST FAILED")
        print("=" * 70)
        print(f"Error: {e}\n")
        raise


if __name__ == "__main__":
    run_all_tests()
