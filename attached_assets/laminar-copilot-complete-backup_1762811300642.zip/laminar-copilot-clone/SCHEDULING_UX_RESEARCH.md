# Scheduling UX Research: Monday.com, Homebase, Connecteam

## Key Findings

### Common UX Patterns Across All Three Platforms:

1. **Drag-and-Drop Simplicity**
   - All three use drag-and-drop for assigning employees to shifts
   - No complex configuration panels - just drag names onto time slots
   - Visual, intuitive, immediate feedback

2. **Minimal Configuration**
   - No heavy "Auto-Schedule" panels taking up screen space
   - Configuration happens inline or in small modals
   - Focus on the calendar grid, not settings

3. **Smart Recommendations**
   - Homebase: "smart recommendations" for shift assignments
   - Connecteam: Auto-fill based on availability and past schedules
   - Monday.com: Workload view shows capacity automatically

4. **Mobile-First Design**
   - Clean, simple interfaces that work on phones
   - Large touch targets
   - Minimal text, maximum visual clarity

5. **Instant Notifications**
   - Changes notify employees immediately
   - No "publish" step - changes are live
   - Real-time updates

### What Makes Them "Easy":

**Monday.com:**
- Timeline/Gantt view for visual scheduling
- Inline editing - click to change
- Color-coded status (no manual tagging)
- Templates for common schedules

**Homebase:**
- "Create schedule in minutes" promise
- Auto-copy previous week's schedule
- Availability checking built-in
- One-click shift swaps

**Connecteam:**
- Mobile app-first (not web-first)
- Open shifts that employees can claim
- Shift templates for recurring patterns
- Status updates (confirmed/rejected) inline

### What They DON'T Have:

❌ Heavy configuration panels
❌ Sliders for "max days" and "max hours"
❌ Separate "Generate Draft" buttons
❌ Warning/Violation cards taking up space
❌ Multiple steps to publish

### What They DO Have:

✅ Clean calendar grid as the main focus
✅ Drag-drop employee names onto shifts
✅ Inline warnings (red border on conflicts)
✅ Quick actions (copy week, auto-fill, templates)
✅ Minimal clicks to complete a schedule

## Recommendations for Our App:

### Remove:
1. The entire Auto-Schedule panel (too bulky)
2. Sliders for max days/hours (move to settings if needed)
3. Warning/Violation cards (show inline instead)

### Add:
1. **Quick Actions Bar** (top right):
   - "Copy Last Week" button
   - "Auto-Fill" button (one-click AI assignment)
   - "Import Blocks" button (already have)
   - "Clear Schedule" button (already have)

2. **Inline Conflict Indicators**:
   - Red border on time slots with violations
   - Tooltip on hover showing the issue
   - No separate warning panel

3. **Drag-Drop Enhancement**:
   - Already have drag-drop ✓
   - Add visual feedback (ghost preview)
   - Add "undo" button after assignment

4. **Simplified Layout**:
   - Calendar grid takes full width
   - Driver sidebar on left (already have) ✓
   - No configuration panels
   - Settings in a dropdown menu if needed

### Design Principles:
- **Clean**: Remove all unnecessary UI elements
- **Simple**: One action = one click
- **Visual**: Use colors and borders for status, not text
- **Fast**: No loading screens for simple operations
- **Intuitive**: If it needs explanation, redesign it

## Implementation Plan:

1. Remove AutoSchedulePanel component
2. Add "Auto-Fill" button to header (one-click AI assignment)
3. Move max days/hours to driver preferences (not global settings)
4. Show conflicts inline with red borders
5. Add "Copy Last Week" quick action
6. Keep drag-drop (already works well)

