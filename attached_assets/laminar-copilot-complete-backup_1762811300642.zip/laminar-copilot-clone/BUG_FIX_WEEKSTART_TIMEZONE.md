# Bug Fix: Timezone Issue in weekStartDate Calculation

## Problem Summary

**Issue:** Nov 9, 2025 blocks were not appearing in the week navigation view, even though they were successfully imported into the database.

**Root Cause:** The `getSundayOfWeek` function had a timezone bug that caused it to calculate the wrong week start date for certain dates.

## Technical Details

### The Bug

When parsing date strings like `'2025-11-09'` using `new Date()`, JavaScript treats them as **UTC midnight**. However, when calling `getDay()`, it returns the day of the week in the **local timezone**.

**Example:**
```javascript
const date = new Date('2025-11-09');  // Parsed as UTC midnight
console.log(date.toISOString());      // 2025-11-09T00:00:00.000Z
console.log(date.getDay());           // Returns 6 (Saturday) in EST timezone!
console.log(date.toString());         // Sat Nov 08 2025 19:00:00 GMT-0500
```

In the EST timezone (GMT-5), UTC midnight on Nov 9 becomes **Saturday Nov 8 at 7pm local time**. So `getDay()` returns 6 (Saturday) instead of 0 (Sunday).

### The Impact

The old `getSundayOfWeek` function would:
1. Parse '2025-11-09' as UTC midnight
2. Get day of week = 6 (Saturday in EST)
3. Subtract 6 days to find Sunday
4. Return '2025-11-03' instead of '2025-11-09'

**Result:** Nov 9 blocks were assigned `weekStartDate = '2025-11-03'` instead of `'2025-11-09'`, causing them to appear in the wrong week.

## The Fix

### Old Code (BUGGY)
```typescript
const getSundayOfWeek = (date: Date): string => {
  const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
  const sunday = new Date(date);
  sunday.setDate(date.getDate() - dayOfWeek);
  return sunday.toISOString().split('T')[0];
};

// Usage
const blockDate = new Date(block.startDate);  // ❌ Timezone issue!
const weekStartDate = getSundayOfWeek(blockDate);
```

### New Code (FIXED)
```typescript
const getSundayOfWeek = (dateStr: string): string => {
  // Parse date in local time to avoid timezone issues
  const parts = dateStr.split('-');
  const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
  
  const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
  const sunday = new Date(date);
  sunday.setDate(date.getDate() - dayOfWeek);
  
  // Format as YYYY-MM-DD
  const year = sunday.getFullYear();
  const month = String(sunday.getMonth() + 1).padStart(2, '0');
  const day = String(sunday.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Usage
const weekStartDate = getSundayOfWeek(block.startDate);  // ✓ No timezone issues!
```

### Key Changes

1. **Parse in local time:** Instead of passing a Date object, we parse the date string components directly into a local Date object
2. **Consistent formatting:** Return YYYY-MM-DD format without relying on `toISOString()` which uses UTC
3. **Direct string input:** Accept date string directly instead of Date object

## Test Results

All test cases pass with the fixed function:

```
2025-11-09 (Sunday)   → 2025-11-09 ✓
2025-11-02 (Sunday)   → 2025-11-02 ✓
2025-11-03 (Monday)   → 2025-11-02 ✓
2025-11-08 (Saturday) → 2025-11-02 ✓
2025-11-10 (Monday)   → 2025-11-09 ✓
```

## How to Apply the Fix

The code has been fixed in `server/routers.ts` (lines 268-282). To apply the fix to your existing data:

### Option 1: Re-upload CSV (Recommended)

1. Go to the Schedules page
2. Scroll to the "Import Blocks from CSV" section
3. Upload your Amazon Relay CSV file again
4. The system will:
   - Delete old blocks with incorrect weekStartDate
   - Re-import with corrected weekStartDate values
   - Nov 9 blocks will now appear in the correct week (Nov 9-15)

### Option 2: Manual Database Update (Advanced)

If you want to fix existing data without re-importing:

```sql
-- Update all blocks to recalculate weekStartDate
-- This requires running a script to recalculate each block's weekStartDate
-- Contact support for assistance
```

## Verification

After re-importing:

1. Navigate to the Schedules page
2. Check the current week (Nov 2-8, 2025)
3. Click "Next Week" to navigate to Nov 9-15, 2025
4. You should now see the Nov 9 blocks (B-V05GK3HS2 and B-B6XVT5ZDQ) appearing in that week

## Files Modified

- `server/routers.ts` (lines 268-282, 308): Fixed `getSundayOfWeek` function
- `todo.md`: Added bug fix to completed items

## Related Issues

This fix also resolves any other date-related timezone issues in the import process, ensuring all blocks are assigned to the correct week regardless of server timezone.

