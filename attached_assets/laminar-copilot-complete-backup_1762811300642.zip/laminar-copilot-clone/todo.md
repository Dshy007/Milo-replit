# Manus TODO

## Completed Features
- [x] Static marketing website clone
- [x] Homepage with hero section and features
- [x] Features page
- [x] Contact page
- [x] Pricing page
- [x] Navigation and footer
- [x] Manus branding

## Backend & Database Features
- [x] Add database support (web-db-user feature)
- [x] User authentication system
- [x] Database schema for drivers
- [x] Database schema for tractors/vehicles
- [x] Database schema for routes
- [x] Database schema for schedules
- [x] Database schema for contracts

## Core Scheduling Features
- [x] Dashboard for schedule management
- [x] Driver management (add, edit, delete drivers)
- [x] Tractor/vehicle management
- [ ] Route upload from Amazon Relay (CSV/Excel import)
- [ ] Weekly schedule builder
- [ ] Drag-and-drop schedule interface
- [ ] Driver availability calendar
- [ ] Tractor availability tracking
- [ ] Driver preferences management
- [ ] Automated schedule generation algorithm

## Communication Features
- [ ] SMS notification system for drivers
- [ ] Email notifications
- [ ] Driver confirmation tracking
- [ ] Manager alerts for unconfirmed shifts

## Additional Features
- [ ] Audit panel for risk management
- [ ] Analytics and reporting
- [ ] Contract management (Solo 1, Solo 2)
- [ ] SCAC code and domicile tracking
- [ ] Time-off request management
- [ ] Maintenance scheduling
- [ ] Real-time route reallocation

## UI/UX Improvements
- [ ] Protected routes (login required)
- [ ] User profile management
- [ ] Settings page
- [ ] Mobile responsive dashboard



## Critical Missing Features (Production-Ready)
- [x] Weekly schedule calendar view with drag-and-drop
- [x] CSV/Excel import for drivers and existing schedules
- [ ] Amazon Relay route import integration
- [x] HOS compliance validation (10-hour rest periods)
- [x] Solo1/Solo2 contract block assignment logic
- [ ] Driver availability calendar (mark unavailable dates)
- [ ] SMS notification system for shift reminders
- [ ] Schedule conflict detection
- [ ] Driver swap functionality for HOS violations
- [ ] Block time slot management (00:30, 01:30, 08:30, etc.)
- [ ] Weekly schedule generation (Friday for next week)
- [ ] 34-hour reset tracking for consecutive days
- [ ] Part-time driver special schedules (Firas, Tareef patterns)



## Real-Time Notifications (NEW REQUEST)
- [x] In-app notification system for dispatchers
- [x] Real-time notification bell/dropdown in dashboard
- [x] SMS notification integration for drivers
- [x] Notification triggers: shift assigned, shift changed, shift reminder (24h before), HOS violation detected
- [x] Notification preferences per driver
- [x] Notification history and read/unread status



## Schedule Import and Auto-Build (NEW REQUEST)
- [x] Import schedule from Excel/CSV with driver preferences
- [x] Auto-build weekly schedule based on driver preferences and type
- [x] Match historical start times from imported data
- [x] Seed database with user's actual driver roster
- [ ] Test complete workflow with real schedule data



## Bug Fixes
- [x] Fix database column name mismatch (license_number vs licenseNumber, driver_type vs driverType, etc.)



- [x] Fix CSV import validation error (name field undefined)


- [x] Improve CSV parser to handle quoted fields, commas in values, and various CSV formats


- [x] Fix CSV header mapping to handle Amazon Relay export format (First name, Last name, Email address, Mobile phone number, Relay status, Domiciles)


- [x] Skip empty rows in CSV import instead of failing entire import


- [x] Filter CSV import to only include Active and Inactive drivers (skip Onboarding)


- [x] Style inactive drivers in red color on Drivers page



## Schedule Improvements (NEW REQUEST)
- [x] Add start time import from Amazon Relay (CSV/paste)
- [x] Create tractors table with start times, driver type (Solo1/Solo2), domicile
- [ ] Fix drag-and-drop functionality on schedule page
- [ ] Separate schedule view into Solo1 and Solo2 sections
- [ ] Highlight matching start times in green when driver matches tractor schedule
- [ ] Show tractor assignments with their start times



## Bugs
- [x] Start Times import button not working (sits there without importing) - Added loading state and debug logging


- [x] Fix import dialog UI - textarea should be smaller and Import button should be visible without scrolling


- [x] Fix start times not displaying after import - data imports but page doesn't refresh


- [x] Fix start time field not saving - imports succeed but startTime column shows empty - Added missing database columns


- [x] Debug paste import - data is being pasted but not parsing correctly - Fixed vertical format parser


- [x] Auto-sort start times by contract type (Solo1 first, then Solo2) and start time
- [x] Add edit/delete buttons (pencil icon) for each tractor row
- [ ] Add manual add tractor form


- [x] Add CSV/paste import to Tractors page for bulk fleet upload
- [x] Parse Amazon Relay fleet format (Asset ID, Type, Make, Fuel, License, VIN, Location, Status)
- [x] Support vertical format like Start Times import


- [x] Fix fleet import not uploading - add debug logging and error handling


- [x] Fix fleet import parser - expecting 8 lines but data has 9 lines per tractor - Fixed to handle 7-line format


- [x] Add Fuel column to tractors table and database
- [x] Add Year column to tractors table and database
- [x] Parse Fuel and Year from pasted data during import
- [x] Remove Location column from tractors table (split Make/Model into separate columns)
- [x] Add sortable headers to tractors table (click to sort by column)



## User Feedback - Fix Sortable Headers
- [x] Fixed missing useAuth import causing page to crash
- [ ] Remove Year column from Tractors table (not needed)
- [ ] Verify sortable headers work after fixing import




## Fix Fuel Type Import
- [x] Added debug logging to see what's being extracted from combined line
- [x] Confirmed fuel is being extracted correctly (CNG/DIESEL)
- [x] Added fuel field to tRPC create/update/import mutation schemas
- [ ] Test import again to verify fuel saves to database




## Fix Dashboard Title and Clear Data
- [ ] Change dashboard title from "Laminar Copilot Clone" to "Manus" (user needs to update in Settings)
- [x] Delete all tractors from database to allow clean re-import




## Remove Year Column
- [x] Remove Year column from Tractors table display
- [x] Remove Year from sortable headers




## Replace Laminar Copilot Clone with Manus
- [x] Replaced all "Laminar Copilot" references with "Manus" in Home.tsx
- [x] Updated package.json name to "manus"
- [x] Title uses VITE_APP_TITLE env variable (user can update in Settings)




## Add Sortable Columns to Driver Management
- [x] Add sorting state (sortColumn, sortDirection) to Drivers page
- [x] Add click handlers to column headers (Name, Email, Phone, License #, Status)
- [x] Implement sorting logic for driver data
- [x] Add arrow indicators (↑/↓) to show sort direction




## Fix Start Times Page
- [x] Delete all trucks from Start Times table (tractors table cleared)
- [x] Add sortable columns to Start Times table
- [ ] User to test import functionality for start times




## Fix Start Times Duplicate Handling
- [x] Delete all tractors from database again
- [x] Changed import logic to always create new entries (no more updates)
- [x] Allow duplicate tractor numbers in start times (same tractor can have multiple time slots)
- [ ] User to test import with all 17 entries




## Fix Start Times Import Removing Duplicates
- [x] Import was only keeping 10 of 17 entries - was updating instead of creating
- [x] Fixed import logic - removed deduplication code
- [x] Now always creates new entries (allows same tractor with multiple start times)
- [ ] User to verify all 17 entries import correctly




## Separate Fleet Tractors and Start Times Entries
- [x] Add 'entryType' field to tractors table ('fleet' or 'start_time')
- [x] Update Fleet Management import to set entryType='fleet'
- [x] Update Start Times import to set entryType='start_time'
- [x] Update Tractors page to only show entryType='fleet' (getTractorsByUserId)
- [x] Update Start Times page to only show entryType='start_time' (getStartTimesByUserId)
- [x] Delete all existing tractors
- [ ] User to test both imports separately




## Update Schedule Grid to Use Dynamic Start Times
- [x] Replace hardcoded TIME_SLOTS with dynamic query from Start Times table
- [x] Group time slots by time + contract type (e.g., "16:30 MKC • Solo1")
- [x] Show only configured start times (not all 24 hours)
- [x] Match Amazon Relay format: Time, Location, Contract Type, 7-day grid
- [x] Validate driver type matches contract type when dragging
- [ ] User to test schedule grid with imported start times




## Fix Schedule Drag-and-Drop and Styling
- [x] Fix driver cards to be draggable (converted to useDraggable hook)
- [x] Available drivers are GREEN (working correctly)
- [x] Empty schedule slots are LIGHT RED
- [x] Assigned schedule slots are BLUE with driver name
- [x] Fixed DndContext to wrap both sidebar and schedule grid
- [ ] User to test drag-and-drop functionality (should work now)
- [ ] Add driver preference field to drivers
- [ ] Auto-populate schedule based on driver preference when dragging
- [ ] Add 10-hour break indicator/warning when scheduling




## Add Driver Type Field
- [x] driverType field already exists in drivers schema (Solo1/Solo2)
- [x] Add driver type dropdown in Add/Edit Driver form
- [x] Add preferred start time field in Add/Edit Driver form
- [ ] Update existing drivers to have a driver type
- [ ] Test drag-and-drop with driver types set

## Driver Availability Calendar (Onboarding Feature)
- [ ] Add calendar interface for setting driver availability date ranges
- [ ] Add "infinite" option (driver always available)
- [ ] Add "disable" option to temporarily disable driver
- [ ] Store availability dates in database
- [ ] Filter available drivers in schedule based on date range




## Add "Both" Driver Type Option
- [x] Add "Both" option to driver type dropdown (Solo1, Solo2, Both)
- [x] Update schema to allow "Both" as driver type
- [x] Update API validation to accept "Both"
- [x] Update drag-and-drop validation to allow "Both" drivers in any slot type




## Fix Controlled Input Error in Drivers Page
- [x] Fix "uncontrolled to controlled" error when editing drivers
- [x] Ensure all form fields have default values (not undefined)
- [x] Handle null/undefined values from database properly (use || "" for optional fields)




## Driver Availability Calendar - Days and Times
- [x] Add availableDays field to drivers table
- [x] Create driver_availability_slots table for time slots
- [x] Add day-of-week selector UI (checkboxes for Sun, Mon, Tue, Wed, Thu, Fri, Sat)
- [x] Add time picker UI with 15-minute intervals (00:00, 00:15, 00:30, etc.)
- [x] Allow multiple start times per day (automatically adds to all selected days)
- [x] Add API mutations for saving availability slots to database
- [x] Load existing availability slots when editing a driver
- [ ] Enforce 10-hour rule when scheduling (check previous shift end time)
- [ ] Filter available drivers in schedule based on day/time availability
- [ ] Show warning if assigning driver violates 10-hour break rule





## 10-Hour Break Rule Implementation
- [x] Add function to calculate shift end time based on contract type (Solo1: 14h, Solo2: 38h)
- [x] Add validation function to check if 10 hours have passed between shifts
- [x] Update drag-and-drop handler in Schedules.tsx to validate 10-hour break
- [x] Prevent assignment if 10-hour rule is violated with error toast
- [ ] Show red warning badge if driver violates 10-hour rule (visual indicator)
- [ ] Display last shift end time when hovering over driver in sidebar





## Driver Availability UX Improvements
- [x] Add "Select All Times" button to mark driver available 24/7
- [x] Add "Clear All Times" button to deselect all time slots
- [ ] Show count of selected time slots





## UI/UX Redesign - Monday.com Color Scheme
- [x] Update primary color to Monday.com purple/blue (#6161FF)
- [x] Update background to light lavender (#F6F7FB)
- [x] Update button border radius to 8px (Monday style)
- [x] Update card and component styling with purple tones
- [x] Update navigation and sidebar colors





## SaaS / Multi-Tenancy Features
- [ ] Add organization/company table to database
- [ ] Add user roles and permissions (Owner, Manager, Dispatcher, Driver)
- [ ] Implement organization-based data isolation (each AFP sees only their data)
- [ ] Create organization signup/onboarding flow
- [ ] Add subscription/billing integration (Stripe)
- [ ] Create pricing tiers (Free, Pro, Enterprise)
- [ ] Add organization settings page (company name, logo, timezone)
- [ ] Implement team member invitation system
- [ ] Add usage analytics dashboard for organization admins
- [ ] Create public marketing/landing page
- [ ] Add organization switching for users in multiple companies
- [ ] Implement API rate limiting per organization
- [ ] Add data export functionality per organization
- [ ] Create admin panel for platform management

## Subscription Tiers (Draft)
- [ ] **Free Tier**: Up to 5 drivers, 3 tractors, basic scheduling
- [ ] **Pro Tier**: Unlimited drivers/tractors, advanced scheduling, HOS compliance, API access
- [ ] **Enterprise Tier**: White-label, custom integrations, dedicated support, SLA




- [x] Add "Select All Days" button for availability calendar





## Bugs to Fix
- [x] Fix NULL message appearing during drag-and-drop in Schedules page
- [x] Fix timezone bug in getSundayOfWeek function causing incorrect weekStartDate calculation for imported blocks




- [x] Fix drag-and-drop not working in Schedules page (removed duplicate existingShifts code)





## Homepage Content & Authentication
- [x] Research competitor scheduling platforms (Monday, Asana, ClickUp, Skedulo, Deputy, When I Work)
- [x] Rewrite homepage copy to be original (not word-for-word from competitors)
- [x] Add Login button to homepage hero section
- [x] Connect Login button to redirect to Dashboard




- [x] Allow Dashboard access without authentication for testing (auth check commented out)




- [x] Remove ownerId filtering from API queries for testing (show all data)
  - Changed protectedProcedure to publicProcedure in routers.ts
  - Modified getDriversByUserId, getTractorsByUserId, getStartTimesByUserId, getSchedulesByUserId to return all data





## Future Features - Advanced HOS & Shift Management

### Load Board & Available Drivers
- [ ] Create "Available Drivers" list showing who can take extra shifts
- [ ] Filter available drivers based on:
  - [ ] Current HOS compliance (10-hour break rule)
  - [ ] Driver availability calendar (days/times they marked as available)
  - [ ] Current week's hours worked
  - [ ] 34-hour reset tracking
- [ ] "Load Board" view for unassigned shifts/routes
- [ ] One-click assign from available drivers list

### Shift Confirmation System
- [ ] Send shift notification to driver when assigned
- [ ] Driver must confirm shift within timeframe
- [ ] 20-hour pre-shift reminder if driver hasn't confirmed
- [ ] Visual status indicators:
  - [ ] Red: Driver has not responded (< 20 hours before shift)
  - [ ] Yellow: Pending confirmation (> 20 hours before shift)
  - [ ] Green: Driver confirmed shift
- [ ] Automatic escalation if no response 20 hours before shift
- [ ] Manager notification for unconfirmed shifts

### Enhanced HOS Logic
- [ ] Track cumulative hours worked per week
- [ ] 70-hour/8-day rule enforcement
- [ ] 34-hour restart tracking and automatic reset
- [ ] Consecutive days worked limit (suggest rest days)
- [ ] HOS violation warnings before assignment
- [ ] Driver fatigue score based on recent shifts
- [ ] Suggest optimal rest periods for drivers

### Notifications & Alerts
- [ ] SMS/Email notifications for shift assignments
- [ ] Push notifications for shift confirmations
- [ ] Manager alerts for:
  - [ ] Unconfirmed shifts (20-hour threshold)
  - [ ] HOS violations
  - [ ] Driver unavailability conflicts
- [ ] Driver alerts for:
  - [ ] New shift assignments
  - [ ] Upcoming shifts (24h, 12h, 2h reminders)
  - [ ] HOS compliance status

### Reporting & Analytics
- [ ] Driver utilization report (hours worked vs available)
- [ ] HOS compliance dashboard
- [ ] Shift confirmation rate metrics
- [ ] Available driver pool analytics
- [ ] Weekly/monthly hours summary per driver





## Bugs to Fix
- [x] NULL error ("Driver type null doesn't match slot type") - Fixed by treating null driverType as "Both"
- [ ] Drivers page not loading on mobile (crashes with 42 drivers)



- [x] Keep drivers in sidebar after assignment (allow assigning same driver to multiple days)





## Schedule Management Features

### Copy & Template System
- [ ] "Copy to Next Week" button - duplicate current week's schedule to next week
- [ ] "Save as Template" - save current schedule as reusable template
- [ ] "Load Template" - apply saved template to any week
- [ ] Bulk copy specific days (e.g., copy Monday's schedule to all Mondays for next 4 weeks)
- [ ] "Repeat Weekly" option when creating schedule
- [ ] Smart copy with conflict detection (warn if driver unavailable or HOS violation)

### Schedule Building Prompts
- [ ] End-of-week prompt: "Build next week's schedule?"
- [ ] Options when prompted:
  - [ ] Copy this week's schedule
  - [ ] Auto-assign based on availability
  - [ ] Start from blank schedule
  - [ ] Load from template
- [ ] Schedule ahead: Build multiple weeks in advance
- [ ] Recurring schedule patterns (e.g., same schedule every week)

### Quick Actions
- [ ] Right-click on assigned shift → "Copy to..." (select target days/times)
- [ ] Select multiple shifts → Bulk copy/move
- [ ] "Fill Week" button - auto-assign all open slots for the week
- [ ] "Clear Week" button - remove all assignments for selected week




- [x] Add confirmation dialog when dropping driver on already-assigned slot ("Replace [Driver Name]?")




- [x] Move overwrite confirmation to center of screen (use modal dialog instead of toast)





## Auto-Schedule Based on Previous Week

### Core Logic
- [ ] Import Amazon weekly schedule (blocks of time that match Start Times)
- [ ] System remembers which driver worked which **time slot** last week
- [ ] Auto-assign drivers to the **same time slots** they worked previously
- [ ] Day of week doesn't matter - only the **time range** (e.g., 08:00, 16:30)
- [ ] Time blocks always match existing Start Times in the system

### Implementation Steps
- [ ] Add "Import Amazon Schedule" button on Schedules page
- [ ] Parse Amazon schedule CSV to extract time blocks
- [ ] Match time blocks to existing Start Times (by time only, ignore day)
- [ ] Query last week's schedule to see which drivers worked which time slots
- [ ] Auto-populate current week with same driver-to-timeslot assignments
- [ ] Handle conflicts: If multiple drivers worked same time slot, show options
- [ ] Show preview before applying: "Firas → Monday 08:00 (worked this slot last week)"
- [ ] Allow manual adjustments after auto-assignment

### Example Flow
1. **Last Week:** Firas worked Monday 08:00 (Solo1)
2. **This Week:** Amazon schedule shows Tuesday 08:00 (Solo1)
3. **System:** Automatically assigns Firas to Tuesday 08:00
4. **Reason:** Same time slot (08:00), same contract type (Solo1)

### Edge Cases
- [ ] New driver (no history) → Leave unassigned or suggest based on availability
- [ ] Driver unavailable this week → Flag for manual assignment
- [ ] Time slot not worked last week → Leave empty
- [ ] Multiple drivers worked same slot last week → Show dropdown to choose





## AI Scheduling Assistant

### Natural Language Commands
- [ ] "Fill in Firas for Saturday, Sunday, Monday" → AI assigns Firas to all available slots on those days
- [ ] "Who can cover Tuesday and Wednesday?" → AI suggests drivers based on availability and HOS
- [ ] "Fill remaining gaps" → AI auto-assigns available drivers to empty slots
- [ ] "Optimize this week's schedule" → AI redistributes shifts for better balance

### Smart Gap Filling
- [ ] Identify empty slots in schedule
- [ ] Suggest drivers who:
  - Are available on that day (availability calendar)
  - Have worked that time slot before (preference learning)
  - Won't violate 10-hour break rule
  - Haven't exceeded weekly hour limits
- [ ] Show multiple options ranked by best fit
- [ ] One-click to accept AI suggestion

### Workforce Planning & Recommendations

#### Company Goals
- [ ] Set company goal: "All drivers work 3-4 days per week"
- [ ] Set max consecutive days: "No driver works more than 5 days in a row"
- [ ] Set preferred hours per driver per week: 40-50 hours

#### AI Analysis & Recommendations
- [ ] **Hiring Recommendations:**
  - "You need 3 more Solo1 drivers for 16:30-06:30 time slots"
  - "Hire 2 part-time drivers for weekend coverage (Sat-Sun)"
  - Shows which specific time slots need coverage
  
- [ ] **Schedule Health Dashboard:**
  - Current: 15 drivers averaging 5.2 days/week (above goal)
  - Recommendation: Hire 4 more drivers to reach 3-4 days/week goal
  - Shows cost impact: "Hiring 4 drivers reduces overtime by $X/month"

- [ ] **Driver Utilization Report:**
  - Firas: 3 days/week ✅ (within goal)
  - Tareef: 2 days/week ⚠️ (underutilized)
  - Mitchell: 6 days/week ❌ (overworked, hire more to reduce)

### AI Chat Interface
- [ ] Chat box on Schedules page: "Ask AI for help"
- [ ] Example prompts:
  - "Fill Tuesday 08:30 slot"
  - "Who worked 16:30 last week?"
  - "Show me drivers available Friday"
  - "Balance workload across all drivers"
  - "How many drivers do I need to hit 4-day goal?"

### Learning & Preferences
- [ ] AI learns driver preferences over time
- [ ] "Firas prefers weekends" → AI prioritizes him for Sat/Sun
- [ ] "Tareef always works 20:30 slot" → AI suggests him first for that time
- [ ] Track driver performance/reliability → Factor into recommendations

### Integration with Existing Features
- [ ] Respects driver availability calendar
- [ ] Enforces 10-hour break rule
- [ ] Considers driver type (Solo1/Solo2/Both)
- [ ] Checks previous week's assignments for continuity
- [ ] Validates against HOS regulations





## Communication & Messaging System

### SMS Notifications & Confirmations
- [ ] Send SMS when driver is assigned to shift
- [ ] Driver receives: "You're scheduled for Monday 08:30 (Solo1, 14h). Reply YES to confirm or NO to decline"
- [ ] Driver responds via SMS: "YES" or "NO"
- [ ] System updates shift status:
  - ✅ Green = Confirmed
  - 🟡 Yellow = Pending (no response)
  - 🔴 Red = Declined or no response 20 hours before shift
- [ ] SMS reminders: 24h, 12h, 2h before shift
- [ ] Integration with Twilio or similar SMS service

### Dispatcher-Driver Messaging

#### Individual Messages
- [ ] Dispatcher selects driver from list
- [ ] Send message: "Firas, can you work an extra shift on Friday?"
- [ ] Driver receives notification (SMS + in-app)
- [ ] Driver responds in thread
- [ ] Conversation history saved per driver

#### Broadcast Messages (One-to-Many)
- [ ] "Send to All Drivers" button
- [ ] Message: "Reminder: Daylight savings time this weekend"
- [ ] Each driver receives individually (private, can't see others)
- [ ] Drivers respond individually
- [ ] Dispatcher sees all responses in one view:
  ```
  Message: "Who can cover Saturday 16:30?"
  
  Responses:
  - Firas: "I can do it" ✅
  - Mitchell: "Not available"
  - Tareef: "Yes, I'm free" ✅
  - Brian: (no response yet)
  ```

#### Messaging Features
- [ ] Real-time notifications (push, SMS, email)
- [ ] Read receipts ("Seen at 3:45 PM")
- [ ] Typing indicators
- [ ] Message history/archive
- [ ] Search conversations
- [ ] Attach files (PDFs, images)
- [ ] Quick replies: "Confirmed", "On my way", "Running late"

### Time-Off Request System

#### Driver Side
- [ ] "Request Time Off" button
- [ ] Select date range: "Nov 15 - Nov 20"
- [ ] Add reason (optional): "Family vacation"
- [ ] Submit request
- [ ] Status tracking:
  - 🟡 Pending approval
  - ✅ Approved
  - ❌ Denied (with reason)

#### Manager Side
- [ ] View all time-off requests in one place
- [ ] See impact: "Firas off Nov 15-20 affects 6 scheduled shifts"
- [ ] Approve/Deny with one click
- [ ] Add notes: "Approved. Find coverage for Monday 08:30"
- [ ] System automatically:
  - Removes driver from those days' schedules
  - Marks slots as "Needs coverage"
  - Suggests replacement drivers

#### Calendar Integration
- [ ] Time-off shows on driver availability calendar
- [ ] Blocked days appear in red
- [ ] Can't assign driver to shifts during time-off
- [ ] Annual time-off balance tracking

### Truck Assignment Management

#### Assign Trucks to Drivers
- [ ] When scheduling shift, assign tractor number
- [ ] Dropdown: "Select Tractor" → Shows available tractors
- [ ] Track which driver has which truck for each shift
- [ ] Prevent double-booking trucks

#### Truck Availability
- [ ] Show which tractors are available for each time slot
- [ ] Filter by fuel type (CNG/DIESEL)
- [ ] Filter by status (Active, Maintenance, Out of Service)
- [ ] "Truck #1234 is in maintenance Nov 10-12"

#### Truck Assignment View
- [ ] See all truck assignments for the week
- [ ] "Tractor 1234: Monday (Firas), Tuesday (Mitchell), Wednesday (Brian)"
- [ ] Identify unused tractors
- [ ] Optimize truck utilization

#### Pre-Trip & Post-Trip Reports
- [ ] Driver submits pre-trip inspection via app
- [ ] Report issues: "Tire pressure low on Truck 1234"
- [ ] Manager gets notified
- [ ] Post-trip report: Mileage, fuel, damages
- [ ] Track maintenance needs

### Notification Center
- [ ] Centralized notification hub
- [ ] Types of notifications:
  - Shift assignments
  - Shift confirmations/declines
  - Time-off requests
  - Messages from drivers
  - Truck issues
  - HOS violations
  - Schedule changes
- [ ] Mark as read/unread
- [ ] Filter by type
- [ ] Notification preferences (email, SMS, push, in-app)

### Mobile App Considerations
- [ ] Driver mobile app for:
  - Viewing schedule
  - Confirming shifts
  - Messaging dispatcher
  - Requesting time off
  - Submitting truck reports
- [ ] Push notifications
- [ ] Offline mode (view schedule without internet)





## Natural Language Scheduling with Preferences

### Complex Multi-Constraint Commands
- [ ] "Auto-generate schedule from last week, but Brian wants Tuesday instead of Wednesday"
  - AI copies last week's schedule
  - Finds Brian's Wednesday shifts
  - Moves them to Tuesday (if available and HOS compliant)
  - Fills Wednesday gaps with other drivers

- [ ] "Build from last week, Tareef wants Saturday off, and Firas can work extra on Friday"
  - AI copies last week
  - Removes Tareef from all Saturday shifts
  - Suggests replacements for Tareef's Saturday slots
  - Adds Firas to available Friday slots
  - Shows preview before applying

- [ ] "Same as last week but Mitchell is on vacation Monday-Wednesday"
  - AI copies schedule
  - Removes Mitchell from Mon-Wed
  - Auto-assigns replacements based on:
    - Who worked those time slots before
    - Who's available
    - HOS compliance
  - Shows which drivers are covering Mitchell's shifts

### Preference Learning & Memory
- [ ] AI remembers preferences across weeks:
  - "Brian prefers Tuesday over Wednesday" → Prioritizes Tuesday for Brian in future
  - "Tareef doesn't work Saturdays" → Avoids assigning Tareef to Saturdays
  - "Firas likes extra shifts on Friday" → Suggests Firas first for Friday gaps

### Interactive Adjustments
- [ ] Multi-step conversations:
  ```
  You: "Build from last week"
  AI: "✅ Schedule built. 42 shifts assigned, 6 gaps remaining."
  
  You: "Fill the gaps"
  AI: "✅ Filled 4 gaps. 2 remaining (no available drivers for Sat 20:30)"
  
  You: "Who can work Sat 20:30?"
  AI: "Mitchell (available, worked this slot 2 weeks ago) or Brian (available, prefers weekends)"
  
  You: "Assign Mitchell"
  AI: "✅ Mitchell assigned to Sat 20:30"
  ```

### Constraint Handling
- [ ] "Build from last week but keep everyone under 4 days"
  - AI redistributes shifts to balance workload
  - Shows before/after:
    ```
    Before: Firas (6 days), Mitchell (5 days), Brian (2 days)
    After: Firas (4 days), Mitchell (4 days), Brian (4 days)
    ```

- [ ] "Same as last week but no one works more than 5 consecutive days"
  - AI checks for consecutive day violations
  - Automatically inserts rest days
  - Suggests coverage for affected shifts

### Swap & Trade Commands
- [ ] "Swap Brian's Monday with Mitchell's Tuesday"
  - AI validates both drivers can work the swapped days
  - Checks HOS compliance
  - Executes swap if valid

- [ ] "Move all of Firas's shifts to next week"
  - AI removes Firas from current week
  - Adds him to same time slots next week
  - Suggests coverage for current week

### Batch Operations
- [ ] "Copy Monday's schedule to all Mondays for next 4 weeks"
  - AI duplicates Monday assignments
  - Validates driver availability each week
  - Flags conflicts for manual review

- [ ] "Fill all 16:30 slots with Mitchell this week"
  - AI finds all 16:30 time slots
  - Assigns Mitchell (checks HOS)
  - Shows count: "✅ Assigned Mitchell to 5 shifts (16:30 Mon-Fri)"





## AI Assistant Implementation (IN PROGRESS)

### Phase 1: Basic AI Chat Interface ✅ COMPLETE
- [x] Add AI chat component to Schedules page
- [x] Connect to Manus Forge API (using BUILT_IN_FORGE_API_KEY)
- [x] Implement basic command parsing with natural language understanding
- [x] Test commands: "Fill Firas for Saturday, Sunday, Monday"
- [x] AI Assistant button added to Schedules page header (gradient purple/blue)
- [x] Chat UI with floating panel, message history, and loading states
- [x] Backend tRPC endpoint for AI command processing
- [x] All test commands responding appropriately

### Phase 2: CSV Import + Auto-Build from Last Week (IN PROGRESS)
- [x] Add CSV import button to Schedules page for Friday's new blocks
- [x] Parse Amazon Relay block format (Start Time, Tractor, Driver Type, Domicile)
- [x] Auto-assign drivers based on last week's schedule (match time slots)
- [x] Match contract types (Solo1/Solo2)
- [x] Handle driver unavailability (checks active status and driver type)
- [x] Import dialog with CSV upload and paste options
- [ ] Show preview of auto-assignments before applying
- [ ] AI Assistant integration for review and adjustments
- [ ] "Build from last week" AI command triggers auto-build
- [ ] Allow AI commands to modify auto-generated schedule
- [ ] Test with real Amazon Relay data

### Phase 3: Complex Multi-Constraint Commands
- [ ] Parse complex commands with multiple conditions
- [ ] Handle preferences: "Brian wants Tuesday instead of Wednesday"
- [ ] Handle time-off: "Tareef wants Saturday off"
- [ ] Validate and suggest replacements

### Phase 4: Smart Suggestions
- [ ] "Who can cover [day] [time]?" command
- [ ] Rank suggestions by best fit
- [ ] Show reasoning for each suggestion

### Phase 5: Workload Balancing
- [ ] "Keep everyone under X days" command
- [ ] Redistribute shifts automatically
- [ ] Show before/after comparison





## Dashboard Enhancements

- [x] Add AI Assistant button/widget to Dashboard page
- [x] Floating AI chat accessible from Dashboard (bottom-right corner)
- [x] Expandable button with hover effect (shows "Ask AI Assistant")
- [x] AI can answer questions about fleet status, driver availability, etc.
- [ ] Quick actions for common tasks (import blocks, build schedule, etc.)




## Homepage Rebrand & Marketing Copy ✅ COMPLETE

- [x] Remove all "Laminar" references from codebase
- [x] Research shift scheduling pain points (forums, X, Reddit)
- [x] Create compelling hero section with AI focus
- [x] Highlight time savings: "Hours of planning, done in minutes"
- [x] Add rich, modern fonts and gradient color scheme (purple/blue/teal)
- [x] Rewrite copy to beat Monday.com and other schedulers
- [x] Focus on SaaS shift-based scheduling value prop
- [x] Add social proof section (20K+ shifts, 1K+ hours saved, 60s avg time)
- [x] Emphasize AI automation and "get your hours back"
- [x] Use buzzy, exciting language throughout
- [x] Animated gradient backgrounds and floating orbs
- [x] Feature comparison cards (vs Monday.com, 7shifts, WhenIWork)
- [x] 3-step "How It Works" section
- [x] Bold CTAs with "Start Free Trial" messaging




## Homepage Expansion - Multi-Industry Theme ✅ COMPLETE

- [x] Expand "Built for shift-based teams" section with industry cards
- [x] Add industry-specific use cases (restaurants, logistics, healthcare, retail, manufacturing)
- [x] Remove "VAS certified" references from Navigation
- [x] Make product positioning more universal (not just drivers)
- [x] Add visual industry icons/illustrations (emojis)
- [x] Show how different industries use the platform with testimonial-style quotes
- [x] 6 industry cards: Restaurants, Logistics, Healthcare, Retail, Manufacturing, Your Industry




## Homepage Rewrite - Diary of a CEO Style ✅ COMPLETE

**Goal:** Rewrite homepage using Steven Bartlett's attention-grabbing storytelling approach

**Key Learnings from Diary of a CEO:**
- Bold, provocative statements that challenge status quo
- Pain-first approach - Hit frustration HARD before offering solution
- Emotional hooks - Make them FEEL the problem
- Pattern interrupts - Unexpected angles
- Curiosity gaps - Make them want to scroll/read more
- Conversational, direct tone
- Focus on what the audience cares about (themselves, their pain)
- Create memorable moments, not just information
- Use stories and specific examples over generic features

**Homepage Sections to Rewrite:**
- [ ] Hero section - Lead with PAIN (scheduling nightmares)
- [ ] Hook them with a bold statement they can't ignore
- [ ] Use curiosity gaps throughout
- [ ] Rewrite industry cards with emotional storytelling
- [ ] Add "Before/After" narrative structure
- [ ] Make it conversational and direct
- [ ] Remove corporate speak, add human voice
- [ ] Focus on "you" language, not "we" language
- [ ] Create pattern interrupts to keep attention
- [ ] End with strong call-to-action that feels inevitable




## Bug Fixes

- [x] Fix AI chat error when processing commands like "firas want to work Sunday, Monday, and Saturday at 1730"
- [x] Improve error handling in AI scheduler backend (now returns helpful messages instead of throwing)
- [x] Add better error messages for users (graceful degradation with suggestions)




## Homepage Simplification - ChatGPT/Google Style ✅ COMPLETE

- [x] Remove all clutter from homepage
- [x] Focus on ONE problem to solve ("Stop wasting 10 hours every week on scheduling")
- [x] Simple, clean design like ChatGPT/Google
- [x] One prominent login/get started button (rounded, gradient)
- [x] Minimal text, maximum impact
- [x] Clean white space (centered, breathing room)
- [x] Remove all secondary sections initially




## Critical Bug Fix

- [x] Fix tRPC mutation error: "hooks[lastArg] is not a function" in AI service
- [x] Correct tRPC client usage - now using useMutation hook properly in Schedules.tsx
- [x] Removed AISchedulingService wrapper, calling tRPC mutation directly




## Make AI Actually Intelligent (Like Manus) ✅ COMPLETE

- [x] AI now receives full driver data from database
- [x] "Who can cover Tuesday 16:30?" returns actual list of available drivers
- [x] Checks who's already scheduled and filters them out
- [x] Returns actionable data with bullet-point lists
- [x] Shows driver names, driver types (Solo1/Solo2), preferred times
- [x] Analyzes schedule data in real-time
- [x] AI feels smart and helpful with specific recommendations




## AI Natural Language Improvements ✅ COMPLETE

- [x] Parse military time flexibly: 1630, 16:30, 16;30, "sixteen thirty"
- [x] Handle day abbreviations: Tues, Wed, Thurs, M-F, M-Sat
- [x] Support day letter codes: M T W T F, MTWRF
- [x] Interpret day ranges: M-F = Monday through Friday, M-Sat = Monday through Saturday
- [x] Tolerate misspellings: Wendsday, Teusday, Fridy, Satday, etc.
- [x] Handle typos in time separators: : ; . or no separator
- [x] Created comprehensive NLP parser (nlp-parser.ts)
- [x] AI understands natural variations and paraphrasing




## AI-Powered CSV Import with Custom Prompts ✅ COMPLETE

- [x] Add text field to CSV import dialog for AI instructions
- [x] Show example prompts: "Keep Firas under 4 days", "Prioritize Solo1 drivers", "Balance workload evenly"
- [x] Pass AI prompt to auto-build service
- [x] AI interprets constraints and applies them during scheduling
- [x] Support constraints: max days per driver, driver type preferences, workload balancing
- [x] Parse prompts with regex: "Keep [driver] under [X] days", "Prioritize Solo1/Solo2", "Balance workload"
- [x] Constraint validation during driver assignment
- [x] Return explanation via warnings array




## Advanced Scheduling Constraints & Analysis ✅ COMPLETE

- [x] Parse "Give [driver] only 1 Solo1" constraint (limit specific contract types per driver)
- [x] Parse "Keep everyone between 3 Solo1 and 2 Solo2" optimal range constraint
- [x] Enforce per-driver contract type limits during auto-build
- [x] AI capacity analysis: "How many more drivers do I need to fill this schedule?"
- [x] Calculate total blocks vs driver capacity (optimal: 3 Solo1 + 2 Solo2 per driver)
- [x] Profitability warnings: 5-6 Solo1 or 3 Solo2 = not profitable
- [x] Show warnings when drivers exceed optimal ranges (with emojis)
- [x] AI can answer capacity questions based on imported blocks
- [x] Constraint validation prevents over-assignment
- [x] Optimal assignments highlighted with ✅




## Import Dialog Improvements ✅ COMPLETE

- [x] Change dialog title from "Import Friday's Amazon Relay Blocks" to "Import Weekly Shifts"
- [x] Add drag-and-drop support for CSV file upload (with visual drop zone)
- [x] Keep existing "Choose file" button (hidden input with label)
- [x] Make it work for any shift-based industry, not just Amazon Relay
- [x] Updated description to mention "team members" instead of "drivers"
- [x] Changed "Paste Data from Amazon Relay" to "Paste Shift Data"




## Bug Fixes

- [ ] Fix CSV parser to handle real Amazon Relay format (Block ID, Trip ID, Block/Trip, Trip Stage, Load ID, Facility Sequence, etc.)
- [ ] Parser currently expects "Start Time, Tractor, Driver Type, Domicile" but real format is different
- [ ] Extract start time from "Port Appointment Time" or "Trip Stage" column
- [ ] Map real column names to expected format



- [ ] Debug why "Port Appointment Time" column isn't being recognized
- [ ] Add console logging to see what headers are being parsed
- [ ] Test with real Amazon Relay CSV data




## Amazon Relay Trip CSV Parser Rewrite ✅ COMPLETE

- [x] Parse real Amazon Relay Trip CSV format (Block ID, locations, times, duration)
- [x] Extract BLOCK rows only (skip Trip rows)
- [x] Identify Solo1 vs Solo2 from FTIM contract type field
- [x] Extract start time from column 25 (Port Appointment Time)
- [x] Use Block ID as tractor identifier
- [x] Parser now handles actual Amazon Relay export format
- [ ] Sort drivers by last name in UI (future enhancement)
- [ ] Show blocks starting on tender day (already working)




## Dual-Mode CSV Import (Friday Tender vs Learning Mode) ✅ COMPLETE

- [x] Update parser to handle blocks WITHOUT driver names (Friday tenders)
- [x] Auto-build pulls from last week's DATABASE schedule (not CSV driver names)
- [x] Match blocks by day/time from previous week's assignments
- [x] Learning mode: If CSV has driver names, added as suggestedDriver field
- [x] Friday mode: CSV has no drivers, system assigns based on historical patterns from DB
- [x] Parser extracts driver name only if present (optional field)




## Bug Fixes

- [ ] Fix CSV file upload - parser not finding Block rows
- [ ] Debug why uploaded CSV shows in paste area but doesn't parse correctly
- [ ] Verify file reading logic is working




## CSV Block Import Debug (Current Issue)
- [x] Fix CSV parser failing with "No valid blocks found in CSV" error
  - File upload working (reads file, displays in paste area)
  - Parser correctly identifies Block rows (column 2 = "Block")
  - Fixed column indices to match actual Amazon Relay Trip CSV format:
    - Column 18: Truck Filter (was 17)
    - Column 28: Stop 1 Location (was 22)
    - Column 30: Start Date (was 24)
    - Column 31: Start Time (was 25)
  - Removed debug logging
  - Ready for user to test import




## Truck AI Management (NEW REQUEST)
- [x] Add status field to tractors table (available, unavailable, maintenance)
- [ ] Add unavailableFrom and unavailableTo date fields to tractors (not needed yet)
- [x] Update AI scheduler to handle truck management commands
- [x] Implement natural language commands:
  - [x] "Mark truck [number] as unavailable"
  - [x] "Set tractor [number] to maintenance"
  - [x] "Make truck [number] available again"
  - [x] "Make Mohammad Rasool a Solo2 driver"
  - [x] "Set Isaac's status to inactive"
  - [ ] "Which trucks are available on [day]?" (query feature - future)
  - [ ] "Show me all unavailable trucks" (query feature - future)
- [ ] Update scheduling logic to respect truck availability (future)
- [ ] Add truck status indicators in Fleet Management page (future)
- [ ] Test AI commands for truck management




## Truck Maintenance Tracking & Query (NEW REQUEST)
- [x] Add AI query commands for truck status:
  - [x] "Which trucks are in maintenance?"
  - [x] "Which truck was down last week for maintenance?"
  - [x] "Show me all unavailable trucks"
  - [x] "Do I have enough trucks for next week?"
- [x] Add truck maintenance history tracking:
  - [x] Track when truck status changes (via updatedAt timestamp)
  - [x] Query trucks that went into maintenance in last 7 days
  - [ ] Store maintenance start/end dates in tractorAvailability table (future enhancement)
- [x] Add truck capacity analysis:
  - [x] Count active trucks vs total blocks needed
  - [x] Calculate if enough trucks available for schedule
  - [x] Warn if truck shortage
- [x] Implement database queries for truck filtering by status
- [x] Add date range queries for maintenance history (using updatedAt)




## Capacity Planning & What-If Analysis (NEW REQUEST)
- [x] Add AI scenario-based capacity analysis:
  - [x] "If I lose 2 drivers next week, how many contracts will I need?"
  - [x] "If I have 3 trucks down, what's my capacity?"
  - [x] "Can I handle the load with current fleet?"
  - [x] "If I don't schedule 5 routes, do I still have enough drivers?"
- [x] Implement capacity calculation logic:
  - [x] Parse scenario variables (drivers lost, trucks down, routes removed)
  - [x] Calculate remaining capacity (drivers × optimal blocks per driver)
  - [x] Calculate contract shortfall (blocks needed - capacity)
  - [x] Provide recommendations (hire X drivers, bring trucks back, etc.)
- [x] Add natural language parsing for scenario questions:
  - [x] Detect "if I lose X drivers" patterns
  - [x] Detect "if X trucks down" patterns
  - [x] Detect "if I don't schedule X routes" patterns
  - [ ] Detect "if X is off [day]" patterns (future - requires driver-day mapping)
- [x] Integrate with existing capacity analysis
- [ ] Test various scenario combinations




## HOS (Hours of Service) Tracking & Capacity Analysis (NEW REQUEST)
- [x] Add HOS rules to driver capacity calculations:
  - [x] Solo2: Max 3 consecutive blocks before 34-hour restart
  - [x] Solo1: Max 6 consecutive days before 34-hour restart
  - [x] Track consecutive work periods per driver
- [x] Store and query last week's schedule:
  - [x] Get driver assignments from previous week
  - [x] Calculate consecutive Solo1/Solo2 blocks worked
  - [x] Determine when last 34-hour restart occurred
- [x] Calculate remaining HOS capacity per driver:
  - [x] Driver worked 2 Solo2s last week → 1 more available this week
  - [x] Driver worked 3 Solo2s last week → needs restart, unavailable until restart complete
  - [x] Driver worked 4 Solo1s last week → 2 more available this week
- [x] Integrate HOS into pre-planning capacity analysis:
  - [x] "Do I have enough drivers for Solo2 next week?" considers HOS limits
  - [x] Show which drivers need restarts
  - [x] Calculate true available capacity accounting for HOS
  - [x] Recommend which time slots to cancel based on HOS constraints
- [x] Add AI commands for HOS queries:
  - [x] "Which drivers need a restart this week?"
  - [x] "What's my real Solo2 capacity considering HOS?"
  - [x] "Do I have enough drivers for Solo2 next week?" (HOS-aware)




## Branding Update & Landing Page Redesign
- [x] Change app name from "Manus" to "Milo"
- [x] Generate friendly robot mascot logo (professional, office-friendly)
- [x] Update all references to app name in code
- [x] Landing page redesign with:
  - [x] "meet... Milo" hero text with gradient
  - [x] Huge centered Milo robot watermark with floating animation
  - [x] Realistic calendar backdrop with month header
  - [x] Soft gradient background (slate → blue → purple)
  - [x] Desktop optimizations (larger typography, animations, shadows)
  - [x] Hover effects on calendar and button
  - [x] Responsive design for mobile and desktop
- [x] Update Navigation and Footer with Milo logo




## AI Command Prompt Interface (NEW REQUEST)
- [x] Replace floating AI button with command-line style input
- [x] Add AI command prompt bar to Dashboard at top location
- [x] Style with Milo robot icon and purple gradient card
- [x] "Ask Milo..." placeholder with example
- [x] Support Enter key to submit commands
- [x] Display AI responses inline below the prompt
- [x] Loading state with "Milo is thinking..."
- [ ] Show command history (up/down arrows) - future enhancement




## CSV Import Issues (BUG REPORT)
- [x] Add preview of parsed blocks after paste/upload
- [x] Show count of blocks found vs errors
- [x] Use parsed blocks directly instead of re-parsing
- [x] Fix auto-build to prioritize suggestedDriver from CSV
- [x] Add fuzzy matching for driver names (handles variations like "Isaac Kiragu" vs "Isaac")
- [x] Add warnings when suggested driver not found or unavailable
- [ ] Test with real Trips.csv to verify driver assignments work correctly

## Schedule Display Enhancement
- [x] Solo2 drivers should appear on BOTH days they work in the schedule grid
- [x] Example: Solo2 driver working Tuesday-Wednesday should show in both Tuesday AND Wednesday cells
- [x] Update schedule rendering logic to span multi-day assignments for Solo2 (38-hour blocks)
- [x] When Solo2 driver assigned on Day 1, automatically display on Day 2 as well
- [x] Removing Solo2 driver removes from both days




## Auto-Build Date Verification
- [ ] Verify dates match exactly for each driver from CSV
- [ ] Investigate why Brian Worts not showing on Sunday schedule
- [ ] Add "Clear Schedule" button to reset all assignments
- [ ] Verify day-of-week calculation from CSV start dates
- [ ] Check if auto-build is matching the correct week (current vs next week)




## Mobile Responsiveness Issues
- [x] Fix schedule grid layout for mobile phones (stacks vertically on mobile, side-by-side on desktop)
- [x] Make schedule grid horizontally scrollable on small screens (already has overflow-x-auto)
- [x] Adjust driver sidebar to collapse or stack on mobile (now stacks above schedule on mobile)
- [x] Fix button sizes and spacing for mobile (buttons now stack vertically on small screens)
- [x] Test landing page on mobile (Milo page) - reduced text sizes, added responsive breakpoints
- [x] Ensure dashboard navigation works on mobile (DashboardLayout already has mobile sidebar)
- [x] Add responsive breakpoints for tablets and phones (sm, md, lg breakpoints added)




## Auto-Build Warnings Display
- [x] Show warnings in a dialog immediately after auto-build completes
- [x] Display specific details: driver names not found, unavailable slots, type mismatches
- [x] Make warnings clickable/expandable for more details (each warning in its own card)
- [x] Add "View Details" button instead of relying on AI Assistant (dialog pops up automatically)




## Driver Name Matching Bug
- [x] Fix fuzzy matching to handle semicolon-separated names (e.g., "Robert Charles; JR Dixon")
- [x] Split on semicolon and try matching each part separately
- [x] Example: "Robert Charles; JR Dixon" should match "Robert Charles" OR "JR Dixon" in database
- [x] Added multi-level matching: exact match → full fuzzy match → semicolon-separated parts




## Driver Name Format Matching
- [x] Handle "Last, First Initial" format (e.g., "R. Dixon" in database)
- [x] Match "R. Dixon" with "JR Dixon" from CSV (matches on last name "Dixon" + first initial "R" in "JR")
- [x] Match "R. Dixon" with "Robert Charles; JR Dixon" from CSV
- [x] Extract last name and first initial for smart matching
- [x] Example: "Dixon" + "R" matches "R. Dixon" when CSV has "JR Dixon" or "Robert Dixon"




## Comprehensive Auto-Build Logic Improvements
- [ ] Review and document current auto-build logic flow
- [ ] Improve driver name matching for ALL name format variations
- [ ] Add detailed logging/debugging for assignment decisions
- [ ] Verify exact date matching from CSV to schedule grid
- [ ] Ensure Solo2 drivers are assigned to correct consecutive days
- [ ] Add conflict detection before assignment
- [ ] Optimize workload distribution (avoid overloading drivers)
- [ ] Add validation: check all CSV blocks are assigned
- [ ] Show detailed assignment report after auto-build
- [ ] Handle edge cases: unavailable drivers, missing time slots, etc.




## CSV Import and Date Range Issues
- [ ] Fix: Only 33 blocks uploaded instead of 34 from Trips.csv
- [ ] Investigate why 1 block is being filtered out during CSV parsing
- [ ] Fix date range matching - blocks appearing outside correct week
- [ ] Ensure blocks only appear in the week that contains their start date
- [ ] Verify day-of-week calculation matches the actual calendar date
- [ ] Add validation: warn if block date is outside current week view




## AI Auto-Correction and Smart Error Handling
- [ ] Auto-fix CSV parsing errors (infer missing data from context)
- [ ] Smart date format detection and conversion
- [ ] Flexible CSV column detection (handle variations in structure)
- [ ] Auto-recovery from import failures with suggestions
- [ ] Intelligent screen size detection and UI adjustment
- [ ] Replace error messages with actionable suggestions
- [ ] Auto-correct common user mistakes (typos, wrong formats, etc.)
- [ ] Predictive validation before import (warn about potential issues)
- [ ] Smart defaults for missing fields
- [ ] Context-aware help messages




## Intelligent Fuzzy Name Matching
- [x] Match by last name only ("ivy" → "Mathew William Ivy")
- [x] Match by first name only ("mathew" → "Mathew William Ivy")
- [x] Match partial names ("mathew ivy" → "Mathew William Ivy")
- [x] Handle common misspellings ("matthew" → "Mathew", "allan" → "Alan")
- [x] Support common nicknames ("matt" → "Mathew", "bob" → "Robert")
- [x] Case insensitive matching
- [x] Ignore extra spaces and punctuation
- [x] Use Levenshtein distance for typo tolerance (70% similarity threshold)
- [x] Apply to auto-build service
- [x] Apply to AI assistant (server-side)
- [x] Show "Did you mean...?" suggestions when match is uncertain




## Full Manus AI Integration (Pro Account)
- [x] Replace basic AI assistant with full Manus AI (GPT-4o via Forge API)
- [x] Integrate Manus AI API for natural language understanding
- [x] Enable conversational interface (no command patterns needed)
- [x] Add context awareness (fleet, drivers, schedules, current week)
- [x] Enhanced system prompt with conversational capabilities
- [x] Intelligent fuzzy name matching in AI responses
- [ ] Support complex queries and multi-step operations (needs function calling)
- [ ] Enable schedule modifications through natural language (needs tool integration)
- [ ] Add driver management through conversation (partially done via ai-scheduler.ts)
- [ ] Implement workload analysis and recommendations (needs database queries)
- [ ] Add memory/context persistence across conversations (needs conversation history)
- [ ] Enable "Ask Manus anything" interface in Dashboard




## Rebrand from "Driver Flow" to "Manus"
- [x] Replace all "Driver Flow" references with "Manus"
- [x] Replace all "DriverFlow" references with "Manus"
- [x] Replace all "manus" references with "manus"
- [x] Update app title and branding
- [x] Update package.json name to "manus"
- [x] Update landing page copy
- [x] Update dashboard welcome messages
- [x] Update all user-facing text
- [x] Update documentation and comments
- [x] Keep "Milo" as the AI assistant name (Milo is part of Manus)
- [ ] User needs to update VITE_APP_TITLE in Settings → General if desired


## Update App Branding to Milo
- [x] Change default APP_TITLE from "App" to "Milo"
- [x] Add Milo robot icon as default APP_LOGO
- [x] Update sidebar to show "Milo" and robot icon




## CSV Import Date Filtering (BUG)
- [x] Filter imported blocks to only match the current week being viewed
- [x] When viewing week Oct 27 - Nov 2, only import blocks with dates in that range
- [x] Ignore blocks from past weeks (before Oct 27)
- [x] Ignore blocks from future weeks (after Nov 2)
- [x] Show warning message if blocks are filtered out due to date mismatch
- [x] Show error if no blocks match current week
- [ ] Add option to "Import All Weeks" vs "Import Current Week Only" (future enhancement)




## Dashboard Statistics Enhancement
- [x] Active Drivers card: Show breakdown by driver type (Solo1, Solo2, Both)
- [x] Active Drivers card: Show total drivers and inactive count
- [x] Active Tractors card: Show breakdown by tractor type (Solo1, Solo2)
- [x] Active Tractors card: Show total tractors and inactive count
- [x] Format: "37 active / 42 total (5 inactive)" with type breakdowns below

## AI Assistant Fuzzy Matching Bug
- [ ] Fix server-side AI assistant to use fuzzy name matching
- [ ] "mathew ivy to" should find "Mathew William Ivy"
- [ ] Integrate fuzzyNameMatcher.ts properly in ai-scheduler.ts




## AI Assistant Context Enhancement (BUG)
- [x] Milo doesn't have access to tractor data when answering questions
- [x] Add tractor query to AI assistant context
- [x] Include driver details (not just names) in AI context
- [x] Include schedule data in AI context
- [x] Enable Milo to answer: "how many solo2 trucks do I have?"
- [x] Enable Milo to answer fleet capacity questions
- [ ] Enable Milo to answer: "who's working next week?" (needs schedule analysis)
- [ ] Add more intelligent schedule queries




## AI Copilot on All Pages
- [ ] Create reusable MiloAssistant component (same design as Dashboard)
- [ ] Add Milo bar to Drivers page (robot icon + input + response area)
- [ ] Add Milo bar to Tractors page
- [ ] Replace "AI Assistant" button on Schedules page with Milo bar
- [ ] Add Milo bar to Start Times page
- [ ] Make Milo context-aware (knows which page user is on)
- [ ] Enable action execution: "make all solo2 trucks" → updates all tractors
- [ ] Enable action execution: "make mathew a solo2 driver" → updates driver type
- [ ] Enable action execution: "assign brian to friday 8am" → creates schedule assignment
- [ ] Auto-refresh page data after Milo executes actions
- [ ] Show confirmation before executing bulk changes
- [ ] Add success/error messages after actions




## Enhanced Milo AI System Prompt (Latest Update)
- [x] Added comprehensive Amazon Freight Partner (AFP) operational context
- [x] Detailed driver/tractor types and optimal workload ranges (3 Solo1 + 2 Solo2)
- [x] Complete schedule building process documentation with CSV import priority
- [x] Advanced fuzzy name matching examples (last name, nicknames, misspellings)
- [x] Tractor data integration in AI context (counts by type)
- [x] DOT HOS compliance rules (70-hour weekly limit, 10-hour breaks)
- [x] Common user request examples with expected responses
- [x] Clearer response guidelines (conversational, data-driven, explain reasoning)
- [x] Explicit limitations (advisor role, cannot execute changes directly)
- [x] Enhanced conversational capabilities with GPT-4o

## Pending - Deploy Milo to All Pages
- [ ] Add MiloAssistant component to Drivers page
- [ ] Add MiloAssistant component to Tractors page
- [ ] Add MiloAssistant component to Start Times page
- [ ] Remove old "AI Assistant" button from Schedules page
- [ ] Replace with MiloAssistant component on Schedules page

## Known Issues
- [ ] Checkpoint save fails with "Killed" error (memory issue during build process)
- [ ] VITE_APP_TITLE environment variable shows "Driver Flo" instead of "Manus" (user needs to update in Settings)




## Add Milo Bar to All Pages (Current Task)
- [x] Add MiloAssistant component to Drivers page
- [x] Add MiloAssistant component to Tractors (Fleet Management) page
- [x] Add MiloAssistant component to Start Times page
- [x] Remove old "AI Assistant" button from Schedules page




## Make Dashboard Stat Cards Clickable (Current Task)
- [x] Make Active Drivers card clickable → navigate to /drivers
- [x] Make Active Tractors card clickable → navigate to /tractors
- [x] Make Upcoming Schedules card clickable → navigate to /schedules
- [x] Make Routes Scheduled card clickable → navigate to /schedules
- [x] Add hover effect and cursor pointer to indicate clickability




## Merge Stat Cards and Quick Actions (Current Task)
- [x] Combine Active Drivers stat card + Driver Management action card into one
- [x] Combine Active Tractors stat card + Fleet Management action card into one
- [x] Add "Manage Drivers" button to Active Drivers card
- [x] Add "Manage Tractors" button to Active Tractors card
- [x] Remove redundant Quick Actions section
- [x] Add "Make Schedules" button to Upcoming Schedules card




## Bug: Dashboard Not Updating After Adding Drivers
- [ ] Dashboard Active Drivers count not refreshing after adding new drivers
- [ ] Need to invalidate dashboard queries when drivers are created/updated/deleted
- [ ] Same issue likely affects Active Tractors count




## Move Action Buttons to Top of Dashboard Cards
- [x] Move "Manage Drivers" button to top of Active Drivers card
- [x] Move "Manage Tractors" button to top of Active Tractors card
- [x] Move "Make Schedules" button to top of Upcoming Schedules card
- [x] Stats should appear below the button




## Make Dashboard Cards Fully Clickable
- [x] Make entire Active Drivers card clickable → navigate to /drivers
- [x] Make entire Active Tractors card clickable → navigate to /tractors
- [x] Make entire Upcoming Schedules card clickable → navigate to /schedules
- [x] Add cursor pointer and hover effects to indicate clickability




## CRITICAL: Make Milo AI Actually Useful (Action Commands)
- [x] Milo should be able to CREATE new tractors when given data
- [x] Milo should be able to UPDATE existing tractors (change type, status, etc.)
- [x] Milo should be able to CREATE new drivers when given data
- [x] Milo should be able to UPDATE existing drivers (change type, status, etc.)
- [x] Parse bulk data input (tab-separated, CSV-like format)
- [x] Execute database mutations through tRPC
- [x] Return confirmation messages with what was changed
- [x] Update AI system prompt to understand action commands vs queries




## CRITICAL: Rebuild Milo with True GPT-4o Intelligence
- [x] Remove hardcoded pattern matching (if/else hell)
- [x] Use pure GPT-4o function calling for all commands
- [x] Add comprehensive function tools: update_tractors_bulk, update_drivers_bulk, query_fleet, etc.
- [x] Let GPT-4o interpret natural language commands without regex patterns
- [x] Handle ambiguous commands gracefully with clarifying questions
- [x] Make Milo as smart as Manus - true conversational AI




## CRITICAL BUG: Milo AI Completely Broken
- [x] Fix "Cannot read properties of undefined (reading 'type')" error in invokeLLM
- [x] Error happens before Milo can process any request
- [x] Need to debug message normalization in llm.ts
- [x] Test basic LLM connectivity with minimal payload
- [x] User has been asking same questions multiple times - Milo never responds successfully
- [x] Fixed hardcoded question interception that bypassed Milo
- [x] Fixed tractorType → contractType field name mismatch




## Add Milo Database Write Capabilities (CRITICAL)
- [x] Implement function calling for UPDATE operations
- [x] Add update_tractors_bulk function (bulk update by filter)
- [x] Add update_drivers_bulk function (bulk update by filter)
- [x] Intelligent filtering (by make, model, contractType, status, name)
- [x] Execute actual database updates using db.tractors.update()
- [x] Return confirmation with count of records affected
- [x] Full GPT-4o function calling with tool use
- [ ] Add create_tractors function (bulk insert) - coming next
- [ ] Add create_drivers function (bulk insert) - coming next




## CRITICAL BUG: Milo Says It Did Something But Didn't Execute (Real World Example)
- [x] User asked: "Schedule Firas Saturday Sunday Monday 17:30"
- [x] Milo responded: "✅ Got it. Firas is scheduled for Saturday, Sunday, and Monday at 17:30."
- [x] Reality: Nothing was actually scheduled in the database - all slots still show "Drop here"
- [x] Root cause: No create_schedule_assignment function exists in Milo's function calling
- [x] Milo needs functions to CREATE and UPDATE schedule assignments
- [x] Add create_schedule_assignment function (assign driver to specific days/times/blocks)
- [ ] Add update_schedule_assignment function (modify existing assignments)
- [ ] Add delete_schedule_assignment function (remove assignments)
- [x] Updated system prompt to tell Milo to use create_schedule_assignment for scheduling commands
- [ ] Test: "Schedule Firas Saturday Sunday Monday 17:30" should actually create database records




## CRITICAL: Milo Cannot Have Conversations (Resets After Each Question)
- [x] User reports: "Milo is not able to get past second questions"
- [x] Root cause: No conversation history/memory between messages
- [x] Each message starts fresh - Milo forgets previous context
- [x] Implemented conversation state management in Schedules.tsx
- [x] Store message history in component state (conversationHistory)
- [x] Pass previous messages to GPT-4o for context
- [x] Milo now remembers: previous questions, answers, fleet state changes, driver assignments
- [x] Added conversation history display (shows full chat)
- [x] Added "Clear chat" button to reset conversation
- [ ] Test: User asks "How many trucks?" then "What about Solo2?" - Milo should remember first question




## Milo Persistent Memory - Get Smarter Over Time
- [ ] Save all Milo conversations to database (conversation_history table)
- [ ] Load recent conversations when page loads (last 10-20 messages)
- [ ] Pass conversation history to GPT-4o for long-term context
- [ ] Milo learns: fleet patterns, user preferences, common questions, scheduling habits
- [ ] Store metadata: timestamp, user_id, command, response, success/failure
- [ ] Add "Memory" section showing what Milo has learned
- [ ] Option to clear/reset Milo's memory
- [ ] Sync with this Manus chat thread (import context from this conversation)
- [ ] Export conversation history for analysis/training

## Sync Milo with Manus Chat Thread
- [ ] Extract key learnings from this thread (business rules, dispatcher logic, 3-day rule, etc.)
- [ ] Create "knowledge base" entries from user's documents/instructions
- [ ] Pre-populate Milo's system prompt with domain knowledge
- [ ] Import fleet state context (driver roster, truck assignments, start times)
- [ ] Milo starts "pre-trained" on your specific AFP operation




## ACTIVE: Build "Open Vein" - Milo Learns from This Manus Thread
- [x] Create knowledge base extraction system (milo-knowledge-base.ts)
- [x] Extract key facts from this conversation thread
- [x] Store business rules, definitions, patterns in structured format
- [x] Inject thread context into Milo's system prompt
- [x] Milo queries thread knowledge before answering (knowledge base loaded on every request)
- [ ] Test: Milo should know everything discussed in this thread
- [ ] Continuous sync: As thread grows, Milo gets smarter automatically (manual updates for now)
- [ ] Store thread ID for future reference
- [ ] Build knowledge base update mechanism (automatic sync with Manus thread)




## BUG: Milo Asking Clarifying Questions Instead of Executing
- [ ] User typed "Schedule him Saturday Sunday Monday 17:30" - Milo asks "Who is him?"
- [ ] User typed "Firas" - Milo asks "What about Firas?"
- [ ] Milo should understand context from conversation history
- [ ] Milo should execute the schedule command, not ask questions
- [ ] Issue: Milo is on Dashboard page, conversation memory might not be working
- [ ] Check if conversationHistory is being passed correctly
- [ ] Verify Milo can see previous messages in the conversation




## Make Milo Global - Available on Every Page
- [x] Create GlobalMiloAssistant component
- [x] Floating button in bottom-right corner (like chat widget)
- [x] Click to open/close chat panel
- [x] Conversation memory persists across pages (component state)
- [x] Knowledge base ("open vein") connected (loaded on every request)
- [x] Add to DashboardLayout so it appears everywhere
- [x] Slide-in panel with full conversation history
- [x] Works on: Dashboard, Drivers, Tractors, Schedules, Start Times, all pages
- [ ] Test: Open Milo on Dashboard, ask question, go to Drivers page, conversation should persist




## BUG: Milo Says "I can't look up driver details" When It Should Know
- [x] User asked "Who is Firas" - Milo said "I can't look up specific driver details"
- [x] Milo SHOULD know Firas (he's in the database, in the knowledge base, in the context)
- [x] Context includes drivers array with all 42 drivers
- [x] Knowledge base lists all driver names including Firas
- [x] Milo was not using the driver data being passed to it
- [x] Improved system prompt to tell Milo to USE the context data
- [x] Added explicit DRIVER DATA section with examples
- [x] Added query_driver_info function for looking up specific drivers
- [x] Added driver/tractor data to user message context
- [ ] Test: "Who is Firas" should return driver details with name, type, status, phone, etc.




## MILO AI ASSISTANT - PRODUCTION-READY IMPLEMENTATION

### Research and Fix (COMPLETED)
- [x] Research X platform (xAI Grok documentation)
- [x] Research Martin Fowler's function calling patterns
- [x] Research academic papers (MediaTek 2024)
- [x] Research Wired magazine articles on AI assistants
- [x] Found proven production solutions

### Implementation Fixes (COMPLETED)
- [x] Removed massive knowledge base (5000+ tokens → 600 tokens)
- [x] Added error handling (try/catch all LLM calls)
- [x] Added malicious input filter (prompt injection protection)
- [x] Fixed function execution flow (check tool_calls exists)
- [x] Simplified architecture following production patterns
- [x] Created comprehensive test plan (test_milo.md)
- [x] Documented research findings (production_ai_assistant_research.md)

### Ready for Testing
- [ ] User to test all 8 scenarios in MILO_TEST_INSTRUCTIONS.md
- [ ] Verify no 500 errors
- [ ] Verify conversation memory works
- [ ] Verify malicious input blocked
- [ ] Save checkpoint after successful testing




## Add update_driver Function to Milo
- [x] User asked: "Can you make someone a Solo2 driver?"
- [x] Milo responded: "I don't have a tool to change driver's default contract type"
- [x] Need to add `update_driver` function
- [x] Function should allow changing: driverType (Solo1/Solo2/Both), status, phone, email, preferredStartTime
- [x] Add to Milo's function library in ai-scheduler.ts
- [x] Add to database layer (updateDriver function already exists, just need to expose it)
- [x] Added function definition to TOOLS array
- [x] Added function handler in executeFunctionCall
- [x] Updated system prompt to include update_driver
- [ ] Test: "Make Firas a Solo2 driver" should update his contract type




## Improve Milo Name Matching
- [ ] User tried "Devin Hill" but driver is "DEVIN WAYNE HILL" - didn't match
- [ ] Current fuzzy matching only does simple includes()
- [ ] Need smarter matching:
  - [ ] First name only: "Devin" → "DEVIN WAYNE HILL"
  - [ ] First + Last: "Devin Hill" → "DEVIN WAYNE HILL"
  - [ ] Full name: "DEVIN WAYNE HILL" → "DEVIN WAYNE HILL"
  - [ ] Case insensitive
  - [ ] Handle middle names
- [ ] Update all driver lookup functions (query_driver_info, update_driver, get_driver_schedule, etc.)
- [ ] Test: "Make Devin Hill a Solo1 driver" should work




## Apply findDriverByName to ALL Driver Lookups
- [x] Replace all driver.find() calls with findDriverByName() helper
- [x] Update query_driver_info to use findDriverByName
- [x] Update update_driver to use findDriverByName
- [x] Update get_driver_schedule to use findDriverByName
- [x] Update check_driver_compliance to use findDriverByName
- [x] Update create_schedule_assignment to use findDriverByName
- [x] Update query_schedule to use findDriverByName
- [x] Update update_schedule to use findDriverByName
- [ ] Test: ALL driver commands should work with first/last/full name

## Auto-Update Driver Roster When Adding New Drivers
- [ ] When new driver is added via UI, automatically refresh Milo's context
- [ ] When driver is imported via CSV, refresh driver list
- [ ] Milo should always have latest driver roster without manual refresh
- [ ] Consider caching driver list with TTL or event-based invalidation




## Milo Cannot Count Sleepers vs Day Cabs
- [ ] User asked: "How many sleepers do I have?"
- [ ] Milo said: "I don't have a way to distinguish between sleepers and day cabs"
- [ ] But tractors table HAS a model field (e.g., "Freightliner Cascadia Sleeper", "Volvo VNL Day Cab")
- [ ] Milo needs to:
  - [ ] Look at tractor model field
  - [ ] If model contains "Sleeper" → count as sleeper
  - [ ] If model contains "Day Cab" → count as day cab
  - [ ] Add `query_tractors` function to filter by type
- [ ] Test: "How many sleepers do I have?" should return count of sleeper tractors


- [x] Update query_tractors to only return the specific information requested (no extra counts)
- [x] Add VIN lookup function to find truck by VIN number
- [x] Add VIN status check (is VIN active/inactive)
- [x] Add function to get last 4 digits of VIN for any truck
- [ ] Test all VIN query variations with Milo


- [x] Fix Schedule page - 10-hour rule error blocking multiple driver assignments
- [x] Review scheduling logic from context (HOS rules, block assignments)
- [x] Fix schedule assignment validation to allow multiple drivers
- [x] Fixed getWeekDates() date mutation bug causing incorrect 10-hour validation
- [x] Test scheduling multiple drivers without errors
- [x] Verify 10-hour rest period validation works correctly


- [ ] Fix Auto-Build Schedule button validation error (invalid blockType enum)
- [ ] Ensure all scheduling features work for all current and future drivers
- [ ] Test Auto-Build with different driver types (Solo1, Solo2, Both, PartTime)


- [x] Fix nested anchor tags in Dashboard page (lines 50 and 58)
- [x] Remove outer Link wrapper or inner Link, keep only one
- [x] Test Dashboard page loads without hydration errors



## CSV Import Feature (Amazon Blocks)
- [x] Create database schema for imported blocks (block_id, driver_name, start_date, start_time, contract_type, duration, pay_rate)
- [x] Build CSV parser to extract blocks from Amazon export
- [x] Create API endpoint to upload and parse CSV
- [x] Match imported blocks to Start Times table
- [x] Filter blocks for "next week" (dynamic Sunday-Saturday)
- [x] Create Excel/Amazon-style table view (matches screenshots)
- [x] Add "Assign driver" dropdown for each block row
- [x] Create toggle button (Table View ↔ Calendar View)
- [x] Integrate table view with existing calendar grid
- [ ] Sync driver assignments between both views
- [ ] Test CSV import with PRACTIVEFORMILO.csv (77 blocks)
- [ ] Verify blocks display correctly in table view
- [ ] Verify toggle switches between views
- [ ] Test driver assignment in both views

## Database Schema Fix
- [x] Check drivers table schema in database
- [x] Compare with schema.ts definition
- [x] Fix column name mismatches (camelCase vs snake_case)
- [x] Sync database schema
- [ ] Test schedules page loads without errors



## Fix Schedules Schema Mismatch
- [ ] Fix schedules table schema to match actual database columns (shiftStart, shiftEnd, scheduledDate vs startTime, endTime, blockType)
- [ ] Update queries to use correct column names
- [ ] Test schedule grid loads without errors



## Add CSV Import Debug Logging
- [ ] Add console logging to CSV import endpoint to track upload process
- [ ] Log file received, parsing progress, data extraction, filtering, and database insertion
- [ ] Test with user's Amazon Relay CSV file



## Fix Schedule Page Layout
- [ ] Fix "null" values showing in start times list
- [ ] Create clean left sidebar with start times from Start Times table
- [ ] Show proper time, location, and contract type for each slot
- [ ] Fix calendar grid on right side
- [ ] Ensure drag-and-drop works between time slots and calendar



## Fix Start Times Showing Null
- [x] Check why startTime column is NULL in database
- [x] Fix import to properly save startTime values
- [x] Update Start Times page to display actual times
- [x] Saved contract start times to CONTRACT_START_TIMES.txt
- [x] Inserted 17 start times into database
- [ ] Verify Schedules page uses correct start times



## Add Collapsible Calendar Section
- [x] Add "> Calendar" collapsible button to Schedules page
- [x] Wrap weekly schedule grid in collapsible section
- [x] Add expand/collapse state management
- [x] Style to match reference screenshot



## Fix Block CSV Upload Null Errors
- [x] Debug CSV parser to find null value source
- [x] Found error: File upload using wrong parser function
- [x] Fix file upload handler in Schedules.tsx to use importBlocksMutation
- [x] Fix both drag-and-drop and file picker to use correct mutation
- [ ] Test with user's Amazon Relay CSV file
- [ ] Ensure blocks display after successful import



## Rebuild CSV Import From Scratch
- [x] Strip BOM character from CSV before parsing
- [x] Use cleaned CSV content in parser
- [ ] Test import with user's CSV file
- [ ] Display imported blocks list on Schedules page after import
- [ ] Show block details: ID, start time, duration, origin → destination



## Exact Match Blocks to Start Times
- [x] Parse Column AF (Stop 1 Planned Arrival Time) as start time
- [x] Only import blocks where AF exactly matches contract start times
- [x] Only import blocks for next week (starting Sunday 11/02)
- [x] Include next Sunday early morning (Saturday night shifts)
- [x] Group trips by Block ID before importing
- [x] Test import - should get 77-78 blocks
- [ ] Remove cost/money fields from block display




## CSV Upload Fix (Current Issue)
- [x] Fix CSV upload button not working (Button asChild with span issue)
- [x] Fix date parsing - showing "undefined, undefined NaN" instead of actual dates (keep dates as strings, not Date objects)
- [ ] Fix block count - only 32 blocks imported instead of 77 (added debug logging)
- [ ] Verify exact time matching works (17 fixed start times)
- [ ] Verify week boundary filtering works (Sun-Sat + following Sun morning)



## Week Filter Fix
- [x] Fix week calculation - now uses next Sunday (not earliest CSV date)
- [x] Update filterBlocksForWeek to use Sunday-Saturday (7 days, not 8)



## Week Calculation Fix (Nov 1, 2025 issue)
- [ ] Fix week calculation - currently importing Nov 3-9 2025, should import Nov 2-8 2025
- [ ] When on Friday Nov 1 2025, should calculate "upcoming Sunday" as Nov 2 2025 (not Nov 3)
- [ ] Verified: Nov 2 2025 is Sunday, Nov 8 2025 is Saturday



## Work Week Header
- [x] Add header showing "Work Week: Sunday November 3 - Saturday November 9"
- [x] Display calculated week range based on import logic



## 100-Year Week Calculation Fix
- [x] Fix week calculation to work for next 100 years without timezone issues
- [x] Use UTC dates for all calculations
- [ ] Test with various dates to ensure consistency

## Project Rename
- [x] Document how user can change names themselves (see HOW_TO_CHANGE_NAMES.md)
- [ ] User can change app title via Management UI → Settings → General
- [ ] Folder name doesn't need to change (doesn't affect functionality)



## Work Week Header Format Update
- [x] Change date format from "26/10/2025 - 01/11/2025" to "Nov 2 - Nov 8, 2025"
- [x] Add "week 45" display on the left
- [x] Match the style shown in the top header



## Imported Blocks Table Redesign
- [x] Match Amazon Relay layout exactly
- [x] Add Origin column with location + date/time
- [x] Add Destination column with location + date/time
- [x] Add arrow icon between origin/destination
- [x] Show Type as "Solo▲ 14h" format
- [x] Change Requirements to show "CDL" only (not BNSF_UIIA_EPA)
- [x] Remove Pay column
- [x] Fix date formatting to "Sun, Nov 2, 16:30 CST"



## Imported Blocks Table Fixes (Current Issues)
- [ ] Fix "Starts in NaNh NaNm" - date calculation broken
- [x] Fix origin showing raw date object - now uses Column F (Facility Sequence)
- [ ] Fix Solo2 logic to handle 2-day shifts properly
- [ ] Add countdown refresh every 15 minutes
- [x] Parse driver name from Column I (Driver Name) - needs DB matching next




## Fix Date Display Bug in CSV Import Table
- [x] Changed importedBlocks schema from DATE to VARCHAR(20) for startDate, endDate, weekStartDate
- [x] Altered database table columns to VARCHAR(20)
- [x] Cleared all imported blocks for fresh import
- [ ] User to test CSV import - dates should now display correctly as "Sun, Nov 2, 16:30 CST"
- [ ] Verify "Starts in" countdown shows "XXh XXm" instead of "NaNh NaNm"




## Parse Additional CSV Columns (Facility Sequence & Driver Name)
- [x] Analyze PRACTIVEFORMILO.csv to identify Column F (Facility Sequence) and Column I (Driver Name) formats
- [x] Update CSV parser to extract origin and destination from Facility Sequence (e.g., "MKC40->MKC6")
- [x] Update CSV parser to extract Driver Name from Column I
- [x] Match driver names to existing drivers in database (case-insensitive)
- [x] Auto-assign drivers if match found (set assignedDriverId)
- [x] Update BlocksTableView to display origin and destination in separate columns
- [ ] Test CSV import with new column parsing




## Filter CSV Import to Block Rows Only
- [x] Identify which column contains "Block" vs "Trip" indicator (Column C: Block/Trip)
- [x] Update CSV parser to only process rows where type = "Block"
- [x] Skip "Trip" rows (individual trips within blocks from previous week)
- [ ] Test import to verify only Block rows are imported




## Verify Work Week Filtering (Sunday 00:00 - Saturday 23:59)
- [x] Confirmed work week = Sunday 00:00 through Saturday 23:59
- [x] Verify filterBlocksForWeek correctly filters Sun-Sat only
- [x] Ensure Nov 1 (Sat) blocks are excluded from Nov 2-8 week
- [x] Verified 76 Block rows for Nov 2-8 (all match contract times)
- [ ] Test import to confirm only Nov 2-8 blocks are imported




## Fix Driver Type Matching in Auto-Assignment
- [x] Update auto-assignment to check driver type matches block contract type
- [x] Solo1 drivers should only be assigned to Solo1 blocks
- [x] Solo2 drivers should only be assigned to Solo2 blocks (can also do Solo1)
- [x] "Both" type drivers can be assigned to either Solo1 or Solo2 blocks
- [ ] Test auto-assignment with driver type validation

## Fix Week Navigation Bug
- [x] Identify where week navigation is implemented (handlePreviousWeek/handleNextWeek)
- [x] Added getBlocksByWeek query endpoint to filter by weekStartDate
- [x] Replaced local importedBlocks state with query that updates on week change
- [x] Blocks now stay in their original week (filtered by weekStartDate)
- [x] Nov 9 00:30 and 01:30 blocks will appear in Nov 9-15 week only
- [ ] Test week navigation to verify blocks don't carry over




## Fix Import Syntax Error and Default Week
- [x] Fix try-catch block syntax error in routers.ts
- [x] Change default week to "next Sunday" instead of current week
- [ ] Verify import works after syntax fix
- [ ] Test that login shows upcoming work week (Nov 2-8)




## Fix Work Week Display and Duplicate Blocks
- [x] Fix work week display showing wrong dates (use weekStartDate instead of min/max)
- [x] Clear old imported blocks before importing new ones (deleteImportedBlocksByWeek)
- [x] Verify only 76 blocks are imported for Nov 2-8 week
- [ ] Test that work week displays correctly as "Sunday Nov 2 - Saturday Nov 8"




## Parse Contract Type from Column J (Equipment Type)
- [x] Update CSV parser to read Column J (Equipment Type)
- [x] Extract Solo1/Solo2 from format "FTIM_MKC_Solo2_Tractor_1_d1"
- [x] Use string.includes() to match "Solo1" or "Solo2"
- [x] Store as contractType in database
- [ ] Test that blocks show correct Solo1▲ or Solo2▲ in table

## Week Assignment Rule (CONFIRMED)
- [x] Blocks appear in the week they are scheduled for (based on start date)
- [x] Nov 9 00:30/01:30 blocks → Nov 9-15 week
- [x] Nov 2 blocks → Nov 2-8 week
- [x] Week filtering logic is correct




## Fix Data Persistence Issue
- [x] Fixed type mismatch in getBlocksByWeek (was passing Date, should pass string)
- [x] Updated getImportedBlocksByWeek to accept string parameter
- [x] Query now correctly fetches blocks from database
- [ ] Test that blocks remain visible after navigating to other pages




## Add Sortable Column Filters
- [x] Add sorting state (sortColumn, sortDirection) to BlocksTableView
- [x] Implement sort logic for each column type
- [x] Add clickable column headers with sort indicators (↑/↓)
- [x] Sort by Block ID (alphanumeric)
- [x] Sort by Starts In (time remaining)
- [x] Sort by Origin (alphabetical)
- [x] Sort by Destination (alphabetical)
- [x] Sort by Type (Solo1/Solo2)
- [x] Sort by Equipment (alphabetical)
- [x] Sort by Assigned Driver (alphabetical)
- [ ] Test sorting functionality




## Fix Week Number Calculation
- [x] Update week number calculation to show US standard week (Sunday-Saturday)
- [x] Nov 2-8, 2025 now shows as Week 45 (fixed from Week 44)
- [x] Use proper week calculation formula (count Sundays from Jan 1)
- [ ] Test that week number displays correctly

## Import All Blocks with Valid Dates
- [x] Remove week filtering from CSV import
- [x] Import ALL blocks that have valid dates
- [x] Store weekStartDate based on block's actual start date (calculate Sunday of week)
- [x] Nov 9 00:30/01:30 blocks will be imported with Nov 9 dates
- [ ] Test that all blocks from CSV are imported




## Fix Missing Blocks B-V05GK3HS2 and B-B6XVT5ZDQ
- [ ] Check CSV data for these two blocks
- [ ] Verify they have "Block" type (not "Trip")
- [ ] Check if start times match contract times
- [ ] Verify dates are valid
- [ ] Check if they're being filtered out by parser
- [ ] Fix the issue and test import


- [x] Delete unused backup and demo files (ComponentShowcase.tsx, Home-old-backup.tsx, ai-scheduler-backup.ts)


- [x] Redesign Schedules page with Milo's rich color scheme and modern styling


- [x] Resize driver cards to match day header size
- [x] Remove scrolling from schedule grid (show all time slots on desktop, scroll on mobile)
- [x] Redesign drop zones with borderless floating effect


- [x] Reduce driver card height by 50%
- [x] Tone down driver card colors by 15%
- [x] Make driver sidebar scrollable
- [x] Add search function for drivers
- [x] Enhance 3D glassmorphism effect on driver cards


- [x] Create Auto-Schedule Configuration Panel (non-functional UI placeholder)


- [x] Make Auto-Schedule panel more compact and modern like Milo
- [x] Add color warnings: 70+ hours yellow, 84+ hours red


- [x] Create animated loading indicator with pulsing dots
- [x] Integrate loading indicator into Auto-Schedule and AI features


- [x] Fix Import Blocks button to open CSV upload dialog
- [x] Make CSV import actually work and store blocks in database
- [x] Display imported blocks in calendar as colored badges
- [x] Ensure table view and calendar view are synchronized


- [x] Redesign unpopulated block badges with gradient yellow/red and 3D glassmorphism


- [x] Fix calendar to display all 228 blocks (currently only 52 showing)
- [x] Reduce block card size by 10%


- [x] Research Monday.com, Homebase, Connecteam scheduling UX patterns
- [x] Remove bulky Auto-Schedule panel
- [x] Redesign scheduling interface to be clean and simple


- [x] Remove "304 blocks imported" message from calendar interface


- [x] Add unassigned blocks countdown that decreases as drivers are assigned



- [x] Change header to show "76 unassigned blocks" instead of "88 blocks imported" (smaller font)
- [x] Fix calendar grid missing 30+ blocks (should show all 76 unassigned blocks)



- [x] Move unassigned blocks count to new line under work week header



- [x] Fix duplicate time slot rows in calendar (group by time+type only, not origin)



- [ ] Merge "Table View/Calendar View" section with "Weekly Schedule Grid" section
- [x] Fix calendar to show multiple blocks per cell (changed from find to filter, updated TimeSlot to display array of blocks)
- [x] Create 17 separate calendar rows (one per contract) - blocks from same contract go in same row across days



- [x] Load 17 static start time contracts from database (configured in Milo section)
- [x] Calendar should display these 17 start times as rows, not derive from imported blocks
- [x] Fix calendar to show current week's Sunday (not next Sunday) - American week Sunday-Saturday



- [x] Fix calendar duplicate rows - use simple time+type grouping like table view (no tractor matching)




## Fix Duplicate Time Slot Rows in Calendar (CRITICAL BUG)
- [x] Identified root cause: Calendar grouped by startTime + contractType only, ignoring tractor assignments
- [x] Fixed CSV import to save Operator ID as truckFilter field (was NULL before)
- [x] Updated calendar grouping logic to extract tractor number from truckFilter using regex
- [x] Calendar now groups by startTime + contractType + tractorNum to create separate rows per tractor
- [x] Updated block matching logic to filter by tractor number
- [x] Kept UI clean - shows "20:30 Solo1" without tractor badge (tractor used internally only)
- [x] Tested and verified - calendar now shows separate rows for each tractor at same time (no duplicates)




## Calendar Display Issues (NEW BUGS)
- [x] Fix calendar year display - was timezone issue, resolved with UTC date parsing
- [x] Fix Saturday blocks not showing - changed from exact date matching to day-of-week matching
- [x] Update date matching logic to match blocks by day of week instead of exact date (blocks repeat weekly)
- [x] Fix timezone bug causing blocks to appear on wrong day - parse dates in UTC using Date.UTC() and getUTCDay()



## Calendar UI Improvements
- [x] Add horizontal scroll to calendar (for viewing all days when window is narrow)
- [x] Add vertical scroll to calendar (for viewing all time slots) - max height set to viewport minus 300px
- [x] Fix schedule not clearing properly after DELETE query - was browser cache, hard refresh needed




## Add Clear Schedule Button
- [x] Add "Clear Schedule" button to Schedules page header
- [x] Create mutation to delete all schedules for current user
- [x] Add confirmation dialog before clearing
- [x] Show success toast after clearing

