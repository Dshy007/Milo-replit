# DriverFlow - Code Package

## 📦 Package Contents

**Archive:** `driverflow-code.tar.gz` (135 KB)
**Total Files:** 97 files
**Lines of Code:** ~6,500 lines

---

## 📁 What's Inside

### Source Code
- **Frontend:** React 19 + TypeScript + Tailwind 4 (~3,000 lines)
- **Backend:** Node.js + Express + tRPC (~2,000 lines)
- **Database:** MySQL with Drizzle ORM
- **AI:** GPT-4o integration (Milo assistant)

### Documentation (~1,500 lines)
- `CODE_INDEX.md` - Complete code structure guide
- `PROJECT_SUMMARY.md` - Full development history
- `MILO_KNOWLEDGE_BASE.md` - Business logic (306 lines)
- `CONNECTTEAM_RESEARCH.md` - Competitor analysis
- `CONTRACT_START_TIMES.txt` - 17 fixed time slots
- `FILE_TREE.txt` - Directory structure

### Key Files
- `pages/Schedules.tsx` (1074 lines) - Main scheduling interface
- `server/ai.ts` (406 lines) - Milo AI implementation
- `lib/hosValidation.ts` - HOS compliance logic
- `lib/blockImportParser.ts` - CSV parsing logic
- `drizzle/schema.ts` - Database schema
- `server/db.ts` - Database operations

---

## 🚀 Quick Start

```bash
# Extract archive
tar -xzf driverflow-code.tar.gz

# Navigate to code
cd driverflow-code

# View structure
cat FILE_TREE.txt

# Read documentation
cat CODE_INDEX.md
```

---

## 📖 Recommended Reading Order

1. `CODE_INDEX.md` - Code structure overview
2. `PROJECT_SUMMARY.md` - Complete project history
3. `MILO_KNOWLEDGE_BASE.md` - Business logic
4. `pages/Schedules.tsx` - Main UI implementation
5. `server/ai.ts` - Milo AI implementation

---

## 🎯 Key Features

1. **CSV Import** - Exact time matching to 17 fixed start times
2. **Drag-and-Drop Scheduling** - Visual calendar with HOS validation
3. **Milo AI Assistant** - GPT-4o with function calling
4. **HOS Compliance** - 10-hour rest rule validation
5. **Auto-Build** - Copy and optimize from last week

---

See `CODE_INDEX.md` for complete analysis guide!
