import { processSchedulingCommand } from './server/ai-scheduler.ts';

async function test() {
  try {
    console.log("Testing Milo AI...");
    const result = await processSchedulingCommand(
      "how many tractors do I have?",
      {
        weekStart: "2025-10-26",
        driverCount: 42,
        driverNames: [],
        scheduleSlotCount: 0,
        startTimeCount: 0,
        userId: 1,
        drivers: [],
        tractors: [
          { tractorNumber: "921158", make: "Freightliner", model: "Sleeper", contractType: "Solo2", status: "active" },
          { tractorNumber: "921157", make: "Freightliner", model: "Sleeper", contractType: "Solo2", status: "active" }
        ],
        schedules: [],
      }
    );
    console.log("✅ SUCCESS:", result);
  } catch (error) {
    console.error("❌ ERROR:", error.message);
    console.error("STACK:", error.stack);
  }
}

test();
