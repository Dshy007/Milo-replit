import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);

console.log('\n=== Testing Week Query ===\n');

// Get all distinct weekStartDate values
const [weeks] = await connection.query(`
  SELECT DISTINCT weekStartDate 
  FROM imported_blocks 
  ORDER BY weekStartDate
`);

console.log('Distinct weekStartDate values:');
weeks.forEach((w, i) => {
  console.log(`  ${i + 1}. "${w.weekStartDate}" (length: ${w.weekStartDate?.length})`);
});

// Count blocks per week
console.log('\nBlocks per week:');
for (const week of weeks) {
  const [blocks] = await connection.query(`
    SELECT blockId, startDate, startTime, userId
    FROM imported_blocks
    WHERE weekStartDate = ?
    ORDER BY startDate, startTime
    LIMIT 5
  `, [week.weekStartDate]);
  
  console.log(`  ${week.weekStartDate}: ${blocks.length}+ blocks`);
  
  // Show first 3 blocks
  blocks.slice(0, 3).forEach(b => {
    console.log(`    - ${b.blockId} (${b.startDate} ${b.startTime}, userId: ${b.userId})`);
  });
}

// Check the Nov 9 blocks specifically
console.log('\n=== Nov 9 Blocks ===');
const [nov9Blocks] = await connection.query(`
  SELECT id, blockId, userId, startDate, startTime, weekStartDate
  FROM imported_blocks
  WHERE blockId IN ('B-V05GK3HS2', 'B-B6XVT5ZDQ')
  ORDER BY id
`);

console.log(`Found ${nov9Blocks.length} blocks for Nov 9:`);
nov9Blocks.forEach(b => {
  console.log(`  ${b.blockId}: ID=${b.id}, userId=${b.userId}, startDate=${b.startDate}, startTime=${b.startTime}, weekStartDate="${b.weekStartDate}"`);
});

await connection.end();
process.exit(0);

