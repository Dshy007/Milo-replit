# How to Change Project Names in DriverFlow

This guide shows you exactly where to change the project name, app title, and branding.

---

## 🎯 Quick Summary

**Current Names:**
- Project folder: `laminar-copilot-clone`
- App title: "Milo" (or "Driver Flo")
- Internal project name: Can be changed in Management UI

**To Change:**
1. **App Title** (what users see) → Management UI Settings
2. **Project Folder** → Can't rename (doesn't affect functionality)
3. **Internal References** → See below

---

## 1️⃣ Change App Title (Easiest - No Code!)

**Via Management UI:**
1. Open your app: https://3000-iztzkv4vo8unbs9qm36tt-bb9f3b71.manusvm.computer
2. Click the **Settings icon** (⚙️) in the top-right header
3. Go to **Settings → General**
4. Change **"Website name"** to "DriverFlow" or "Milo"
5. Click **Save**

This updates the `VITE_APP_TITLE` environment variable automatically!

---

## 2️⃣ Change App Logo (Optional)

**Via Management UI:**
1. Go to **Settings → General**
2. Upload a new logo image
3. Click **Save**

This updates the `VITE_APP_LOGO` environment variable.

---

## 3️⃣ Change Internal Code References (Advanced)

If you want to change names in the code itself:

### **File: `client/src/const.ts`** (Line 3)
```typescript
export const APP_TITLE = import.meta.env.VITE_APP_TITLE || "DriverFlow";
//                                                           ^^^^^^^^^^
//                                                           Change fallback name here
```

### **File: `package.json`** (Line 2)
```json
{
  "name": "driverflow",
  //      ^^^^^^^^^^
  //      Change package name here (use lowercase, no spaces)
}
```

### **File: `client/index.html`** (Line 7)
```html
<title>DriverFlow</title>
<!--    ^^^^^^^^^^
        Change browser tab title here -->
```

---

## 4️⃣ Project Folder Name

**Note:** The folder name `laminar-copilot-clone` is just the directory name on the server. It doesn't affect:
- What users see
- How the app works
- The app title or branding

**To rename the folder** (not recommended):
1. This requires server access
2. You'd need to update deployment configs
3. **Better option:** Just change the app title in Settings!

---

## ✅ Recommended Approach

**For most users:**
1. Use **Management UI → Settings → General** to change the website name
2. Upload a custom logo if desired
3. Done! No code changes needed.

**For developers:**
1. Update `package.json` name
2. Update `client/index.html` title
3. Update `const.ts` fallback value
4. Commit changes to version control

---

## 🎨 Current Branding

**App Title:** Milo (set via `VITE_APP_TITLE`)
**Logo:** Purple smiley face (default SVG)
**Theme:** Light mode with blue accents

To change any of these, use the Management UI Settings panel!

