import fs from 'fs';
import { parseAmazonCSV } from './server/csv-import.ts';
import * as db from './server/db.ts';

console.log('\n=== Re-importing CSV with Fixed weekStartDate ===\n');

// Read the CSV file
const csvContent = fs.readFileSync('/home/ubuntu/Downloads/relay_blocks.csv', 'utf-8');

// Parse the CSV
console.log('Parsing CSV...');
const allBlocks = parseAmazonCSV(csvContent);
console.log(`Parsed ${allBlocks.length} blocks`);

// Helper function to calculate Sunday of the week (FIXED VERSION)
const getSundayOfWeek = (dateStr) => {
  // Parse date in local time to avoid timezone issues
  const parts = dateStr.split('-');
  const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
  
  const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
  const sunday = new Date(date);
  sunday.setDate(date.getDate() - dayOfWeek); // Go back to Sunday
  
  // Format as YYYY-MM-DD
  const year = sunday.getFullYear();
  const month = String(sunday.getMonth() + 1).padStart(2, '0');
  const day = String(sunday.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Test the function with Nov 9
console.log('\nTesting getSundayOfWeek with Nov 9, 2025:');
const testDate = '2025-11-09';
const testResult = getSundayOfWeek(testDate);
console.log(`  Input: ${testDate}`);
console.log(`  Output: ${testResult}`);
console.log(`  Expected: 2025-11-09 (since Nov 9 is Sunday)`);
console.log(`  ✓ ${testResult === '2025-11-09' ? 'PASS' : 'FAIL'}`);

// Import blocks into database
console.log('\nImporting blocks into database...');
const userId = 1; // Default user ID

let imported = 0;
for (const block of allBlocks) {
  const weekStartDate = getSundayOfWeek(block.startDate);
  
  await db.createImportedBlock({
    userId,
    blockId: block.blockId,
    driverName: block.driverName,
    startDate: block.startDate,
    startTime: block.startTime,
    endDate: block.endDate,
    endTime: block.endTime,
    contractType: block.contractType,
    duration: block.duration,
    payRate: block.payRate,
    origin: block.origin,
    destination: block.destination,
    equipmentType: block.equipmentType,
    truckFilter: block.truckFilter,
    weekStartDate,
    assignedDriverId: null,
  });
  
  imported++;
  if (imported <= 3 || imported === allBlocks.length) {
    console.log(`  ${imported}/${allBlocks.length}: ${block.blockId} (${block.startDate}, week: ${weekStartDate})`);
  }
}

console.log(`\n✓ Successfully imported ${imported} blocks`);

// Verify Nov 9 blocks
console.log('\nVerifying Nov 9 blocks...');
const nov9Blocks = await db.getImportedBlocksByWeek(userId, '2025-11-09');
console.log(`Found ${nov9Blocks.length} blocks for week starting Nov 9, 2025`);
nov9Blocks.slice(0, 5).forEach(b => {
  console.log(`  - ${b.blockId} (${b.startDate} ${b.startTime})`);
});

process.exit(0);

