import * as hosValidator from "./hos-validator";

export interface Driver {
  id: number;
  name: string;
  driverType: "Solo1" | "Solo2" | "PartTime";
  preferredStartTime: string; // e.g., "00:30"
  maxConsecutiveDays: number;
  status: string;
}

export interface ScheduleSlot {
  day: string; // "Sunday", "Monday", etc.
  timeSlot: string; // "00:30", "01:30", etc.
  driverId: number;
  driverName: string;
  blockType: "Solo1" | "Solo2";
}

export interface AutoScheduleResult {
  schedule: ScheduleSlot[];
  unassignedDrivers: Driver[];
  violations: any[];
  warnings: string[];
}

/**
 * Auto-build weekly schedule based on driver preferences
 */
export function autoBuildWeeklySchedule(
  drivers: Driver[],
  weekStartDate: Date
): AutoScheduleResult {
  const schedule: ScheduleSlot[] = [];
  const unassignedDrivers: Driver[] = [];
  const violations: any[] = [];
  const warnings: string[] = [];

  const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  
  // Sort drivers by type priority: Solo1 > Solo2 > PartTime
  const sortedDrivers = [...drivers].sort((a, b) => {
    const priority = { Solo1: 3, Solo2: 2, PartTime: 1 };
    return priority[b.driverType] - priority[a.driverType];
  });

  // Track assigned slots to prevent conflicts
  const assignedSlots = new Set<string>();

  for (const driver of sortedDrivers) {
    if (driver.status !== "Active") {
      unassignedDrivers.push(driver);
      continue;
    }

    const preferredTime = driver.preferredStartTime || "08:30";
    
    if (driver.driverType === "Solo1") {
      // Solo1: Assign 4 consecutive days
      let assigned = 0;
      for (let dayOffset = 0; dayOffset < 7 && assigned < 4; dayOffset++) {
        const day = DAYS_OF_WEEK[dayOffset];
        const slotKey = `${day}_${preferredTime}`;
        
        if (!assignedSlots.has(slotKey)) {
          schedule.push({
            day,
            timeSlot: preferredTime,
            driverId: driver.id,
            driverName: driver.name,
            blockType: "Solo1"
          });
          assignedSlots.add(slotKey);
          assigned++;
        }
      }
      
      if (assigned < 4) {
        warnings.push(`${driver.name} (Solo1) only assigned ${assigned}/4 blocks - not enough available slots at ${preferredTime}`);
      }
      
    } else if (driver.driverType === "Solo2") {
      // Solo2: Assign 2 consecutive blocks (38-hour shifts)
      let assigned = 0;
      for (let dayOffset = 0; dayOffset < 7 && assigned < 2; dayOffset += 2) {
        const day = DAYS_OF_WEEK[dayOffset];
        const slotKey = `${day}_${preferredTime}`;
        
        if (!assignedSlots.has(slotKey)) {
          schedule.push({
            day,
            timeSlot: preferredTime,
            driverId: driver.id,
            driverName: driver.name,
            blockType: "Solo2"
          });
          assignedSlots.add(slotKey);
          assigned++;
        }
      }
      
      if (assigned < 2) {
        warnings.push(`${driver.name} (Solo2) only assigned ${assigned}/2 blocks - not enough available slots at ${preferredTime}`);
      }
      
    } else if (driver.driverType === "PartTime") {
      // Part-time: Assign specific pattern (e.g., Sat/Sun/Mon for Firas/Tareef)
      const partTimeDays = ["Saturday", "Sunday", "Monday"];
      let assigned = 0;
      
      for (const day of partTimeDays) {
        const slotKey = `${day}_${preferredTime}`;
        
        if (!assignedSlots.has(slotKey)) {
          schedule.push({
            day,
            timeSlot: preferredTime,
            driverId: driver.id,
            driverName: driver.name,
            blockType: "Solo1" // Part-time uses Solo1 block type
          });
          assignedSlots.add(slotKey);
          assigned++;
        }
      }
      
      if (assigned === 0) {
        unassignedDrivers.push(driver);
      }
    }
  }

  // Validate HOS compliance for generated schedule
  const shifts = schedule.map(slot => {
    const dayIndex = DAYS_OF_WEEK.indexOf(slot.day);
    const date = new Date(weekStartDate);
    date.setDate(date.getDate() + dayIndex);
    
    const [hours, minutes] = slot.timeSlot.split(':').map(Number);
    const startTime = new Date(date);
    startTime.setHours(hours, minutes, 0, 0);
    
    const endTime = new Date(startTime);
    const duration = slot.blockType === "Solo1" ? 14 : 38;
    endTime.setHours(endTime.getHours() + duration);
    
    return {
      driverId: slot.driverId,
      startTime,
      endTime,
      blockType: slot.blockType
    };
  });

  const driverList = drivers.map(d => ({
    id: d.id,
    name: d.name,
    maxConsecutiveDays: d.maxConsecutiveDays
  }));

  const validation = hosValidator.validateSchedule(shifts, driverList);
  violations.push(...validation.violations);
  warnings.push(...validation.warnings);

  return {
    schedule,
    unassignedDrivers,
    violations,
    warnings
  };
}

/**
 * Get available time slots for a given day
 */
export function getAvailableTimeSlots(
  day: string,
  existingSchedule: ScheduleSlot[]
): string[] {
  // Common AFP start times
  const allTimeSlots = [
    "00:30", "01:30", "02:30", "03:30", "04:30", "05:30",
    "06:30", "07:30", "08:30", "09:30", "10:30", "11:30",
    "12:30", "13:30", "14:30", "15:30", "16:30", "17:30",
    "18:30", "19:30", "20:30", "21:30", "22:30", "23:30"
  ];

  const assignedSlots = new Set(
    existingSchedule
      .filter(slot => slot.day === day)
      .map(slot => slot.timeSlot)
  );

  return allTimeSlots.filter(time => !assignedSlots.has(time));
}

/**
 * Suggest optimal start time for a driver based on existing schedule
 */
export function suggestStartTime(
  driver: Driver,
  existingSchedule: ScheduleSlot[],
  targetDay: string
): string | null {
  // First try preferred time
  const preferredTime = driver.preferredStartTime || "08:30";
  const availableSlots = getAvailableTimeSlots(targetDay, existingSchedule);
  
  if (availableSlots.includes(preferredTime)) {
    return preferredTime;
  }
  
  // Find closest available time to preferred
  const [preferredHour, preferredMin] = preferredTime.split(':').map(Number);
  const preferredMinutes = preferredHour * 60 + preferredMin;
  
  let closestTime = availableSlots[0] || null;
  let minDiff = Infinity;
  
  for (const time of availableSlots) {
    const [hour, min] = time.split(':').map(Number);
    const minutes = hour * 60 + min;
    const diff = Math.abs(minutes - preferredMinutes);
    
    if (diff < minDiff) {
      minDiff = diff;
      closestTime = time;
    }
  }
  
  return closestTime;
}

/**
 * Fill gaps in schedule with available drivers
 */
export function fillScheduleGaps(
  existingSchedule: ScheduleSlot[],
  availableDrivers: Driver[],
  weekStartDate: Date
): ScheduleSlot[] {
  const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const additionalSlots: ScheduleSlot[] = [];
  
  // Find gaps (empty time slots on each day)
  for (const day of DAYS_OF_WEEK) {
    const availableSlots = getAvailableTimeSlots(day, existingSchedule);
    
    for (const timeSlot of availableSlots) {
      // Try to find an available driver for this slot
      for (const driver of availableDrivers) {
        if (driver.status !== "Active") continue;
        
        // Check if driver already has too many assignments this week
        const driverAssignments = [
          ...existingSchedule,
          ...additionalSlots
        ].filter(slot => slot.driverId === driver.id);
        
        const maxAssignments = driver.driverType === "Solo1" ? 4 : driver.driverType === "Solo2" ? 2 : 3;
        
        if (driverAssignments.length < maxAssignments) {
          additionalSlots.push({
            day,
            timeSlot,
            driverId: driver.id,
            driverName: driver.name,
            blockType: driver.driverType === "Solo2" ? "Solo2" : "Solo1"
          });
          break; // Move to next time slot
        }
      }
    }
  }
  
  return additionalSlots;
}

