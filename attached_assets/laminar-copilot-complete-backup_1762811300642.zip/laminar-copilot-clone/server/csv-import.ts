import { parse } from 'csv-parse/sync';

export interface ParsedBlock {
  blockId: string;
  driverName: string | null;
  startDate: string; // YYYY-MM-DD format
  startTime: string; // HH:MM format
  endDate: string | null;
  endTime: string | null;
  contractType: string; // Solo1 or Solo2
  duration: string | null;
  payRate: string | null;
  origin: string | null;
  destination: string | null;
  equipmentType: string | null;
  truckFilter: string | null;
}

// Your 17 contract start times (in HH:MM format)
const CONTRACT_START_TIMES = [
  '00:30', '01:30', '08:30', '11:30', '15:30',
  '16:30', '17:30', '18:30', '20:30', '21:30', '23:30'
];

/**
 * Parse Amazon Relay CSV and extract blocks that match contract start times
 */
export function parseAmazonCSV(csvContent: string): ParsedBlock[] {
  // Remove BOM if present
  const cleanContent = csvContent.replace(/^\uFEFF/, '');
  
  const records = parse(cleanContent, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true, // Handle BOM automatically
  });

  const blockMap = new Map<string, ParsedBlock>();

  for (const record of records as any[]) {
    // Only process "Block" rows, skip "Trip" rows
    const rowType = record['Block/Trip'];
    if (rowType !== 'Block') continue;
    
    const blockId = record['Block ID'];
    if (!blockId) continue;

    // Parse Column AF: Stop 1 Planned Arrival Time
    const startTimeStr = record['Stop 1  Planned Arrival Time'] || record['Stop 1 Planned Arrival Time'];
    if (!startTimeStr) continue;

    // Convert to HH:MM format
    const startTime = parseTime(startTimeStr);
    if (!startTime) continue;

    // EXACT MATCH: Only accept blocks that match contract start times
    if (!CONTRACT_START_TIMES.includes(startTime)) {
      // Log first few rejected times for debugging
      if (blockMap.size < 5) {
        console.log(`[CSV Parse] Rejected block ${blockId} - time ${startTime} not in contract times`);
      }
      continue;
    }

    // Parse Column AE: Stop 1 Planned Arrival Date
    const startDateStr = record['Stop 1  Planned Arrival Date'] || record['Stop 1 Planned Arrival Date'];
    if (!startDateStr) continue;

    const startDate = convertDate(startDateStr);
    if (!startDate) continue;

    // Parse Column 19: Operator ID for contract type (e.g., "FTIM_MKC_Solo2_Tractor_6_d1")
    const operatorId = record['Operator ID'] || null;
    let contractType = 'Solo1'; // Default
    if (operatorId) {
      if (operatorId.includes('Solo2')) {
        contractType = 'Solo2';
      } else if (operatorId.includes('Solo1')) {
        contractType = 'Solo1';
      }
    }
    
    // Use Operator ID as truckFilter (contains tractor number)
    const truckFilter = operatorId;

    // Parse Column F: Facility Sequence (origin->destination)
    const facilitySequence = record['Facility Sequence'] || null;
    let origin: string | null = null;
    let destination: string | null = null;
    
    if (facilitySequence && facilitySequence.includes('->')) {
      const parts = facilitySequence.split('->');
      origin = parts[0]?.trim() || null;
      destination = parts[1]?.trim() || null;
    } else {
      origin = facilitySequence;
    }
    
    // Parse Column I: Driver Name
    const driverName = record['Driver Name'] || null;
    
    // Group by Block ID (take first occurrence)
    if (!blockMap.has(blockId)) {
      blockMap.set(blockId, {
        blockId,
        driverName,
        startDate,
        startTime,
        endDate: null,
        endTime: null,
        contractType,
        duration: null,
        payRate: null,
        origin,
        destination,
        equipmentType: null,
        truckFilter,
      });
    }
  }

  const result = Array.from(blockMap.values());
  console.log(`[CSV Parse] Total blocks after exact time matching: ${result.length}`);
  console.log(`[CSV Parse] Contract start times: ${CONTRACT_START_TIMES.join(', ')}`);
  return result;
}

/**
 * Convert MM/DD/YYYY to YYYY-MM-DD
 * Returns a valid date string that can be parsed by new Date()
 */
function convertDate(dateStr: string): string | null {
  if (!dateStr) return null;
  
  const parts = dateStr.trim().split('/');
  if (parts.length !== 3) return null;
  
  const [month, day, year] = parts;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  if (isNaN(monthNum) || isNaN(dayNum) || isNaN(yearNum)) return null;
  if (monthNum < 1 || monthNum > 12) return null;
  if (dayNum < 1 || dayNum > 31) return null;
  
  // Return ISO format string: YYYY-MM-DD
  return `${yearNum}-${String(monthNum).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
}

/**
 * Parse time string to HH:MM format
 */
function parseTime(timeStr: string): string | null {
  if (!timeStr) return null;
  
  // Handle formats like "3:07", "16:30", "0:30"
  const match = timeStr.match(/^(\d{1,2}):(\d{2})$/);
  if (match) {
    const hours = match[1].padStart(2, '0');
    const minutes = match[2];
    return `${hours}:${minutes}`;
  }
  
  return null;
}

/**
 * Filter blocks for a specific week (Sunday through Saturday)
 * Includes next Sunday's early morning blocks (Saturday night shifts)
 */
export function filterBlocksForWeek(blocks: ParsedBlock[], weekStartDate: Date): ParsedBlock[] {
  const weekStart = new Date(weekStartDate);
  weekStart.setHours(0, 0, 0, 0);
  
  // Sunday through Saturday (7 days)
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7); // +7 days = through next Sunday 00:00
  
  console.log(`[Week Filter] Week range: ${weekStart.toISOString().split('T')[0]} to ${weekEnd.toISOString().split('T')[0]}`);
  console.log(`[Week Filter] Total blocks to filter: ${blocks.length}`);
  
  const filtered = blocks.filter(block => {
    const blockDate = new Date(block.startDate);
    const inRange = blockDate >= weekStart && blockDate < weekEnd;
    if (!inRange && blocks.indexOf(block) < 5) {
      console.log(`[Week Filter] Block ${block.blockId} (${block.startDate}) is OUTSIDE range`);
    }
    return inRange;
  });
  
  console.log(`[Week Filter] Filtered blocks: ${filtered.length}`);
  return filtered;
}

/**
 * Get the Sunday of next week based on current date
 */
export function getNextWeekSunday(): Date {
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  
  // Calculate days until next Sunday
  const daysUntilNextSunday = dayOfWeek === 0 ? 7 : (7 - dayOfWeek);
  
  const nextSunday = new Date(today);
  nextSunday.setDate(today.getDate() + daysUntilNextSunday);
  nextSunday.setHours(0, 0, 0, 0);
  
  return nextSunday;
}

