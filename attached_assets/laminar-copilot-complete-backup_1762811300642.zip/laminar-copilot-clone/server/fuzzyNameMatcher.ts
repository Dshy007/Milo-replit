/**
 * Server-side intelligent fuzzy name matching for driver names
 * Handles partial names, misspellings, nicknames, and various formats
 */

export interface Driver {
  id: number;
  name: string;
  driverType?: "Solo1" | "Solo2" | "Both" | null;
  status?: string;
}

export interface MatchResult {
  driver: Driver;
  confidence: number;
  matchType: string;
}

// Common nickname mappings
const NICKNAMES: Record<string, string[]> = {
  robert: ['bob', 'rob', 'bobby'],
  mathew: ['matt', 'matthew', 'mat'],
  matthew: ['matt', 'mathew', 'mat'],
  william: ['will', 'bill', 'billy'],
  richard: ['rick', 'dick', 'rich'],
  brian: ['bryan'],
  michael: ['mike', 'mich'],
  joshua: ['josh'],
  raymond: ['ray'],
};

function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

function normalizeName(name: string): string {
  return name.toLowerCase().trim().replace(/[.,;]/g, '').replace(/\s+/g, ' ');
}

function splitName(name: string): string[] {
  return normalizeName(name).split(/[\s;]+/).filter(p => p.length > 0);
}

function matchesWithNickname(searchTerm: string, namePart: string): boolean {
  const searchLower = searchTerm.toLowerCase();
  const nameLower = namePart.toLowerCase();
  
  if (nameLower === searchLower || nameLower.includes(searchLower) || searchLower.includes(nameLower)) {
    return true;
  }
  
  const nicknames = NICKNAMES[nameLower] || [];
  if (nicknames.includes(searchLower)) return true;
  
  for (const [fullName, nicks] of Object.entries(NICKNAMES)) {
    if (nicks.includes(searchLower) && nameLower === fullName) return true;
  }
  
  return false;
}

export function findDriverByName(
  drivers: Driver[],
  searchName: string,
  minConfidence: number = 50
): MatchResult | null {
  const searchNormalized = normalizeName(searchName);
  const searchParts = splitName(searchName);
  
  const matches: MatchResult[] = [];

  for (const driver of drivers) {
    const driverNormalized = normalizeName(driver.name);
    const driverParts = splitName(driver.name);
    
    // Exact match
    if (driverNormalized === searchNormalized) {
      matches.push({ driver, confidence: 100, matchType: 'exact' });
      continue;
    }
    
    // Contains match
    if (driverNormalized.includes(searchNormalized) || searchNormalized.includes(driverNormalized)) {
      matches.push({ driver, confidence: 95, matchType: 'contains' });
      continue;
    }
    
    // Last name match
    const driverLastName = driverParts[driverParts.length - 1];
    if (searchParts.length === 1 && matchesWithNickname(searchParts[0], driverLastName)) {
      matches.push({ driver, confidence: 90, matchType: 'last_name' });
      continue;
    }
    
    // First name match
    const driverFirstName = driverParts[0];
    if (searchParts.length === 1 && matchesWithNickname(searchParts[0], driverFirstName)) {
      matches.push({ driver, confidence: 85, matchType: 'first_name' });
      continue;
    }
    
    // Levenshtein distance
    const distance = levenshteinDistance(searchNormalized, driverNormalized);
    const maxLen = Math.max(searchNormalized.length, driverNormalized.length);
    const similarity = ((maxLen - distance) / maxLen) * 100;
    
    if (similarity >= 70) {
      matches.push({ driver, confidence: similarity, matchType: 'fuzzy' });
    }
    
    // Partial word matches
    let partialMatchCount = 0;
    for (const searchPart of searchParts) {
      for (const driverPart of driverParts) {
        if (matchesWithNickname(searchPart, driverPart)) {
          partialMatchCount++;
          break;
        }
      }
    }
    
    if (partialMatchCount > 0) {
      const partialConfidence = (partialMatchCount / searchParts.length) * 80;
      if (partialConfidence >= minConfidence) {
        matches.push({ driver, confidence: partialConfidence, matchType: 'partial' });
      }
    }
  }
  
  if (matches.length === 0) return null;
  
  matches.sort((a, b) => b.confidence - a.confidence);
  const bestMatch = matches[0];
  
  return bestMatch.confidence >= minConfidence ? bestMatch : null;
}

export function findAllMatches(
  drivers: Driver[],
  searchName: string,
  minConfidence: number = 50,
  maxResults: number = 5
): MatchResult[] {
  const matches: MatchResult[] = [];
  
  for (const driver of drivers) {
    const result = findDriverByName([driver], searchName, 0);
    if (result && result.confidence >= minConfidence) {
      matches.push(result);
    }
  }
  
  matches.sort((a, b) => b.confidence - a.confidence);
  return matches.slice(0, maxResults);
}

