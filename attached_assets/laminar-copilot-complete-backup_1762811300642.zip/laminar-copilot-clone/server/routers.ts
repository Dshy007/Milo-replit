import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import * as importService from "./import";
import * as hosValidator from "./hos-validator";
import * as notifications from "./notifications";
import * as autoScheduler from "./auto-scheduler";
import * as aiScheduler from "./ai-scheduler";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Driver Management
  drivers: router({
    list: publicProcedure.query(async ({ ctx }) => {
      // For testing: pass 0 as userId (will return all drivers)
      return await db.getDriversByUserId(ctx.user?.id || 0);
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getDriverById(input.id);
      }),
    
    create: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        licenseNumber: z.string().optional(),
        driverType: z.enum(["Solo1", "Solo2", "Both"]).optional(),
        preferredStartTime: z.string().optional(),
        availableDays: z.array(z.string()).optional(),
        status: z.enum(["active", "inactive", "on_leave"]).default("active"),
      }))
      .mutation(async ({ ctx, input }) => {
        const { availableDays, ...rest } = input;
        return await db.createDriver({
          userId: ctx.user?.id || 0,
          ...rest,
          availableDays: availableDays ? JSON.stringify(availableDays) : undefined,
        });
      }),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        licenseNumber: z.string().optional(),
        driverType: z.enum(["Solo1", "Solo2", "Both"]).optional(),
        preferredStartTime: z.string().optional(),
        availableDays: z.array(z.string()).optional(),
        status: z.enum(["active", "inactive", "on_leave"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, availableDays, ...data } = input;
        return await db.updateDriver(id, {
          ...data,
          availableDays: availableDays ? JSON.stringify(availableDays) : undefined,
        });
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteDriver(input.id);
        return { success: true };
      }),
    
    // Availability slots management
    getAvailabilitySlots: publicProcedure
      .input(z.object({ driverId: z.number() }))
      .query(async ({ input }) => {
        return await db.getDriverAvailabilitySlots(input.driverId);
      }),
    
    saveAvailabilitySlots: publicProcedure
      .input(z.object({
        driverId: z.number(),
        slots: z.array(z.object({
          dayOfWeek: z.string(),
          startTime: z.string(),
        }))
      }))
      .mutation(async ({ input }) => {
        // Delete existing slots for this driver
        await db.deleteDriverAvailabilitySlots(input.driverId);
        // Insert new slots
        if (input.slots.length > 0) {
          await db.createDriverAvailabilitySlots(input.driverId, input.slots);
        }
        return { success: true };
      }),
  }),

  // Tractor Management
  tractors: router({
    list: publicProcedure.query(async ({ ctx }) => {
      return await db.getTractorsByUserId(ctx.user?.id || 0);
    }),
    
    listStartTimes: publicProcedure.query(async ({ ctx }) => {
      return await db.getStartTimesByUserId(ctx.user?.id || 0);
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getTractorById(input.id);
      }),
    
    create: publicProcedure
      .input(z.object({
        tractorNumber: z.string(),
        make: z.string().optional(),
        model: z.string().optional(),
        year: z.number().optional(),
        fuel: z.string().optional(),
        vin: z.string().optional(),
        licensePlate: z.string().optional(),
        status: z.enum(["active", "maintenance", "out_of_service"]).default("active"),
      }))
      .mutation(async ({ ctx, input }) => {
        return await db.createTractor({
          userId: ctx.user?.id || 0,
          entryType: "fleet" as const,
          ...input,
        });
      }),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        tractorNumber: z.string().optional(),
        make: z.string().optional(),
        model: z.string().optional(),
        year: z.number().optional(),
        fuel: z.string().optional(),
        vin: z.string().optional(),
        licensePlate: z.string().optional(),
        status: z.enum(["active", "maintenance", "out_of_service"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateTractor(id, data);
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteTractor(input.id);
      }),
    
    importStartTimes: publicProcedure
      .input(z.object({
        data: z.array(z.object({
          tractorNumber: z.string(),
          startTime: z.string(),
          contractType: z.string(),
          domicile: z.string(),
          status: z.enum(["active", "maintenance", "out_of_service"]).optional(),
        }))
      }))
      .mutation(async ({ ctx, input }) => {
        // Always create new entries for start times (allow duplicates)
        const results = [];
        for (const item of input.data) {
          // Create new tractor entry for each start time
          const created = await db.createTractor({
            userId: ctx.user?.id || 0,
            tractorNumber: item.tractorNumber,
            entryType: "start_time" as const,
            startTime: item.startTime,
            contractType: item.contractType,
            domicile: item.domicile,
            status: item.status || "active",
          });
          results.push(created);
        }
        return results;
      }),
  }),

  // Schedules
  schedules: router({
    list: publicProcedure.query(async ({ ctx }) => {
      return await db.getSchedulesByUserId(ctx.user?.id || 0);
    }),
    
    create: publicProcedure
      .input(z.object({
        routeId: z.number(),
        driverId: z.number().optional(),
        tractorId: z.number().optional(),
        scheduledDate: z.string(),
        shiftStart: z.string().optional(),
        shiftEnd: z.string().optional(),
        status: z.enum(["scheduled", "confirmed", "in_progress", "completed", "cancelled"]).default("scheduled"),
      }))
      .mutation(async ({ ctx, input }) => {
        return await db.createSchedule({
          userId: ctx.user?.id || 0,
          ...input,
          scheduledDate: new Date(input.scheduledDate),
        });
      }),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        driverId: z.number().optional(),
        tractorId: z.number().optional(),
        status: z.enum(["scheduled", "confirmed", "in_progress", "completed", "cancelled"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateSchedule(id, data);
      }),
    
    clearAll: publicProcedure
      .mutation(async ({ ctx }) => {
        const userId = ctx.user?.id || 0;
        // Delete all schedules for this user
        await db.deleteSchedulesByUserId(userId);
        return { success: true, message: 'All schedules cleared' };
      }),
  }),

  // CSV Import
  import: router({
    amazonBlocks: publicProcedure
      .input(z.object({
        csvContent: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          console.log('\n========== CSV IMPORT STARTED ==========');
          console.log('User ID:', ctx.user?.id || 0);
          console.log('CSV Content Length:', input.csvContent.length, 'characters');
        
          // Strip BOM (Byte Order Mark) if present
          let csvContent = input.csvContent;
          if (csvContent.charCodeAt(0) === 0xFEFF) {
            console.log('Detected and removing BOM character');
            csvContent = csvContent.substring(1);
          }
          
          console.log('First 200 chars:', csvContent.substring(0, 200));
          
          const csvImport = await import('./csv-import');
          
          // Parse CSV with cleaned content
          const allBlocks = csvImport.parseAmazonCSV(csvContent);
          console.log('\n--- PARSING COMPLETE ---');
          console.log('Total blocks parsed:', allBlocks.length);
          console.log('Sample block:', allBlocks[0]);
          
          // Helper function to calculate Sunday of the week for a given date
          const getSundayOfWeek = (dateStr: string): string => {
            // Parse date in local time to avoid timezone issues
            const parts = dateStr.split('-');
            const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
            
            const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
            const sunday = new Date(date);
            sunday.setDate(date.getDate() - dayOfWeek); // Go back to Sunday
            
            // Format as YYYY-MM-DD
            const year = sunday.getFullYear();
            const month = String(sunday.getMonth() + 1).padStart(2, '0');
            const day = String(sunday.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
          };
          
          console.log('\n--- Importing ALL Blocks with Valid Dates ---');
          console.log('No week filtering applied - all blocks will be imported');
          
          // Use all blocks (no week filtering)
          const weekBlocks = allBlocks;
          console.log('Total blocks to import:', weekBlocks.length);
          if (weekBlocks.length > 0) {
            console.log('First block:', weekBlocks[0]);
            console.log('Last block:', weekBlocks[weekBlocks.length - 1]);
          }
          
          // Store in database
          console.log('\n--- Storing in Database ---');
          const imported = [];
          let count = 0;
          const userId = ctx.user?.id || 0;
          
          for (const block of weekBlocks) {
            count++;
            if (count <= 3 || count === weekBlocks.length) {
              console.log(`Inserting block ${count}/${weekBlocks.length}:`, block.blockId, block.startDate, block.startTime, block.contractType, 'Driver:', block.driverName);
            }
            
            // Calculate weekStartDate based on block's start date
            const weekStartDate = getSundayOfWeek(block.startDate);
            
            // Auto-assign driver if name AND type match
            let assignedDriverId: number | null = null;
            if (block.driverName) {
              const matchedDriver = await db.findDriverByName(userId, block.driverName);
              if (matchedDriver) {
                // Check if driver type matches block contract type
                const driverType = matchedDriver.driverType;
                const blockType = block.contractType;
                
                const typeMatches = 
                  driverType === 'Both' || // "Both" drivers can do any block
                  driverType === blockType || // Exact match (Solo1→Solo1, Solo2→Solo2)
                  (driverType === 'Solo2' && blockType === 'Solo1'); // Solo2 drivers can do Solo1 blocks
                
                if (typeMatches) {
                  assignedDriverId = matchedDriver.id;
                  if (count <= 3 || count === weekBlocks.length) {
                    console.log(`  → Matched driver: ${matchedDriver.name} (ID: ${matchedDriver.id}, Type: ${driverType})`);
                  }
                } else if (count <= 3 || count === weekBlocks.length) {
                  console.log(`  → Driver ${matchedDriver.name} type mismatch: ${driverType} cannot do ${blockType}`);
                }
              } else if (count <= 3 || count === weekBlocks.length) {
                console.log(`  → No driver match found for: ${block.driverName}`);
              }
            }
            
            const result = await db.createImportedBlock({
              userId,
              blockId: block.blockId,
              driverName: block.driverName,
              startDate: block.startDate, // Keep as string (YYYY-MM-DD)
              startTime: block.startTime,
              endDate: block.endDate || null, // Keep as string or null
              endTime: block.endTime,
              contractType: block.contractType,
              duration: block.duration,
              payRate: block.payRate,
              origin: block.origin,
              destination: block.destination,
              equipmentType: block.equipmentType,
              truckFilter: block.truckFilter,
              assignedDriverId,
              weekStartDate, // Already calculated above
            });
            imported.push(result);
          }
          
          console.log('\n--- Import Complete ---');
          console.log('Successfully imported:', imported.length, 'blocks');
          console.log('========== CSV IMPORT FINISHED ==========\n');
          
          return {
            success: true,
            imported: imported.length,
            blocks: imported,
          };
        } catch (error) {
          console.error('\n========== CSV IMPORT ERROR ==========');
          console.error('Error details:', error);
          console.error('Stack trace:', error instanceof Error ? error.stack : 'No stack trace');
          throw new Error(`CSV import failed: ${error instanceof Error ? error.message : String(error)}`);
        }
      }),
    
    getBlocksByWeek: publicProcedure
      .input(z.object({
        weekStartDate: z.string(), // YYYY-MM-DD format
      }))
      .query(async ({ ctx, input }) => {
        const userId = ctx.user?.id || 0;
        const blocks = await db.getImportedBlocksByWeek(userId, input.weekStartDate);
        return blocks;
      }),
    
    drivers: publicProcedure
      .input(z.object({
        data: z.array(z.object({
          name: z.string(),
          email: z.string().optional(),
          phone: z.string().optional(),
          licenseNumber: z.string().optional(),
          driverType: z.enum(["Solo1", "Solo2", "PartTime"]).optional(),
          preferredStartTime: z.string().optional(),
          status: z.enum(["active", "inactive", "on_leave", "onboarding"]).optional(),
        }))
      }))
      .mutation(async ({ ctx, input }) => {
        return await importService.importDriversFromCSV(ctx.user?.id || 0, input.data);
      }),
    
    tractors: publicProcedure
      .input(z.object({
        data: z.array(z.object({
          tractorNumber: z.string(),
          make: z.string().optional(),
          model: z.string().optional(),
          year: z.number().optional(),
          fuel: z.string().optional(),
          vin: z.string().optional(),
          licensePlate: z.string().optional(),
          status: z.enum(["active", "maintenance", "out_of_service"]).optional(),
        }))
      }))
      .mutation(async ({ ctx, input }) => {
        return await importService.importTractorsFromCSV(ctx.user?.id || 0, input.data);
      }),
  }),

  // HOS Validation
  hos: router({
    validate: publicProcedure
      .input(z.object({
        shifts: z.array(z.object({
          driverId: z.number(),
          startTime: z.date(),
          endTime: z.date(),
          blockType: z.enum(["Solo1", "Solo2"])
        })),
        drivers: z.array(z.object({
          id: z.number(),
          name: z.string(),
          maxConsecutiveDays: z.number().optional()
        }))
      }))
      .query(({ input }) => {
        return hosValidator.validateSchedule(input.shifts, input.drivers);
      }),

    autoAssign: publicProcedure
      .input(z.object({
        driverId: z.number(),
        driverType: z.enum(["Solo1", "Solo2", "PartTime"]),
        startDate: z.date(),
        startTime: z.string(),
        existingShifts: z.array(z.object({
          driverId: z.number(),
          startTime: z.date(),
          endTime: z.date(),
          blockType: z.enum(["Solo1", "Solo2"])
        }))
      }))
      .mutation(({ input }) => {
        return hosValidator.autoAssignBlocks(
          input.driverId,
          input.driverType,
          input.startDate,
          input.startTime,
          input.existingShifts
        );
      }),

    suggestSwap: publicProcedure
      .input(z.object({
        violatingShift: z.object({
          driverId: z.number(),
          startTime: z.date(),
          endTime: z.date(),
          blockType: z.enum(["Solo1", "Solo2"])
        }),
        allShifts: z.array(z.object({
          driverId: z.number(),
          startTime: z.date(),
          endTime: z.date(),
          blockType: z.enum(["Solo1", "Solo2"])
        })),
        availableDrivers: z.array(z.object({
          id: z.number(),
          name: z.string(),
          driverType: z.string()
        }))
      }))
      .query(({ input }) => {
        return hosValidator.suggestDriverSwap(
          input.violatingShift,
          input.allShifts,
          input.availableDrivers
        );
      }),
  }),

  // Notifications
  notifications: router({
    send: publicProcedure
      .input(z.object({
        driverId: z.number(),
        type: z.enum(["shift_assigned", "shift_changed", "shift_reminder"]),
        shiftDetails: z.object({
          startTime: z.date(),
          endTime: z.date(),
          location: z.string(),
          tractorNumber: z.string().optional()
        })
      }))
      .mutation(async ({ input }) => {
        // Get driver details
        const driver = await db.getDriverById(input.driverId);
        if (!driver) throw new Error("Driver not found");

        if (input.type === "shift_assigned") {
          await notifications.notifyShiftAssigned(
            driver.id,
            driver.name,
            driver.phone || "",
            input.shiftDetails
          );
        }
        
        return { success: true };
      }),

    publishSchedule: publicProcedure
      .input(z.object({
        driverIds: z.array(z.number()),
        weekStartDate: z.date()
      }))
      .mutation(async ({ input }) => {
        const drivers = await Promise.all(
          input.driverIds.map(id => db.getDriverById(id))
        );
        
        const validDrivers = drivers.filter(d => d !== null).map(d => ({
          id: d!.id,
          name: d!.name,
          phone: d!.phone || ""
        }));

        await notifications.notifySchedulePublished(validDrivers, input.weekStartDate);
        return { success: true, notified: validDrivers.length };
      }),

    preferences: publicProcedure
      .query(async ({ ctx }) => {
        return await notifications.getNotificationPreferences(ctx.user?.id || 0);
      }),

    updatePreferences: publicProcedure
      .input(z.object({
        smsEnabled: z.boolean().optional(),
        emailEnabled: z.boolean().optional(),
        shiftReminders: z.boolean().optional(),
        scheduleChanges: z.boolean().optional()
      }))
      .mutation(async ({ ctx, input }) => {
        await notifications.updateNotificationPreferences(ctx.user?.id || 0, input);
        return { success: true };
      }),
  }),

  // Auto Scheduler
  autoScheduler: router({

    buildWeekly: publicProcedure
      .input(z.object({
        weekStartDate: z.date()
      }))
      .mutation(async ({ ctx, input }) => {
        // Get all active drivers for this user
        const drivers = await db.getDriversByUserId(ctx.user?.id || 0);
        
        const driverList = drivers.map(d => ({
          id: d.id,
          name: d.name,
          driverType: (d.driverType || "Solo1") as "Solo1" | "Solo2" | "PartTime",
          preferredStartTime: d.preferredStartTime || "08:30",
          maxConsecutiveDays: d.maxConsecutiveDays || 5,
          status: d.status
        }));

        const result = autoScheduler.autoBuildWeeklySchedule(driverList, input.weekStartDate);
        return result;
      }),

    suggestTime: publicProcedure
      .input(z.object({
        driverId: z.number(),
        targetDay: z.string(),
        existingSchedule: z.array(z.object({
          day: z.string(),
          timeSlot: z.string(),
          driverId: z.number(),
          driverName: z.string(),
          blockType: z.enum(["Solo1", "Solo2"])
        }))
      }))
      .query(async ({ ctx, input }) => {
        const driver = await db.getDriverById(input.driverId);
        if (!driver) throw new Error("Driver not found");

        const driverData = {
          id: driver.id,
          name: driver.name,
          driverType: (driver.driverType || "Solo1") as "Solo1" | "Solo2" | "PartTime",
          preferredStartTime: driver.preferredStartTime || "08:30",
          maxConsecutiveDays: driver.maxConsecutiveDays || 5,
          status: driver.status
        };

        return autoScheduler.suggestStartTime(driverData, input.existingSchedule, input.targetDay);
      }),
  }),

  // AI Scheduling Assistant
  ai: router({
    processCommand: publicProcedure
      .input(z.object({
        command: z.string(),
        conversationHistory: z.array(z.object({
          role: z.string(),
          content: z.string(),
        })).optional(),
        context: z.object({
          weekStart: z.string(),
          driverCount: z.number(),
          driverNames: z.array(z.string()),
          scheduleSlotCount: z.number(),
          startTimeCount: z.number(),
          userId: z.number().optional(),
          drivers: z.array(z.any()).optional(),
          tractors: z.array(z.any()).optional(),
          schedules: z.array(z.any()).optional(),
          scheduleData: z.record(z.string(), z.any()).optional(),
          startTimes: z.array(z.any()).optional(),
          totalBlocks: z.object({ Solo1: z.number(), Solo2: z.number() }).optional(),
        }),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          // Add userId to context for database operations
          const enrichedContext = {
            ...input.context,
            userId: ctx.user?.id || 0,
          };
          
          const response = await aiScheduler.processSchedulingCommand(
            input.command,
            enrichedContext,
            input.conversationHistory || []
          );
          return { response, success: true };
        } catch (error) {
          console.error("AI command processing error:", error);
          return { 
            response: "I apologize, but I encountered an error processing your request. Please try rephrasing your command or contact support if the issue persists.",
            success: false,
            error: error instanceof Error ? error.message : "Unknown error"
          };
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
