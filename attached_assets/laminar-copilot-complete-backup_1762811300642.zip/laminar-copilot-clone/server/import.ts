import * as db from "./db";

export interface DriverCSVRow {
  name: string;
  email?: string;
  phone?: string;
  licenseNumber?: string;
  driverType?: "Solo1" | "Solo2" | "PartTime";
  preferredStartTime?: string;
  status?: "active" | "inactive" | "on_leave" | "onboarding";
}

export interface TractorCSVRow {
  tractorNumber: string;
  make?: string;
  model?: string;
  year?: number;
  vin?: string;
  licensePlate?: string;
  status?: "active" | "maintenance" | "out_of_service";
}

/**
 * Parse CSV content and import drivers
 */
export async function importDriversFromCSV(
  userId: number,
  csvData: DriverCSVRow[]
): Promise<{ success: number; failed: number; errors: string[] }> {
  let success = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const row of csvData) {
    try {
      if (!row.name || row.name.trim() === "") {
        failed++;
        errors.push(`Skipped row: missing driver name`);
        continue;
      }

      await db.createDriver({
        userId,
        name: row.name.trim(),
        email: row.email?.trim() || null,
        phone: row.phone?.trim() || null,
        licenseNumber: row.licenseNumber?.trim() || null,
        driverType: row.driverType || null,
        preferredStartTime: row.preferredStartTime?.trim() || null,
        status: row.status || "active",
      });

      success++;
    } catch (error) {
      failed++;
      errors.push(`Failed to import ${row.name}: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }

  return { success, failed, errors };
}

/**
 * Parse CSV content and import tractors
 */
export async function importTractorsFromCSV(
  userId: number,
  csvData: TractorCSVRow[]
): Promise<{ success: number; failed: number; errors: string[] }> {
  let success = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const row of csvData) {
    try {
      if (!row.tractorNumber || row.tractorNumber.trim() === "") {
        failed++;
        errors.push(`Skipped row: missing tractor number`);
        continue;
      }

      await db.createTractor({
        userId,
        tractorNumber: row.tractorNumber.trim(),
        make: row.make?.trim() || null,
        model: row.model?.trim() || null,
        year: row.year || null,
        vin: row.vin?.trim() || null,
        licensePlate: row.licensePlate?.trim() || null,
        status: row.status || "active",
      });

      success++;
    } catch (error) {
      failed++;
      errors.push(`Failed to import ${row.tractorNumber}: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }

  return { success, failed, errors };
}

/**
 * Validate CSV structure for drivers
 */
export function validateDriverCSV(data: any[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!Array.isArray(data) || data.length === 0) {
    errors.push("CSV file is empty or invalid");
    return { valid: false, errors };
  }

  const requiredFields = ["name"];
  const optionalFields = ["email", "phone", "licenseNumber", "driverType", "preferredStartTime", "status"];
  const validFields = [...requiredFields, ...optionalFields];

  const firstRow = data[0];
  const headers = Object.keys(firstRow);

  // Check for required fields
  for (const field of requiredFields) {
    if (!headers.includes(field)) {
      errors.push(`Missing required column: ${field}`);
    }
  }

  // Check for invalid fields
  for (const header of headers) {
    if (!validFields.includes(header)) {
      errors.push(`Unknown column: ${header} (will be ignored)`);
    }
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Validate CSV structure for tractors
 */
export function validateTractorCSV(data: any[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!Array.isArray(data) || data.length === 0) {
    errors.push("CSV file is empty or invalid");
    return { valid: false, errors };
  }

  const requiredFields = ["tractorNumber"];
  const optionalFields = ["make", "model", "year", "vin", "licensePlate", "status"];
  const validFields = [...requiredFields, ...optionalFields];

  const firstRow = data[0];
  const headers = Object.keys(firstRow);

  // Check for required fields
  for (const field of requiredFields) {
    if (!headers.includes(field)) {
      errors.push(`Missing required column: ${field}`);
    }
  }

  // Check for invalid fields
  for (const header of headers) {
    if (!validFields.includes(header)) {
      errors.push(`Unknown column: ${header} (will be ignored)`);
    }
  }

  return { valid: errors.length === 0, errors };
}

