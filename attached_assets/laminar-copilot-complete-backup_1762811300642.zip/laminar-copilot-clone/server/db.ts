import { eq, and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  drivers,
  InsertDriver,
  Driver,
  tractors,
  InsertTractor,
  Tractor,
  driverPreferences,
  InsertDriverPreference,
  DriverPreference,
  driverAvailability,
  InsertDriverAvailability,
  DriverAvailability,
  tractorAvailability,
  InsertTractorAvailability,
  TractorAvailability,
  contracts,
  InsertContract,
  Contract,
  routes,
  InsertRoute,
  Route,
  schedules,
  InsertSchedule,
  Schedule,
  notifications,
  InsertNotification,
  Notification,
  driverAvailabilitySlots,
  InsertDriverAvailabilitySlot,
  DriverAvailabilitySlot,
  importedBlocks,
  InsertImportedBlock,
  ImportedBlock
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "companyName", "scacCode", "domicile", "homeYardCode"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Driver Management
export async function getDriversByUserId(userId: number): Promise<Driver[]> {
  const db = await getDb();
  if (!db) return [];
  
  // For testing: return all drivers regardless of userId
  return await db.select().from(drivers);
  // Production: return await db.select().from(drivers).where(eq(drivers.userId, userId));
}

export async function getDriverById(id: number): Promise<Driver | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(drivers).where(eq(drivers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDriver(driver: InsertDriver): Promise<Driver> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(drivers).values(driver);
  const insertedId = Number(result[0].insertId);
  
  const newDriver = await getDriverById(insertedId);
  if (!newDriver) throw new Error("Failed to retrieve created driver");
  
  return newDriver;
}

export async function updateDriver(id: number, driver: Partial<InsertDriver>): Promise<Driver | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  await db.update(drivers).set(driver).where(eq(drivers.id, id));
  return await getDriverById(id);
}

export async function deleteDriver(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(drivers).where(eq(drivers.id, id));
}

export async function findDriverByName(userId: number, name: string): Promise<Driver | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  // Get all drivers for this user
  const allDrivers = await getDriversByUserId(userId);
  
  // Case-insensitive name matching
  const normalizedName = name.toLowerCase().trim();
  const found = allDrivers.find(d => d.name.toLowerCase().trim() === normalizedName);
  
  return found;
}

// Driver Availability Slots
export async function getDriverAvailabilitySlots(driverId: number): Promise<DriverAvailabilitySlot[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(driverAvailabilitySlots).where(eq(driverAvailabilitySlots.driverId, driverId));
}

export async function createDriverAvailabilitySlots(driverId: number, slots: Array<{ dayOfWeek: string; startTime: string }>): Promise<void> {
  const db = await getDb();
  if (!db) return;
  
  const values = slots.map(slot => ({
    driverId,
    dayOfWeek: slot.dayOfWeek,
    startTime: slot.startTime,
  }));
  
  await db.insert(driverAvailabilitySlots).values(values);
}

export async function deleteDriverAvailabilitySlots(driverId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(driverAvailabilitySlots).where(eq(driverAvailabilitySlots.driverId, driverId));
}

// Tractor Management
export async function getTractorsByUserId(userId: number): Promise<Tractor[]> {
  const db = await getDb();
  if (!db) return [];
  
  // For testing: return all fleet tractors
  return await db.select().from(tractors).where(eq(tractors.entryType, 'fleet'));
  // Production: return await db.select().from(tractors).where(and(eq(tractors.userId, userId), eq(tractors.entryType, 'fleet')));
}

export async function getStartTimesByUserId(userId: number): Promise<Tractor[]> {
  const db = await getDb();
  if (!db) return [];
  
  // For testing: return all start time entries
  return await db.select().from(tractors).where(eq(tractors.entryType, 'start_time'));
  // Production: return await db.select().from(tractors).where(and(eq(tractors.userId, userId), eq(tractors.entryType, 'start_time')));
}

export async function getTractorById(id: number): Promise<Tractor | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(tractors).where(eq(tractors.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getTractorByNumber(userId: number, tractorNumber: string): Promise<Tractor | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(tractors)
    .where(and(eq(tractors.userId, userId), eq(tractors.tractorNumber, tractorNumber)))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createTractor(tractor: InsertTractor): Promise<Tractor> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(tractors).values(tractor);
  const insertedId = Number(result[0].insertId);
  
  const newTractor = await getTractorById(insertedId);
  if (!newTractor) throw new Error("Failed to retrieve created tractor");
  
  return newTractor;
}

export async function updateTractor(id: number, tractor: Partial<InsertTractor>): Promise<Tractor | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  await db.update(tractors).set(tractor).where(eq(tractors.id, id));
  return await getTractorById(id);
}

export async function deleteTractor(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(tractors).where(eq(tractors.id, id));
}

// Schedules
export async function getSchedulesByUserId(userId: number): Promise<Schedule[]> {
  const db = await getDb();
  if (!db) return [];
  
  // For testing: return all schedules
  return await db.select().from(schedules);
  // Production: return await db.select().from(schedules).where(eq(schedules.userId, userId));
}

export async function createSchedule(schedule: InsertSchedule): Promise<Schedule> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(schedules).values(schedule);
  const insertedId = Number(result[0].insertId);
  
  const newSchedule = await db.select().from(schedules).where(eq(schedules.id, insertedId)).limit(1);
  if (!newSchedule[0]) throw new Error("Failed to retrieve schedule");
  
  return newSchedule[0];
}

export async function updateSchedule(id: number, schedule: Partial<InsertSchedule>): Promise<Schedule | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  await db.update(schedules).set(schedule).where(eq(schedules.id, id));
  
  const result = await db.select().from(schedules).where(eq(schedules.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// HOS (Hours of Service) Tracking
export interface DriverHOSStatus {
  driverId: number;
  driverName: string;
  consecutiveSolo1Days: number;
  consecutiveSolo2Blocks: number;
  lastWorkDate: string | null;
  needsRestart: boolean;
  remainingSolo1Capacity: number; // 0-6
  remainingSolo2Capacity: number; // 0-3
  lastRestartDate: string | null;
}

export async function getDriverHOSStatus(userId: number, weekStart: Date): Promise<DriverHOSStatus[]> {
  const db = await getDb();
  if (!db) return [];
  
  // Get all active drivers
  const allDrivers = await getDriversByUserId(userId);
  const activeDrivers = allDrivers.filter(d => d.status === 'active');
  
  // Calculate date range for last week (7 days before weekStart)
  const lastWeekStart = new Date(weekStart);
  lastWeekStart.setDate(weekStart.getDate() - 7);
  const lastWeekEnd = new Date(weekStart);
  lastWeekEnd.setDate(weekStart.getDate() - 1);
  
  const hosStatusList: DriverHOSStatus[] = [];
  
  for (const driver of activeDrivers) {
    // Get schedules for this driver in the last week
    const driverSchedules = await db
      .select({
        scheduleId: schedules.id,
        scheduledDate: schedules.scheduledDate,
        routeId: schedules.routeId,
      })
      .from(schedules)
      .where(
        and(
          eq(schedules.driverId, driver.id),
          gte(schedules.scheduledDate, lastWeekStart),
          lte(schedules.scheduledDate, lastWeekEnd)
        )
      )
      .orderBy(schedules.scheduledDate);
    
    // Get contract types for each schedule
    let consecutiveSolo1 = 0;
    let consecutiveSolo2 = 0;
    let lastWorkDate: string | null = null;
    
    for (const sched of driverSchedules) {
      // Get route and contract info
      const route = await db.select().from(routes).where(eq(routes.id, sched.routeId)).limit(1);
      if (route.length === 0 || !route[0].contractId) continue;
      
      const contract = await db.select().from(contracts).where(eq(contracts.id, route[0].contractId)).limit(1);
      if (contract.length === 0) continue;
      
      const contractType = contract[0].contractType;
      lastWorkDate = sched.scheduledDate instanceof Date 
        ? sched.scheduledDate.toISOString().split('T')[0] 
        : sched.scheduledDate;
      
      if (contractType === 'solo1') {
        consecutiveSolo1++;
        consecutiveSolo2 = 0; // Reset Solo2 counter
      } else if (contractType === 'solo2') {
        consecutiveSolo2++;
        consecutiveSolo1 = 0; // Reset Solo1 counter
      }
    }
    
    // Calculate remaining capacity
    const remainingSolo1 = Math.max(0, 6 - consecutiveSolo1);
    const remainingSolo2 = Math.max(0, 3 - consecutiveSolo2);
    const needsRestart = (consecutiveSolo1 >= 6) || (consecutiveSolo2 >= 3);
    
    hosStatusList.push({
      driverId: driver.id,
      driverName: driver.name,
      consecutiveSolo1Days: consecutiveSolo1,
      consecutiveSolo2Blocks: consecutiveSolo2,
      lastWorkDate,
      needsRestart,
      remainingSolo1Capacity: remainingSolo1,
      remainingSolo2Capacity: remainingSolo2,
      lastRestartDate: needsRestart ? null : lastWorkDate,
    });
  }
  
  return hosStatusList;
}



// Check driver compliance (FMCSA HOS violations)
export async function checkDriverCompliance(driverId: number): Promise<{
  isCompliant: boolean;
  violations: string[];
  consecutiveDays: number;
  lastWorkDate: string | null;
  totalHoursIn8Days: number;
  hoursUntil70Limit: number;
}> {
  const db = await getDb();
  if (!db) return { isCompliant: true, violations: [], consecutiveDays: 0, lastWorkDate: null, totalHoursIn8Days: 0, hoursUntil70Limit: 70 };
  
  // Get driver's schedules for the last 8 days (rolling 8-day period)
  const eightDaysAgo = new Date();
  eightDaysAgo.setDate(eightDaysAgo.getDate() - 8);
  
  const recentSchedules = await db
    .select()
    .from(schedules)
    .where(
      and(
        eq(schedules.driverId, driverId),
        gte(schedules.scheduledDate, eightDaysAgo)
      )
    )
    .orderBy(schedules.scheduledDate);
  
  const violations: string[] = [];
  let consecutiveDays = 0;
  let lastWorkDate: string | null = null;
  
  // Calculate total on-duty hours in rolling 8-day period
  // Assuming each schedule is approximately 10-14 hours on-duty (conservative estimate)
  const estimatedHoursPerShift = 12; // Average on-duty hours per shift
  const totalHoursIn8Days = recentSchedules.length * estimatedHoursPerShift;
  const hoursUntil70Limit = Math.max(0, 70 - totalHoursIn8Days);
  
  if (recentSchedules.length > 0) {
    // Count consecutive days worked
    let currentStreak = 1;
    for (let i = 1; i < recentSchedules.length; i++) {
      const prevDate = new Date(recentSchedules[i - 1].scheduledDate);
      const currDate = new Date(recentSchedules[i].scheduledDate);
      const daysDiff = Math.floor((currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysDiff === 1) {
        currentStreak++;
      } else {
        currentStreak = 1;
      }
    }
    consecutiveDays = currentStreak;
    
    const lastSchedule = recentSchedules[recentSchedules.length - 1];
    lastWorkDate = lastSchedule.scheduledDate instanceof Date
      ? lastSchedule.scheduledDate.toISOString().split('T')[0]
      : lastSchedule.scheduledDate;
    
    // Check 70-hour/8-day rule (FMCSA regulation)
    if (totalHoursIn8Days > 70) {
      violations.push(`Exceeded 70-hour limit: ${totalHoursIn8Days} hours in rolling 8-day period`);
    }
    
    // Warn if approaching 70-hour limit
    if (totalHoursIn8Days > 60 && totalHoursIn8Days <= 70) {
      violations.push(`⚠️ Approaching 70-hour limit: ${totalHoursIn8Days}/70 hours used (${hoursUntil70Limit} hours remaining)`);
    }
    
    // Check 10-hour off-duty between shifts
    for (let i = 1; i < recentSchedules.length; i++) {
      const prevSchedule = recentSchedules[i - 1];
      const currSchedule = recentSchedules[i];
      
      const prevDate = new Date(prevSchedule.scheduledDate);
      const currDate = new Date(currSchedule.scheduledDate);
      
      const hoursBetween = (currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60);
      
      if (hoursBetween < 10) {
        violations.push(`Less than 10 hours off-duty between shifts on ${currDate.toLocaleDateString()}`);
      }
    }
  }
  
  return {
    isCompliant: violations.length === 0,
    violations,
    consecutiveDays,
    lastWorkDate,
    totalHoursIn8Days,
    hoursUntil70Limit
  };
}

// Delete schedule
export async function deleteSchedule(scheduleId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  
  try {
    await db.delete(schedules).where(eq(schedules.id, scheduleId));
    return true;
  } catch (error) {
    console.error('Error deleting schedule:', error);
    return false;
  }
}

// Delete all schedules for a user
export async function deleteSchedulesByUserId(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  
  try {
    // For testing: delete all schedules
    await db.delete(schedules);
    // Production: await db.delete(schedules).where(eq(schedules.userId, userId));
    return true;
  } catch (error) {
    console.error('Error deleting schedules:', error);
    return false;
  }
}

// Get routes by user ID
export async function getRoutesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(routes).where(eq(routes.userId, userId));
}



// ==================== Imported Blocks ====================

// Create imported block
export async function createImportedBlock(data: InsertImportedBlock): Promise<ImportedBlock> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  const [result] = await db.insert(importedBlocks).values(data);
  const insertedId = Number(result.insertId);
  const block = await getImportedBlockById(insertedId);
  if (!block) {
    throw new Error(`Failed to retrieve imported block with ID ${insertedId}`);
  }
  return block;
}

// Get imported block by ID
export async function getImportedBlockById(id: number): Promise<ImportedBlock | null> {
  const db = await getDb();
  if (!db) return null;
  
  const [block] = await db.select().from(importedBlocks).where(eq(importedBlocks.id, id));
  return block || null;
}

// Get imported blocks by user ID and week
export async function getImportedBlocksByWeek(userId: number, weekStartDate: string): Promise<ImportedBlock[]> {
  const db = await getDb();
  if (!db) return [];
  
  // weekStartDate is already in YYYY-MM-DD format
  const weekStartStr = weekStartDate;
  
  return db.select().from(importedBlocks)
    .where(and(
      eq(importedBlocks.userId, userId),
      eq(importedBlocks.weekStartDate, weekStartStr)
    ))
    .orderBy(importedBlocks.startDate, importedBlocks.startTime);
}

// Update imported block (assign driver)
export async function updateImportedBlock(id: number, data: Partial<InsertImportedBlock>): Promise<ImportedBlock | null> {
  const db = await getDb();
  if (!db) return null;
  
  await db.update(importedBlocks).set(data).where(eq(importedBlocks.id, id));
  return getImportedBlockById(id);
}

// Delete imported blocks for a specific week
export async function deleteImportedBlocksByWeek(userId: number, weekStartDate: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  
  try {
    await db.delete(importedBlocks).where(and(
      eq(importedBlocks.userId, userId),
      eq(importedBlocks.weekStartDate, weekStartDate)
    ));
    return true;
  } catch (error) {
    console.error('Error deleting imported blocks:', error);
    return false;
  }
}

