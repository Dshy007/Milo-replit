/**
 * Hours of Service (HOS) Validation Service
 * Implements AFP scheduling rules and compliance checks
 */

export interface Shift {
  driverId: number;
  startTime: Date;
  endTime: Date;
  blockType: "Solo1" | "Solo2";
}

export interface HOSViolation {
  type: "insufficient_rest" | "max_consecutive_days" | "no_34hr_reset" | "time_conflict";
  driverId: number;
  driverName: string;
  details: string;
  suggestedFix?: string;
}

export interface ScheduleValidationResult {
  valid: boolean;
  violations: HOSViolation[];
  warnings: string[];
}

/**
 * Validate 10-hour rest period between shifts
 */
export function validateRestPeriod(shift1: Shift, shift2: Shift): boolean {
  const REST_PERIOD_HOURS = 10;
  const timeBetween = (shift2.startTime.getTime() - shift1.endTime.getTime()) / (1000 * 60 * 60);
  return timeBetween >= REST_PERIOD_HOURS;
}

/**
 * Calculate block duration based on type
 */
export function getBlockDuration(blockType: "Solo1" | "Solo2"): number {
  return blockType === "Solo1" ? 14 : 38; // hours
}

/**
 * Get consecutive days worked for a driver
 */
export function getConsecutiveDaysWorked(shifts: Shift[], driverId: number, upToDate: Date): number {
  const driverShifts = shifts
    .filter(s => s.driverId === driverId && s.startTime <= upToDate)
    .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());

  if (driverShifts.length === 0) return 0;

  let consecutiveDays = 1;
  let currentDate = new Date(driverShifts[0].startTime);
  currentDate.setHours(0, 0, 0, 0);

  for (let i = 1; i < driverShifts.length; i++) {
    const shiftDate = new Date(driverShifts[i].startTime);
    shiftDate.setHours(0, 0, 0, 0);

    const daysDiff = Math.floor((shiftDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24));

    if (daysDiff === 1) {
      consecutiveDays++;
      currentDate = shiftDate;
    } else if (daysDiff > 1) {
      // Reset counter if there's a gap
      consecutiveDays = 1;
      currentDate = shiftDate;
    }
  }

  return consecutiveDays;
}

/**
 * Check if driver needs 34-hour reset
 */
export function needs34HourReset(shifts: Shift[], driverId: number, maxConsecutiveDays: number = 5): boolean {
  const consecutiveDays = getConsecutiveDaysWorked(shifts, driverId, new Date());
  return consecutiveDays >= maxConsecutiveDays;
}

/**
 * Validate entire schedule for HOS compliance
 */
export function validateSchedule(
  shifts: Shift[],
  drivers: Array<{ id: number; name: string; maxConsecutiveDays?: number }>
): ScheduleValidationResult {
  const violations: HOSViolation[] = [];
  const warnings: string[] = [];

  // Group shifts by driver
  const shiftsByDriver = new Map<number, Shift[]>();
  shifts.forEach(shift => {
    if (!shiftsByDriver.has(shift.driverId)) {
      shiftsByDriver.set(shift.driverId, []);
    }
    shiftsByDriver.get(shift.driverId)!.push(shift);
  });

  // Validate each driver's schedule
  drivers.forEach(driver => {
    const driverShifts = shiftsByDriver.get(driver.id) || [];
    if (driverShifts.length === 0) return;

    // Sort shifts by start time
    const sortedShifts = [...driverShifts].sort((a, b) => 
      a.startTime.getTime() - b.startTime.getTime()
    );

    // Check rest periods between consecutive shifts
    for (let i = 0; i < sortedShifts.length - 1; i++) {
      const currentShift = sortedShifts[i];
      const nextShift = sortedShifts[i + 1];

      if (!validateRestPeriod(currentShift, nextShift)) {
        const hoursRest = (nextShift.startTime.getTime() - currentShift.endTime.getTime()) / (1000 * 60 * 60);
        violations.push({
          type: "insufficient_rest",
          driverId: driver.id,
          driverName: driver.name,
          details: `Only ${hoursRest.toFixed(1)} hours between shifts (requires 10 hours)`,
          suggestedFix: "Consider swapping this shift with a fully rested driver"
        });
      }
    }

    // Check consecutive days worked
    const maxDays = driver.maxConsecutiveDays || 5;
    const consecutiveDays = getConsecutiveDaysWorked(sortedShifts, driver.id, new Date());
    
    if (consecutiveDays > maxDays) {
      violations.push({
        type: "max_consecutive_days",
        driverId: driver.id,
        driverName: driver.name,
        details: `Driver has worked ${consecutiveDays} consecutive days (max: ${maxDays})`,
        suggestedFix: "Schedule a 34-hour reset period"
      });
    } else if (consecutiveDays === maxDays) {
      warnings.push(`${driver.name} is at maximum consecutive days (${maxDays}). Schedule reset after this shift.`);
    }

    // Check for overlapping shifts (time conflicts)
    for (let i = 0; i < sortedShifts.length - 1; i++) {
      const currentShift = sortedShifts[i];
      const nextShift = sortedShifts[i + 1];

      if (nextShift.startTime < currentShift.endTime) {
        violations.push({
          type: "time_conflict",
          driverId: driver.id,
          driverName: driver.name,
          details: "Overlapping shifts detected",
          suggestedFix: "Adjust shift times to prevent overlap"
        });
      }
    }
  });

  return {
    valid: violations.length === 0,
    violations,
    warnings
  };
}

/**
 * Auto-assign blocks based on driver type
 * Returns array of shifts to create
 */
export function autoAssignBlocks(
  driverId: number,
  driverType: "Solo1" | "Solo2" | "PartTime",
  startDate: Date,
  startTime: string, // e.g., "00:30"
  existingShifts: Shift[]
): Shift[] {
  const shifts: Shift[] = [];
  
  if (driverType === "Solo1") {
    // Solo1: 4 blocks of 14 hours each
    for (let i = 0; i < 4; i++) {
      const shiftStart = new Date(startDate);
      shiftStart.setDate(shiftStart.getDate() + i);
      const [hours, minutes] = startTime.split(':').map(Number);
      shiftStart.setHours(hours, minutes, 0, 0);

      const shiftEnd = new Date(shiftStart);
      shiftEnd.setHours(shiftEnd.getHours() + 14);

      shifts.push({
        driverId,
        startTime: shiftStart,
        endTime: shiftEnd,
        blockType: "Solo1"
      });
    }
  } else if (driverType === "Solo2") {
    // Solo2: 2 consecutive blocks of 38 hours each
    for (let i = 0; i < 2; i++) {
      const shiftStart = new Date(startDate);
      shiftStart.setDate(shiftStart.getDate() + (i * 2)); // Every other day
      const [hours, minutes] = startTime.split(':').map(Number);
      shiftStart.setHours(hours, minutes, 0, 0);

      const shiftEnd = new Date(shiftStart);
      shiftEnd.setHours(shiftEnd.getHours() + 38);

      shifts.push({
        driverId,
        startTime: shiftStart,
        endTime: shiftEnd,
        blockType: "Solo2"
      });
    }
  }

  // Validate generated shifts don't conflict with existing
  const allShifts = [...existingShifts, ...shifts];
  const validation = validateSchedule(allShifts, [{ id: driverId, name: "Driver" }]);
  
  if (!validation.valid) {
    console.warn("Auto-assigned blocks have HOS violations:", validation.violations);
  }

  return shifts;
}

/**
 * Suggest driver swap to fix HOS violation
 */
export function suggestDriverSwap(
  violatingShift: Shift,
  allShifts: Shift[],
  availableDrivers: Array<{ id: number; name: string; driverType: string }>
): Array<{ driverId: number; driverName: string; reason: string }> {
  const suggestions: Array<{ driverId: number; driverName: string; reason: string }> = [];

  availableDrivers.forEach(driver => {
    const driverShifts = allShifts.filter(s => s.driverId === driver.id);
    
    // Check if driver has enough rest before this shift
    let hasEnoughRest = true;
    for (const shift of driverShifts) {
      if (shift.endTime > violatingShift.startTime) {
        const restHours = (violatingShift.startTime.getTime() - shift.endTime.getTime()) / (1000 * 60 * 60);
        if (restHours < 10) {
          hasEnoughRest = false;
          break;
        }
      }
    }

    if (hasEnoughRest) {
      const consecutiveDays = getConsecutiveDaysWorked(driverShifts, driver.id, violatingShift.startTime);
      if (consecutiveDays < 5) {
        suggestions.push({
          driverId: driver.id,
          driverName: driver.name,
          reason: `Fully rested with ${5 - consecutiveDays} days remaining in work week`
        });
      }
    }
  });

  return suggestions;
}

