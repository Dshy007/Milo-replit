import * as db from "./db";

export interface Notification {
  id: number;
  userId: number;
  type: "shift_assigned" | "shift_changed" | "shift_reminder" | "hos_violation" | "schedule_published";
  title: string;
  message: string;
  read: boolean;
  createdAt: Date;
  metadata?: Record<string, any>;
}

export interface SMSNotification {
  to: string; // phone number
  message: string;
  type: "shift_reminder" | "shift_change" | "urgent";
}

/**
 * Create in-app notification
 */
export async function createNotification(
  userId: number,
  type: Notification["type"],
  title: string,
  message: string,
  metadata?: Record<string, any>
): Promise<void> {
  // Store notification in database
  // In production, this would also trigger real-time push via WebSocket/SSE
  console.log(`[Notification] Created for user ${userId}: ${title}`);
  
  // TODO: Implement actual database insert
  // await db.createNotification({ userId, type, title, message, metadata });
}

/**
 * Send SMS notification to driver
 * Note: This is a placeholder. In production, integrate with Twilio, AWS SNS, or similar service
 */
export async function sendSMS(notification: SMSNotification): Promise<boolean> {
  console.log(`[SMS] Sending to ${notification.to}: ${notification.message}`);
  
  // TODO: Integrate with SMS provider
  // Example with Twilio:
  // const client = twilio(accountSid, authToken);
  // await client.messages.create({
  //   body: notification.message,
  //   to: notification.to,
  //   from: process.env.TWILIO_PHONE_NUMBER
  // });
  
  return true;
}

/**
 * Send shift reminder notification (24 hours before shift)
 */
export async function sendShiftReminder(
  driverId: number,
  driverName: string,
  driverPhone: string,
  shiftStartTime: Date,
  shiftLocation: string
): Promise<void> {
  const formattedTime = shiftStartTime.toLocaleString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  // In-app notification
  await createNotification(
    driverId,
    "shift_reminder",
    "Shift Reminder",
    `Your shift starts tomorrow at ${formattedTime}`,
    { shiftStartTime, shiftLocation }
  );

  // SMS notification
  if (driverPhone) {
    await sendSMS({
      to: driverPhone,
      message: `Hi ${driverName}, reminder: Your shift starts tomorrow at ${formattedTime}. Location: ${shiftLocation}. -Milo`,
      type: "shift_reminder"
    });
  }
}

/**
 * Notify driver of shift assignment
 */
export async function notifyShiftAssigned(
  driverId: number,
  driverName: string,
  driverPhone: string,
  shiftDetails: {
    startTime: Date;
    endTime: Date;
    location: string;
    tractorNumber?: string;
  }
): Promise<void> {
  const formattedStart = shiftDetails.startTime.toLocaleString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  // In-app notification
  await createNotification(
    driverId,
    "shift_assigned",
    "New Shift Assigned",
    `You've been assigned a shift starting ${formattedStart}`,
    shiftDetails
  );

  // SMS notification
  if (driverPhone) {
    const tractorInfo = shiftDetails.tractorNumber ? ` | Tractor: ${shiftDetails.tractorNumber}` : '';
    await sendSMS({
      to: driverPhone,
      message: `${driverName}, you've been assigned a shift: ${formattedStart}${tractorInfo}. Check Milo for details.`,
      type: "shift_change"
    });
  }
}

/**
 * Notify driver of shift change
 */
export async function notifyShiftChanged(
  driverId: number,
  driverName: string,
  driverPhone: string,
  changeDetails: {
    oldStartTime: Date;
    newStartTime: Date;
    reason?: string;
  }
): Promise<void> {
  const oldTime = changeDetails.oldStartTime.toLocaleString('en-US', {
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  const newTime = changeDetails.newStartTime.toLocaleString('en-US', {
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });

  // In-app notification
  await createNotification(
    driverId,
    "shift_changed",
    "Shift Time Changed",
    `Your shift has been moved from ${oldTime} to ${newTime}`,
    changeDetails
  );

  // SMS notification
  if (driverPhone) {
    await sendSMS({
      to: driverPhone,
      message: `IMPORTANT: ${driverName}, your shift time changed from ${oldTime} to ${newTime}. ${changeDetails.reason || 'Check Milo for details.'}`,
      type: "urgent"
    });
  }
}

/**
 * Notify dispatcher of HOS violation
 */
export async function notifyHOSViolation(
  dispatcherId: number,
  violation: {
    driverId: number;
    driverName: string;
    violationType: string;
    details: string;
    suggestedFix?: string;
  }
): Promise<void> {
  await createNotification(
    dispatcherId,
    "hos_violation",
    `HOS Violation: ${violation.driverName}`,
    `${violation.violationType} - ${violation.details}`,
    violation
  );
}

/**
 * Notify all drivers when schedule is published
 */
export async function notifySchedulePublished(
  drivers: Array<{ id: number; name: string; phone: string }>,
  weekStartDate: Date
): Promise<void> {
  const weekStr = weekStartDate.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric'
  });

  for (const driver of drivers) {
    // In-app notification
    await createNotification(
      driver.id,
      "schedule_published",
      "New Schedule Published",
      `Your schedule for the week of ${weekStr} is now available`,
      { weekStartDate }
    );

    // SMS notification
    if (driver.phone) {
      await sendSMS({
        to: driver.phone,
        message: `${driver.name}, your schedule for week of ${weekStr} is ready. Check Milo to view your shifts.`,
        type: "shift_change"
      });
    }
  }
}

/**
 * Schedule shift reminders for upcoming shifts
 * This should be run by a cron job 24 hours before shifts
 */
export async function scheduleShiftReminders(shifts: Array<{
  driverId: number;
  driverName: string;
  driverPhone: string;
  startTime: Date;
  location: string;
}>): Promise<void> {
  const now = new Date();
  const twentyFourHoursFromNow = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  for (const shift of shifts) {
    const timeDiff = shift.startTime.getTime() - now.getTime();
    const hoursUntilShift = timeDiff / (1000 * 60 * 60);

    // Send reminder if shift is between 23-25 hours away
    if (hoursUntilShift >= 23 && hoursUntilShift <= 25) {
      await sendShiftReminder(
        shift.driverId,
        shift.driverName,
        shift.driverPhone,
        shift.startTime,
        shift.location
      );
    }
  }
}

/**
 * Get notification preferences for a driver
 */
export async function getNotificationPreferences(userId: number): Promise<{
  smsEnabled: boolean;
  emailEnabled: boolean;
  shiftReminders: boolean;
  scheduleChanges: boolean;
}> {
  // TODO: Fetch from database
  return {
    smsEnabled: true,
    emailEnabled: true,
    shiftReminders: true,
    scheduleChanges: true
  };
}

/**
 * Update notification preferences
 */
export async function updateNotificationPreferences(
  userId: number,
  preferences: Partial<{
    smsEnabled: boolean;
    emailEnabled: boolean;
    shiftReminders: boolean;
    scheduleChanges: boolean;
  }>
): Promise<void> {
  // TODO: Update in database
  console.log(`[Notifications] Updated preferences for user ${userId}`, preferences);
}

