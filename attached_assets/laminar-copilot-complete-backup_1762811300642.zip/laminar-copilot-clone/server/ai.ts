import type { Request, Response } from "express";
import * as db from "./db";

const FORGE_API_URL = process.env.BUILT_IN_FORGE_API_URL;
const FORGE_API_KEY = process.env.BUILT_IN_FORGE_API_KEY;

// Define available tools for GPT-4o function calling
const tools = [
  {
    type: "function",
    function: {
      name: "create_tractors",
      description: "Create multiple new tractors in the fleet database. Use this when user provides tractor data to add.",
      parameters: {
        type: "object",
        properties: {
          tractors: {
            type: "array",
            items: {
              type: "object",
              properties: {
                tractorNumber: { type: "string", description: "Tractor number/ID" },
                make: { type: "string", description: "Manufacturer (e.g., Freightliner, International)" },
                model: { type: "string", description: "Model type (e.g., Sleeper, Day Cab)" },
                fuel: { type: "string", description: "Fuel type (e.g., DIESEL)" },
                vin: { type: "string", description: "Vehicle Identification Number" },
                licensePlate: { type: "string", description: "License plate number" },
                contractType: { type: "string", enum: ["Solo1", "Solo2"], description: "Contract type - Solo1 (day cab) or Solo2 (sleeper)" },
                status: { type: "string", enum: ["active", "maintenance", "out_of_service"], description: "Current status" },
              },
              required: ["tractorNumber"],
            },
          },
        },
        required: ["tractors"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_tractors",
      description: "Update existing tractors (e.g., change type to Solo2, update status). Use when user wants to modify tractor properties.",
      parameters: {
        type: "object",
        properties: {
          updates: {
            type: "array",
            items: {
              type: "object",
              properties: {
                tractorNumber: { type: "string", description: "Tractor number to update" },
                contractType: { type: "string", enum: ["Solo1", "Solo2"], description: "New contract type" },
                status: { type: "string", enum: ["active", "maintenance", "out_of_service"], description: "New status" },
                make: { type: "string" },
                model: { type: "string" },
                fuel: { type: "string" },
                vin: { type: "string" },
                licensePlate: { type: "string" },
              },
              required: ["tractorNumber"],
            },
          },
        },
        required: ["updates"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "create_drivers",
      description: "Create multiple new drivers in the roster. Use when user provides driver data to add.",
      parameters: {
        type: "object",
        properties: {
          drivers: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string", description: "Driver full name" },
                email: { type: "string", description: "Email address" },
                phone: { type: "string", description: "Phone number" },
                licenseNumber: { type: "string", description: "CDL license number" },
                driverType: { type: "string", enum: ["Solo1", "Solo2", "Both"], description: "Qualified contract types" },
                status: { type: "string", enum: ["active", "inactive", "on_leave"], description: "Current status" },
              },
              required: ["name"],
            },
          },
        },
        required: ["drivers"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_drivers",
      description: "Update existing drivers (e.g., change type, update status). Use when user wants to modify driver properties.",
      parameters: {
        type: "object",
        properties: {
          updates: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string", description: "Driver name to update (will use fuzzy matching)" },
                driverType: { type: "string", enum: ["Solo1", "Solo2", "Both"], description: "New qualified contract types" },
                status: { type: "string", enum: ["active", "inactive", "on_leave"], description: "New status" },
                email: { type: "string" },
                phone: { type: "string" },
                licenseNumber: { type: "string" },
              },
              required: ["name"],
            },
          },
        },
        required: ["updates"],
      },
    },
  },
];

export async function handleAIScheduleCommand(req: Request, res: Response) {
  try {
    const { command, context } = req.body;

    if (!command) {
      return res.status(400).json({ error: "Command is required" });
    }

    // Build enhanced system prompt with action capabilities
    const systemPrompt = `You are Milo, an intelligent AI assistant for Freedom Transportation's Amazon Freight Partner (AFP) fleet management system.

You are powered by GPT-4o and have full conversational capabilities AND the ability to execute database operations through function calling.

**Current Fleet Status:**
- Week starting: ${context.weekStart}
- Total drivers: ${context.driverCount} (${context.driverNames.slice(0, 10).join(", ")}${context.driverCount > 10 ? `, and ${context.driverCount - 10} more` : ''})
- Total tractors: ${context.tractors?.length || 0} (Solo1: ${context.tractors?.filter((t: any) => t.contractType === 'Solo1').length || 0}, Solo2: ${context.tractors?.filter((t: any) => t.contractType === 'Solo2').length || 0})
- Schedule slots this week: ${context.scheduleSlotCount}
- Unique start times: ${context.startTimeCount}

**Amazon Freight Partner (AFP) Context:**
Freedom Transportation operates as an AFP, managing Amazon Relay loads with specific operational requirements:
- **Contracts**: Solo1 (14-hour) and Solo2 (38-hour) blocks from Amazon Relay
- **Load types**: Amazon freight with strict delivery windows
- **Scheduling**: Weekly schedules built from Amazon Relay CSV exports
- **Compliance**: DOT Hours of Service (HOS) regulations must be followed
- **Optimization**: Balance driver workload (3 Solo1 + 2 Solo2 per driver optimal)

**Driver Types & Rules:**
- **Solo1 drivers**: 14-hour shifts, single day, can work 3-5 blocks/week optimally
- **Solo2 drivers**: 38-hour shifts, span 2 consecutive days, 2-3 blocks/week optimal
- **Both drivers**: Qualified for either Solo1 or Solo2 assignments
- **HOS compliance**: 10-hour rest between shifts, 70-hour weekly limit
- **Availability**: Active (can be scheduled), Inactive (not available), On Leave

**Tractor Management:**
- **Solo1 tractors**: Day cabs for 14-hour local/regional runs
- **Solo2 tractors**: Sleeper cabs for 38-hour long-haul runs
- **Assignment**: Match tractor type to driver assignment (Solo1 driver → Solo1 tractor)
- **Maintenance**: Track status (active/inactive) for maintenance scheduling

**Your Action Capabilities:**
✅ **CREATE tractors** - Add new tractors to the fleet database
✅ **UPDATE tractors** - Change tractor type (Solo1/Solo2), status, or other properties
✅ **CREATE drivers** - Add new drivers to the roster
✅ **UPDATE drivers** - Change driver type, status, or other properties
✅ **QUERY data** - Answer questions about fleet, capacity, workload
✅ **ANALYZE** - Provide insights on HOS compliance, optimization, conflicts

**Parsing Bulk Data:**
When users paste tab-separated or structured data (like from Excel), parse it intelligently:
- Detect columns: tractor number, make, model, fuel, VIN, license plate, status
- Handle missing fields gracefully
- Infer tractor type from model (Sleeper → Solo2, Day Cab → Solo1)
- Default status to "active" if not specified

**Response Guidelines:**
- **Be conversational**: Talk like a helpful teammate
- **Take action**: When user asks you to create/update, USE THE FUNCTIONS to do it
- **Confirm results**: After executing functions, tell user what you did
- **Show data**: Include relevant numbers and confirmations
- **Use formatting**: Bullet points for lists, **bold** for emphasis
- **Minimal emojis**: Only use ✅ ❌ ⚠️ 🚛 when helpful

**Example Interactions:**
User: "make these solo2 trucks. 921158 Freightliner Sleeper DIESEL 3AKJHPDV0RSUY0190 3446128 active"
You: Parse the data, call create_tractors with contractType="Solo2", confirm "✅ Created 1 Solo2 tractor (#921158)"

User: "change tractor 921158 to solo2"
You: Call update_tractors with tractorNumber="921158" and contractType="Solo2", confirm "✅ Updated tractor #921158 to Solo2"

User: "how many solo2 trucks do I have?"
You: Query the context data, respond "You have ${context.tractors?.filter((t: any) => t.contractType === 'Solo2').length || 0} Solo2 tractors."`;

    // Initial API call to GPT-4o with function calling
    let messages: any[] = [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: command,
      },
    ];

    let functionCallResults: any[] = [];
    let maxIterations = 5; // Prevent infinite loops
    let iteration = 0;

    while (iteration < maxIterations) {
      iteration++;

      const response = await fetch(`${FORGE_API_URL}/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${FORGE_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages,
          tools,
          tool_choice: "auto",
          temperature: 0.7,
          max_tokens: 2000,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Forge API error:", errorText);
        throw new Error(`Forge API request failed: ${response.status}`);
      }

      const data = await response.json();
      const choice = data.choices[0];
      const message = choice.message;

      // Add assistant's response to messages
      messages.push(message);

      // Check if GPT-4o wants to call a function
      if (choice.finish_reason === "tool_calls" && message.tool_calls) {
        // Execute each function call
        for (const toolCall of message.tool_calls) {
          const functionName = toolCall.function.name;
          const functionArgs = JSON.parse(toolCall.function.arguments);

          console.log(`Executing function: ${functionName}`, functionArgs);

          let functionResult: any;

          try {
            // Execute the appropriate function
            switch (functionName) {
              case "create_tractors":
                functionResult = await executeCreateTractors(functionArgs.tractors, context.userId || 0);
                break;
              case "update_tractors":
                functionResult = await executeUpdateTractors(functionArgs.updates);
                break;
              case "create_drivers":
                functionResult = await executeCreateDrivers(functionArgs.drivers, context.userId || 0);
                break;
              case "update_drivers":
                functionResult = await executeUpdateDrivers(functionArgs.updates);
                break;
              default:
                functionResult = { error: `Unknown function: ${functionName}` };
            }

            functionCallResults.push({
              function: functionName,
              result: functionResult,
            });

            // Add function result to messages
            messages.push({
              role: "tool",
              tool_call_id: toolCall.id,
              content: JSON.stringify(functionResult),
            });
          } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Unknown error";
            console.error(`Function ${functionName} error:`, errorMessage);
            messages.push({
              role: "tool",
              tool_call_id: toolCall.id,
              content: JSON.stringify({ error: errorMessage }),
            });
          }
        }

        // Continue loop to get final response from GPT-4o
        continue;
      }

      // No more function calls, return final response
      const aiResponse = message.content || "I couldn't process that command. Please try again.";
      return res.json({ 
        response: aiResponse,
        functionCalls: functionCallResults,
      });
    }

    // Max iterations reached
    return res.json({ 
      response: "I processed your request but reached the maximum number of steps. Please check the results.",
      functionCalls: functionCallResults,
    });

  } catch (error) {
    console.error("AI scheduling error:", error);
    res.status(500).json({ 
      error: "Failed to process AI command",
      details: error instanceof Error ? error.message : "Unknown error"
    });
  }
}

// Function execution helpers
async function executeCreateTractors(tractors: any[], userId: number) {
  const results = [];
  for (const tractor of tractors) {
    const created = await db.createTractor({
      userId,
      entryType: "fleet" as const,
      tractorNumber: tractor.tractorNumber,
      make: tractor.make,
      model: tractor.model,
      fuel: tractor.fuel,
      vin: tractor.vin,
      licensePlate: tractor.licensePlate,
      contractType: tractor.contractType,
      status: tractor.status || "active",
    });
    results.push(created);
  }
  return { success: true, created: results.length, tractors: results };
}

async function executeUpdateTractors(updates: any[]) {
  const results = [];
  for (const update of updates) {
    // Find tractor by number
    const tractors = await db.getTractorsByUserId(0); // Get all tractors
    const tractor = tractors.find((t: any) => t.tractorNumber === update.tractorNumber);
    
    if (!tractor) {
      results.push({ tractorNumber: update.tractorNumber, error: "Tractor not found" });
      continue;
    }

    const { tractorNumber, ...updateData } = update;
    const updated = await db.updateTractor(tractor.id, updateData);
    results.push(updated);
  }
  return { success: true, updated: results.length, tractors: results };
}

async function executeCreateDrivers(drivers: any[], userId: number) {
  const results = [];
  for (const driver of drivers) {
    const created = await db.createDriver({
      userId,
      name: driver.name,
      email: driver.email,
      phone: driver.phone,
      licenseNumber: driver.licenseNumber,
      driverType: driver.driverType,
      status: driver.status || "active",
    });
    results.push(created);
  }
  return { success: true, created: results.length, drivers: results };
}

async function executeUpdateDrivers(updates: any[]) {
  const results = [];
  for (const update of updates) {
    // Find driver by name (exact match for now, could add fuzzy matching)
    const drivers = await db.getDriversByUserId(0); // Get all drivers
    const driver = drivers.find((d: any) => 
      d.name.toLowerCase() === update.name.toLowerCase()
    );
    
    if (!driver) {
      results.push({ name: update.name, error: "Driver not found" });
      continue;
    }

    const { name, ...updateData } = update;
    const updated = await db.updateDriver(driver.id, updateData);
    results.push(updated);
  }
  return { success: true, updated: results.length, drivers: results };
}

