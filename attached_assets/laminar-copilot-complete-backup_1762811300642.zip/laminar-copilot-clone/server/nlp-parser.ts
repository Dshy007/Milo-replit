/**
 * Natural Language Parser for AI Scheduling
 * Handles flexible time formats, day abbreviations, misspellings, and ranges
 */

// Day name mappings with common misspellings and abbreviations
const DAY_MAPPINGS: Record<string, string> = {
  // Full names
  'sunday': 'Sunday',
  'monday': 'Monday',
  'tuesday': 'Tuesday',
  'wednesday': 'Wednesday',
  'thursday': 'Thursday',
  'friday': 'Friday',
  'saturday': 'Saturday',
  
  // Common abbreviations
  'sun': 'Sunday',
  'mon': 'Monday',
  'tue': 'Tuesday',
  'tues': 'Tuesday',
  'wed': 'Wednesday',
  'weds': 'Wednesday',
  'thu': 'Thursday',
  'thur': 'Thursday',
  'thurs': 'Thursday',
  'fri': 'Friday',
  'sat': 'Saturday',
  
  // Single letter codes
  's': 'Sunday',
  'm': 'Monday',
  't': 'Tuesday',
  'w': 'Wednesday',
  'r': 'Thursday',
  'f': 'Friday',
  'a': 'Saturday',
  
  // Common misspellings
  'teusday': 'Tuesday',
  'tusday': 'Tuesday',
  'wendsday': 'Wednesday',
  'wensday': 'Wednesday',
  'wednsday': 'Wednesday',
  'thirsday': 'Thursday',
  'thrusday': 'Thursday',
  'fridy': 'Friday',
  'satday': 'Saturday',
  'saterday': 'Saturday',
};

// Number word mappings for time parsing
const NUMBER_WORDS: Record<string, string> = {
  'zero': '0',
  'one': '1',
  'two': '2',
  'three': '3',
  'four': '4',
  'five': '5',
  'six': '6',
  'seven': '7',
  'eight': '8',
  'nine': '9',
  'ten': '10',
  'eleven': '11',
  'twelve': '12',
  'thirteen': '13',
  'fourteen': '14',
  'fifteen': '15',
  'sixteen': '16',
  'seventeen': '17',
  'eighteen': '18',
  'nineteen': '19',
  'twenty': '20',
  'thirty': '30',
  'forty': '40',
  'fifty': '50',
};

/**
 * Parse flexible time formats into HH:MM
 * Handles: 1630, 16:30, 16;30, 16.30, "sixteen thirty", etc.
 */
export function parseTime(input: string): string | null {
  const cleaned = input.toLowerCase().trim();
  
  // Handle word-based time: "sixteen thirty" → "16:30"
  let timeStr = cleaned;
  for (const [word, num] of Object.entries(NUMBER_WORDS)) {
    timeStr = timeStr.replace(new RegExp(word, 'g'), num);
  }
  
  // Remove common separators and spaces
  timeStr = timeStr.replace(/[:\s;.,]/g, '');
  
  // Match 3-4 digit military time: 1630, 0830, 130
  const militaryMatch = timeStr.match(/^(\d{1,2})(\d{2})$/);
  if (militaryMatch) {
    const hours = militaryMatch[1].padStart(2, '0');
    const minutes = militaryMatch[2];
    
    const h = parseInt(hours);
    const m = parseInt(minutes);
    
    if (h >= 0 && h < 24 && m >= 0 && m < 60) {
      return `${hours}:${minutes}`;
    }
  }
  
  // Try to match HH:MM format (already formatted)
  const formattedMatch = cleaned.match(/^(\d{1,2})[:\s;.,](\d{2})$/);
  if (formattedMatch) {
    const hours = formattedMatch[1].padStart(2, '0');
    const minutes = formattedMatch[2];
    
    const h = parseInt(hours);
    const m = parseInt(minutes);
    
    if (h >= 0 && h < 24 && m >= 0 && m < 60) {
      return `${hours}:${minutes}`;
    }
  }
  
  return null;
}

/**
 * Parse day names with abbreviations and misspellings
 */
export function parseDay(input: string): string | null {
  const cleaned = input.toLowerCase().trim();
  return DAY_MAPPINGS[cleaned] || null;
}

/**
 * Parse day ranges like "M-F", "M-Sat", "Mon-Fri"
 */
export function parseDayRange(input: string): string[] {
  const cleaned = input.toLowerCase().trim();
  
  const WEEK_ORDER = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  
  // Match patterns like "M-F", "Mon-Fri", "Monday-Friday"
  const rangeMatch = cleaned.match(/^([a-z]+)\s*-\s*([a-z]+)$/);
  if (rangeMatch) {
    const start = parseDay(rangeMatch[1]);
    const end = parseDay(rangeMatch[2]);
    
    if (start && end) {
      const startIdx = WEEK_ORDER.indexOf(start);
      const endIdx = WEEK_ORDER.indexOf(end);
      
      if (startIdx !== -1 && endIdx !== -1 && startIdx <= endIdx) {
        return WEEK_ORDER.slice(startIdx, endIdx + 1);
      }
    }
  }
  
  // Match space-separated letter codes: "M T W T F" or "MTWRF"
  const letterPattern = cleaned.replace(/\s+/g, '');
  if (/^[smtwrfa]+$/.test(letterPattern)) {
    const days: string[] = [];
    const letterMap: Record<string, string> = {
      's': 'Sunday',
      'm': 'Monday',
      't': 'Tuesday',
      'w': 'Wednesday',
      'r': 'Thursday',
      'f': 'Friday',
      'a': 'Saturday',
    };
    
    for (const letter of letterPattern) {
      const day = letterMap[letter];
      if (day && !days.includes(day)) {
        days.push(day);
      }
    }
    
    return days;
  }
  
  return [];
}

/**
 * Parse a list of days from various formats
 * Handles: "Monday, Tuesday", "M-F", "Tues and Wed", "MTWRF"
 */
export function parseDays(input: string): string[] {
  const cleaned = input.toLowerCase().trim();
  
  // Check for range first
  const range = parseDayRange(cleaned);
  if (range.length > 0) {
    return range;
  }
  
  // Split by common separators
  const parts = cleaned.split(/[,\s]+and\s+|[,\s]+/);
  const days: string[] = [];
  
  for (const part of parts) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    
    const day = parseDay(trimmed);
    if (day && !days.includes(day)) {
      days.push(day);
    }
  }
  
  return days;
}

/**
 * Enhanced command parser with flexible NLP
 */
export function parseFlexibleCommand(command: string): {
  type: string;
  driver?: string;
  days?: string[];
  time?: string;
  rawCommand: string;
} {
  const lower = command.toLowerCase().trim();
  
  // "Fill [driver] for [days]" or "Assign [driver] to [days]"
  const fillMatch = lower.match(/(?:fill|assign|schedule|put)\s+([a-z\s]+?)\s+(?:for|to|on)\s+(.+)/i);
  if (fillMatch) {
    const driver = fillMatch[1].trim();
    const daysStr = fillMatch[2].trim();
    const days = parseDays(daysStr);
    
    // Check if there's a time in the days string
    const timeMatch = daysStr.match(/(?:at\s+)?(\d{1,4}[:\s;.,]?\d{0,2}|[a-z]+\s+[a-z]+)/i);
    let time = null;
    if (timeMatch) {
      time = parseTime(timeMatch[1]);
    }
    
    return { type: 'fill_driver', driver, days, time: time || undefined, rawCommand: command };
  }
  
  // "Who can cover [day] [time]?" or "Who's available for [day] at [time]?"
  const coverMatch = lower.match(/(?:who|which|what|show)\s+(?:can|is|are)?\s*(?:cover|available|work|do)\s+(?:for\s+)?([a-z]+)\s*(?:at\s+)?(.+)?/i);
  if (coverMatch) {
    const dayStr = coverMatch[1].trim();
    const timeStr = coverMatch[2]?.trim();
    
    const day = parseDay(dayStr);
    const time = timeStr ? parseTime(timeStr) : null;
    
    return { 
      type: 'find_available', 
      days: day ? [day] : [], 
      time: time || undefined,
      rawCommand: command 
    };
  }
  
  // "Build from last week" or "Copy last week"
  if (lower.includes('build') && lower.includes('last week') || lower.includes('copy') && lower.includes('last week')) {
    return { type: 'build_from_last_week', rawCommand: command };
  }
  
  // "Fill gaps" or "Fill remaining"
  if (lower.includes('fill') && (lower.includes('gap') || lower.includes('remaining') || lower.includes('empty'))) {
    return { type: 'fill_gaps', rawCommand: command };
  }
  
  return { type: 'unknown', rawCommand: command };
}

