-- Add imported_blocks table for Amazon Relay CSV imports
CREATE TABLE IF NOT EXISTS `imported_blocks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `blockId` VARCHAR(100) NOT NULL,
  `driverName` VARCHAR(255),
  `startDate` DATE NOT NULL,
  `startTime` VARCHAR(10) NOT NULL,
  `endDate` DATE,
  `endTime` VARCHAR(10),
  `contractType` VARCHAR(20) NOT NULL,
  `duration` VARCHAR(20),
  `payRate` VARCHAR(50),
  `origin` VARCHAR(255),
  `destination` VARCHAR(255),
  `equipmentType` VARCHAR(100),
  `truckFilter` VARCHAR(255),
  `assignedDriverId` INT,
  `weekStartDate` DATE NOT NULL,
  `importedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  INDEX `idx_userId` (`userId`),
  INDEX `idx_weekStartDate` (`weekStartDate`),
  INDEX `idx_blockId` (`blockId`)
);

