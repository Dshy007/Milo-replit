CREATE TABLE `driver_availability_slots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`dayOfWeek` varchar(20) NOT NULL,
	`startTime` varchar(10) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `driver_availability_slots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `imported_blocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`blockId` varchar(100) NOT NULL,
	`driverName` varchar(255),
	`startDate` date NOT NULL,
	`startTime` varchar(10) NOT NULL,
	`endDate` date,
	`endTime` varchar(10),
	`contractType` varchar(20) NOT NULL,
	`duration` varchar(20),
	`payRate` varchar(50),
	`origin` varchar(255),
	`destination` varchar(255),
	`equipmentType` varchar(100),
	`truckFilter` varchar(255),
	`assignedDriverId` int,
	`weekStartDate` date NOT NULL,
	`importedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `imported_blocks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `drivers` MODIFY COLUMN `status` varchar(50) NOT NULL DEFAULT 'active';--> statement-breakpoint
ALTER TABLE `tractors` MODIFY COLUMN `status` enum('active','maintenance','out_of_service','unavailable') NOT NULL DEFAULT 'active';--> statement-breakpoint
ALTER TABLE `drivers` ADD `driver_type` varchar(50);--> statement-breakpoint
ALTER TABLE `drivers` ADD `preferred_start_time` varchar(10);--> statement-breakpoint
ALTER TABLE `drivers` ADD `available_days` varchar(255);--> statement-breakpoint
ALTER TABLE `drivers` ADD `max_consecutive_days` int DEFAULT 5;--> statement-breakpoint
ALTER TABLE `tractors` ADD `entry_type` enum('fleet','start_time') DEFAULT 'fleet' NOT NULL;--> statement-breakpoint
ALTER TABLE `tractors` ADD `fuel` varchar(50);--> statement-breakpoint
ALTER TABLE `tractors` ADD `startTime` varchar(10);--> statement-breakpoint
ALTER TABLE `tractors` ADD `contractType` varchar(20);--> statement-breakpoint
ALTER TABLE `tractors` ADD `domicile` varchar(100);