import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, date } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  
  // AFP-specific fields
  companyName: varchar("companyName", { length: 255 }),
  scacCode: varchar("scacCode", { length: 10 }),
  domicile: varchar("domicile", { length: 100 }),
  homeYardCode: varchar("homeYardCode", { length: 50 }),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Drivers table - stores information about drivers
 */
export const drivers = mysqlTable("drivers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // References users table
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  licenseNumber: varchar("licenseNumber", { length: 50 }),
  driverType: varchar("driver_type", { length: 50 }), // Solo1, Solo2, Both
  preferredStartTime: varchar("preferred_start_time", { length: 10 }), // e.g., "00:30", "01:30"
  availableDays: varchar("available_days", { length: 255 }), // JSON array: ["Sunday", "Monday", "Tuesday"]
  maxConsecutiveDays: int("max_consecutive_days").default(5),
  status: varchar("status", { length: 50 }).default("active").notNull(), // active, inactive, on_leave, onboarding
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Driver = typeof drivers.$inferSelect;
export type InsertDriver = typeof drivers.$inferInsert;

/**
 * Driver preferences table - stores driver scheduling preferences
 */
export const driverPreferences = mysqlTable("driver_preferences", {
  id: int("id").autoincrement().primaryKey(),
  driverId: int("driverId").notNull(), // References drivers table
  preferredDays: text("preferredDays"), // JSON array of preferred days
  preferredShiftStart: varchar("preferredShiftStart", { length: 10 }),
  preferredShiftEnd: varchar("preferredShiftEnd", { length: 10 }),
  maxHoursPerWeek: int("maxHoursPerWeek"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Driver availability time slots - stores specific times driver can start on each day
 */
export const driverAvailabilitySlots = mysqlTable("driver_availability_slots", {
  id: int("id").autoincrement().primaryKey(),
  driverId: int("driverId").notNull(), // References drivers table
  dayOfWeek: varchar("dayOfWeek", { length: 20 }).notNull(), // Sunday, Monday, Tuesday, etc.
  startTime: varchar("startTime", { length: 10 }).notNull(), // e.g., "16:00", "16:15", "16:30"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DriverAvailabilitySlot = typeof driverAvailabilitySlots.$inferSelect;
export type InsertDriverAvailabilitySlot = typeof driverAvailabilitySlots.$inferInsert;

export type DriverPreference = typeof driverPreferences.$inferSelect;
export type InsertDriverPreference = typeof driverPreferences.$inferInsert;

/**
 * Driver availability table - tracks when drivers are available/unavailable
 */
export const driverAvailability = mysqlTable("driver_availability", {
  id: int("id").autoincrement().primaryKey(),
  driverId: int("driverId").notNull(),
  date: date("date").notNull(),
  isAvailable: boolean("isAvailable").default(true).notNull(),
  reason: varchar("reason", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DriverAvailability = typeof driverAvailability.$inferSelect;
export type InsertDriverAvailability = typeof driverAvailability.$inferInsert;

/**
 * Tractors/Vehicles table
 */
export const tractors = mysqlTable("tractors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tractorNumber: varchar("tractorNumber", { length: 50 }).notNull(),
  entryType: mysqlEnum("entry_type", ["fleet", "start_time"]).default("fleet").notNull(), // Distinguish fleet tractors from start time entries
  make: varchar("make", { length: 100 }),
  model: varchar("model", { length: 100 }),
  year: int("year"),
  fuel: varchar("fuel", { length: 50 }), // CNG, DIESEL
  vin: varchar("vin", { length: 50 }),
  licensePlate: varchar("licensePlate", { length: 20 }),
  startTime: varchar("startTime", { length: 10 }), // e.g., "00:30", "16:30"
  contractType: varchar("contractType", { length: 20 }), // Solo1, Solo2
  domicile: varchar("domicile", { length: 100 }), // e.g., "MKC"
  status: mysqlEnum("status", ["active", "maintenance", "out_of_service", "unavailable"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Tractor = typeof tractors.$inferSelect;
export type InsertTractor = typeof tractors.$inferInsert;

/**
 * Tractor availability table
 */
export const tractorAvailability = mysqlTable("tractor_availability", {
  id: int("id").autoincrement().primaryKey(),
  tractorId: int("tractorId").notNull(),
  date: date("date").notNull(),
  isAvailable: boolean("isAvailable").default(true).notNull(),
  reason: varchar("reason", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TractorAvailability = typeof tractorAvailability.$inferSelect;
export type InsertTractorAvailability = typeof tractorAvailability.$inferInsert;

/**
 * Contracts table - Amazon Relay contracts (Solo 1, Solo 2)
 */
export const contracts = mysqlTable("contracts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contractType: mysqlEnum("contractType", ["solo1", "solo2"]).notNull(),
  contractNumber: varchar("contractNumber", { length: 100 }),
  startDate: date("startDate"),
  endDate: date("endDate"),
  status: mysqlEnum("status", ["active", "inactive", "pending"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Contract = typeof contracts.$inferSelect;
export type InsertContract = typeof contracts.$inferInsert;

/**
 * Routes table - imported from Amazon Relay
 */
export const routes = mysqlTable("routes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  routeId: varchar("routeId", { length: 100 }).notNull(),
  contractId: int("contractId"),
  origin: varchar("origin", { length: 255 }),
  destination: varchar("destination", { length: 255 }),
  pickupTime: timestamp("pickupTime"),
  deliveryTime: timestamp("deliveryTime"),
  distance: int("distance"),
  status: mysqlEnum("status", ["pending", "assigned", "in_progress", "completed", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Route = typeof routes.$inferSelect;
export type InsertRoute = typeof routes.$inferInsert;

/**
 * Schedules table - weekly driver/tractor assignments
 */
export const schedules = mysqlTable("schedules", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  routeId: int("routeId").notNull(),
  driverId: int("driverId"),
  tractorId: int("tractorId"),
  scheduledDate: date("scheduledDate").notNull(),
  shiftStart: varchar("shiftStart", { length: 10 }),
  shiftEnd: varchar("shiftEnd", { length: 10 }),
  status: mysqlEnum("status", ["scheduled", "confirmed", "in_progress", "completed", "cancelled"]).default("scheduled").notNull(),
  confirmedAt: timestamp("confirmedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Schedule = typeof schedules.$inferSelect;
export type InsertSchedule = typeof schedules.$inferInsert;

/**
 * Notifications table - SMS/Email notifications sent to drivers
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  scheduleId: int("scheduleId").notNull(),
  driverId: int("driverId").notNull(),
  type: mysqlEnum("type", ["sms", "email"]).notNull(),
  message: text("message").notNull(),
  sentAt: timestamp("sentAt"),
  status: mysqlEnum("status", ["pending", "sent", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Imported Blocks table - Amazon Relay blocks imported from CSV
 */
export const importedBlocks = mysqlTable("imported_blocks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  blockId: varchar("blockId", { length: 100 }).notNull(), // e.g., B-WH58JKFB1
  driverName: varchar("driverName", { length: 255 }), // Pre-assigned driver from CSV (optional)
  startDate: varchar("startDate", { length: 20 }).notNull(), // e.g., "2025-11-02"
  startTime: varchar("startTime", { length: 10 }).notNull(), // e.g., "08:30"
  endDate: varchar("endDate", { length: 20 }), // Optional end date
  endTime: varchar("endTime", { length: 10 }), // Optional end time
  contractType: varchar("contractType", { length: 20 }).notNull(), // Solo1, Solo2
  duration: varchar("duration", { length: 20 }), // e.g., "38h", "14h"
  payRate: varchar("payRate", { length: 50 }), // e.g., "$960.39"
  origin: varchar("origin", { length: 255 }), // e.g., "LENEXA, KS"
  destination: varchar("destination", { length: 255 }),
  equipmentType: varchar("equipmentType", { length: 100 }), // e.g., "53' Trailer"
  truckFilter: varchar("truckFilter", { length: 255 }), // Full truck filter string from CSV
  assignedDriverId: int("assignedDriverId"), // Driver assigned in our system
  weekStartDate: varchar("weekStartDate", { length: 20 }).notNull(), // Sunday of the week this block belongs to (YYYY-MM-DD)
  importedAt: timestamp("importedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ImportedBlock = typeof importedBlocks.$inferSelect;
export type InsertImportedBlock = typeof importedBlocks.$inferInsert;