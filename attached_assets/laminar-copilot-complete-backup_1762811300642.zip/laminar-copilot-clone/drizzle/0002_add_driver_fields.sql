-- Add new columns to drivers table
ALTER TABLE `drivers` ADD COLUMN `driver_type` varchar(50);
ALTER TABLE `drivers` ADD COLUMN `preferred_start_time` varchar(10);
ALTER TABLE `drivers` ADD COLUMN `max_consecutive_days` int DEFAULT 5;

-- Update existing status column to allow new values
ALTER TABLE `drivers` MODIFY COLUMN `status` varchar(50) DEFAULT 'active' NOT NULL;

