CREATE TABLE `contracts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`contractType` enum('solo1','solo2') NOT NULL,
	`contractNumber` varchar(100),
	`startDate` date,
	`endDate` date,
	`status` enum('active','inactive','pending') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contracts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `driver_availability` (
	`id` int AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`date` date NOT NULL,
	`isAvailable` boolean NOT NULL DEFAULT true,
	`reason` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `driver_availability_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `driver_preferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`preferredDays` text,
	`preferredShiftStart` varchar(10),
	`preferredShiftEnd` varchar(10),
	`maxHoursPerWeek` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `driver_preferences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `drivers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`licenseNumber` varchar(50),
	`status` enum('active','inactive','on_leave') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drivers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scheduleId` int NOT NULL,
	`driverId` int NOT NULL,
	`type` enum('sms','email') NOT NULL,
	`message` text NOT NULL,
	`sentAt` timestamp,
	`status` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `routes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`routeId` varchar(100) NOT NULL,
	`contractId` int,
	`origin` varchar(255),
	`destination` varchar(255),
	`pickupTime` timestamp,
	`deliveryTime` timestamp,
	`distance` int,
	`status` enum('pending','assigned','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `routes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`routeId` int NOT NULL,
	`driverId` int,
	`tractorId` int,
	`scheduledDate` date NOT NULL,
	`shiftStart` varchar(10),
	`shiftEnd` varchar(10),
	`status` enum('scheduled','confirmed','in_progress','completed','cancelled') NOT NULL DEFAULT 'scheduled',
	`confirmedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `schedules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tractor_availability` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tractorId` int NOT NULL,
	`date` date NOT NULL,
	`isAvailable` boolean NOT NULL DEFAULT true,
	`reason` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tractor_availability_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tractors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tractorNumber` varchar(50) NOT NULL,
	`make` varchar(100),
	`model` varchar(100),
	`year` int,
	`vin` varchar(50),
	`licensePlate` varchar(20),
	`status` enum('active','maintenance','out_of_service') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tractors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `companyName` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `scacCode` varchar(10);--> statement-breakpoint
ALTER TABLE `users` ADD `domicile` varchar(100);--> statement-breakpoint
ALTER TABLE `users` ADD `homeYardCode` varchar(50);