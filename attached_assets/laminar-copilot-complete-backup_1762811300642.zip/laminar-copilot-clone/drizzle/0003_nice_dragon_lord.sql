ALTER TABLE `imported_blocks` MODIFY COLUMN `startDate` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `imported_blocks` MODIFY COLUMN `endDate` varchar(20);--> statement-breakpoint
ALTER TABLE `imported_blocks` MODIFY COLUMN `weekStartDate` varchar(20) NOT NULL;