# Shift Scheduling Research - Pain Points & Opportunities

## Key Pain Points from Reddit/Forums:

### Top Frustrations (Rating: 10/10):
1. **Time-consuming** - "Takes hours every week"
2. **Last-minute changes** - Call-outs, sick days, emergencies
3. **Balancing employee preferences** - Everyone wants different days off
4. **Manual coverage finding** - "Playing chess with pieces on fire"
5. **Constant requests** - Time off, shift swaps, availability changes
6. **No advance planning** - Schedules made week-to-week cause chaos

### What Works (Success Stories):
1. **3+ weeks advance scheduling** - Reduces conflicts dramatically
2. **Set schedules** - Consistency = happiness
3. **Automated tools** - "Schedule took 5 minutes for 5 locations"
4. **AI/Smart matching** - Auto-assign based on availability
5. **Mobile apps** - Staff can request/swap on the go

### Monday.com Complaints:
- Expensive for small businesses
- Overkill for simple scheduling
- Poor customer service
- Not shift-focused (project management tool)
- Steep learning curve

### Winning Features Users Want:
1. **AI auto-scheduling** - "Build schedule in minutes"
2. **Drag-and-drop** - Visual, intuitive
3. **Mobile-first** - Staff access anywhere
4. **Automatic conflict detection** - No double-booking
5. **Time-off management** - Built-in requests/approvals
6. **Shift swapping** - Staff self-serve
7. **Budget tracking** - Stay within labor costs
8. **Notifications** - Auto-alert staff of changes

## Competitive Positioning:

**vs Monday.com:**
- We're shift-focused (they're project management)
- 10x faster to learn
- AI does the work (they make you do it)
- Affordable for small teams

**vs 7shifts/WhenIWork:**
- AI-powered (they're manual)
- Learns from history (auto-build from last week)
- Natural language commands ("Fill Firas for Saturday")
- Modern, beautiful UI

## Marketing Angles:

**Headline Ideas:**
- "Hours of planning, done in minutes"
- "Stop playing Tetris with your schedule"
- "AI that actually saves you time"
- "From chaos to clarity in 60 seconds"
- "Your scheduling nightmare, solved"

**Key Messages:**
- Get your hours back
- AI learns your patterns
- Build from last week automatically
- Beautiful, modern interface
- Mobile-first for your team
- Affordable SaaS pricing

