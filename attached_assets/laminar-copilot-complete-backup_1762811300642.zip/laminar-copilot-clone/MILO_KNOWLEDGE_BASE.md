# Milo AI Knowledge Base - Freedom Transportation, Inc.

## Business Overview

**Company:** Freedom Transportation, Inc.  
**Primary Business:** Amazon Relay freight transportation  
**Location:** MKC (Kansas City) domicile  
**Contract Types:** Solo1 and Solo2 shifts

## Contract Start Times (17 Fixed Slots)

These are the company's fixed Amazon Relay contract start times that never change:

### Solo1 Contracts (10 slots)
- 00:30 CT - Tractor_8
- 01:30 CT - Tractor_6
- 16:30 CT - Tractor_1
- 16:30 CT - Tractor_9
- 17:30 CT - Tractor_4
- 18:30 CT - Tractor_7
- 20:30 CT - Tractor_10
- 20:30 CT - Tractor_2
- 20:30 CT - Tractor_3
- 21:30 CT - Tractor_5

### Solo2 Contracts (7 slots)
- 08:30 CT - Tractor_4
- 11:30 CT - Tractor_6
- 15:30 CT - Tractor_5
- 16:30 CT - Tractor_7
- 18:30 CT - Tractor_1
- 21:30 CT - Tractor_3
- 23:30 CT - Tractor_2

**Important:** These start times are contracts and remain constant. They are stored in the `CONTRACT_START_TIMES.txt` file.

## Amazon Relay Block Import Process

### CSV File Format
Amazon Relay exports CSV files with the following key columns:
- **Column A:** Block ID (e.g., B-KRTB9MZBG)
- **Column C:** Block/Trip (indicates if row is Block or Trip level)
- **Column S:** Truck Filter (contains contract type: Solo1 or Solo2)
- **Column AE:** Stop 1 Planned Arrival Date (MM/DD/YYYY format)
- **Column AF:** Stop 1 Planned Arrival Time (H:MM or HH:MM format)

### Import Rules
1. **Exact Time Matching:** Only import blocks where Column AF (start time) EXACTLY matches one of the 17 contract start times
2. **Week Filtering:** Import blocks for the upcoming Sunday through Saturday week, PLUS the following Sunday (to capture Saturday night shifts that continue into Sunday morning)
3. **Block Grouping:** Multiple trip rows with the same Block ID should be grouped as one block
4. **BOM Handling:** CSV files from Excel contain a Byte Order Mark (BOM) character that must be stripped before parsing
5. **Column Name Variations:** Amazon CSV columns may have single or double spaces (e.g., "Stop 1 Planned" vs "Stop 1  Planned")

### Import Workflow
1. User uploads CSV file from Amazon Relay export
2. System shows file preview with name and size
3. User clicks "Import Blocks" button
4. System parses CSV, filters by exact time match and date range
5. System groups trips by Block ID
6. System imports blocks into database
7. System displays count of imported blocks (should be ~77-78 for a typical week)

## Driver Management

### Driver Information
- Drivers have names, phone numbers, email addresses
- Drivers are categorized by contract type capability (Solo1, Solo2, or both)
- Driver availability is tracked
- Drivers can be assigned to specific blocks

### Assignment Rules
- Drivers must match the contract type of the block (Solo1 driver → Solo1 block)
- Each block can only have one driver assigned
- Drivers should not be double-booked for overlapping time slots

## Schedule Management

### Weekly Schedule Structure
- Schedules are organized by week (Sunday through Saturday)
- Each week shows:
  - Contract start times (rows)
  - Days of the week (columns)
  - Assigned drivers and blocks in each time slot

### Schedule Workflow
1. **Import Blocks:** Load Amazon Relay blocks for the target week
2. **Match to Start Times:** System matches block start times to contract start times
3. **Assign Drivers:** User assigns available drivers to matched blocks
4. **Publish:** Finalize and notify drivers of their assignments

## Data Relationships

### Database Schema
- **Drivers:** Store driver information and capabilities
- **Tractors:** Store tractor assignments to contract start times
- **Start Times:** Store the 17 fixed contract start times with tractor assignments
- **Blocks:** Store imported Amazon Relay blocks
- **Schedules:** Store driver assignments to blocks for specific dates

### Key Relationships
- Start Time → Tractor (one-to-one)
- Start Time → Contract Type (Solo1 or Solo2)
- Block → Start Time (matched by exact time)
- Block → Driver (assigned)
- Block → Date (scheduled date)

## Business Logic

### HOS (Hours of Service) Rules

**10-Hour Rest Rule:**
- Drivers MUST have 10 hours of rest between shifts
- Example: Driver finishes at 18:00 → Cannot start next shift until 04:00 (next day)
- This rule applies to all drivers regardless of contract type

**Contract Duration:**
- **Solo1 = 1 day commitment** (single day shift)
- **Solo2 = 2 consecutive days** (driver must be available for both days)

**Weekly Work Pattern:**
- Typical full week = 5 days
- Common pattern: 2 Solo2 blocks (4 days) + 1 Solo1 block (1 day) = 5 days
- Drivers should not exceed this pattern without approval

**HOS Validation Rules:**
1. Check 10-hour rest between consecutive shifts
2. For Solo2 assignments, verify driver is free for BOTH days
3. Track total days worked per week (should not exceed 5-6 days)
4. Prevent same-day double bookings

### Block Assignment Priority
1. Match block start time to contract start time (exact match required)
2. Match block contract type (Solo1/Solo2) to available drivers
3. Check driver availability for that date/time
4. Verify no HOS violations
5. Assign driver to block

## Common Scheduling Scenarios

### Call-Off Coverage Process

When a driver calls off, Milo should find replacement coverage following these steps:

**Step 1: Identify Shift Requirements**
- Start time (e.g., 16:30)
- Contract type (Solo1 or Solo2)
- Date(s) - Solo2 requires TWO consecutive days
- Block ID and any special requirements

**Step 2: Find Eligible Replacement Drivers**

A driver is eligible if ALL conditions are met:

✓ **Contract Type Match:** Driver must be qualified for that contract type (Solo1 or Solo2)

✓ **10-Hour Rest Compliance:** 
  - Calculate when driver's last shift ended
  - Ensure at least 10 hours between end of last shift and start of new shift
  - Example: Last shift ended 06:30 → Can start at 16:30 (10 hours later)

✓ **No Same-Day Conflicts:**
  - Driver must not already be assigned to another shift that day
  - Check for any overlapping time slots

✓ **Solo2 Two-Day Availability:**
  - If covering Solo2, driver must be free BOTH days
  - Check both Day 1 and Day 2 for conflicts
  - Verify 10-hour rest before Day 1 AND after Day 2

✓ **Weekly Limit Check:**
  - Count driver's total days worked that week
  - Prefer drivers under 5 days
  - Flag if assignment would exceed 5-day pattern

**Step 3: Rank Replacement Options**

Priority order for suggesting replacements:
1. **Fewest hours/days worked that week** (most rested)
2. **No upcoming shifts** (won't create future conflicts)
3. **Same domicile/location** (if applicable)
4. **Driver preference/history** (if tracked)

**Step 4: Present Options to Dispatcher**

For each eligible driver, show:
- Driver name
- Current weekly hours/days
- Last shift end time (to verify 10-hour rest)
- Next scheduled shift (to check conflicts)
- Reason why this driver is a good fit

**Step 5: Explain Ineligible Drivers**

For drivers who CAN'T cover, explain why:
- ❌ "Driver B: Already assigned to 20:30 shift same day"
- ❌ "Driver C: Last shift ended at 08:00, needs rest until 18:00 (violates 10-hour rule)"
- ❌ "Driver D: Not qualified for Solo2 (only has Solo1 certification)"
- ❌ "Driver E: Already working 5 days this week"

### Example Call-Off Scenario

**Situation:**
- Driver "Firas IMAD Tahseen" calls off for **Wednesday 11/06 at 16:30 Solo2**
- This is a 2-day commitment (Wed 11/06 + Thu 11/07)

**Milo's Analysis:**

**Eligible Drivers:**
1. **Mitchell Don YOUNG**
   - ✓ Solo2 qualified
   - ✓ Last shift ended Tuesday 06:00 (34+ hours rest)
   - ✓ No shifts Wednesday or Thursday
   - ✓ Only 2 days worked this week
   - **RECOMMENDED** ⭐

2. **Rahmatullah Sangar**
   - ✓ Solo2 qualified
   - ✓ Last shift ended Monday 18:00 (46+ hours rest)
   - ✓ No shifts Wednesday or Thursday
   - ⚠️ Already working 4 days this week (would make 6 total)
   - **AVAILABLE** (but near weekly limit)

**Ineligible Drivers:**
- **Daniel James Shirey:** ❌ Already assigned to Wednesday 20:30 (same day conflict)
- **John Smith:** ❌ Last shift ends Wednesday 08:00 (only 8.5 hours rest before 16:30)
- **Mike Johnson:** ❌ Not qualified for Solo2 (Solo1 only)

**Milo's Suggestion:**
"Assign Mitchell Don YOUNG to cover this Solo2 shift. He has the most rest, is well under weekly limits, and has no conflicts."

### Driver Swap Scenarios

*(To be expanded based on user's swap policies)*

### Last-Minute Changes

*(To be expanded based on user's change management process)*

## Common Issues & Solutions

### CSV Import Issues
- **0 blocks imported:** Check for BOM character, verify column names have correct spacing
- **Wrong block count:** Verify date filtering includes target week + following Sunday
- **Duplicate blocks:** Group by Block ID to eliminate trip-level duplicates

### Schedule Display Issues
- **Null start times:** Verify start times table has valid data in `startTime` column
- **Missing blocks:** Check that block start times exactly match contract start times
- **Wrong week displayed:** Verify week calculation starts on Sunday

## User Preferences

### Display Preferences
- No cost/money information should be shown in block displays
- Focus on operational data: times, drivers, tractors, contract types
- Mobile-friendly interface needed for on-the-go schedule management

### Workflow Preferences
- File upload should show preview before importing
- Import should be triggered by explicit button click (not automatic)
- Clear visual feedback on import success/failure with block counts
- Blocks should be displayed grouped by start time after import

## Technical Details

### File Handling
- CSV files may be in Excel format (.csv or .xlsx)
- Files contain BOM (Byte Order Mark) character: `0xFEFF`
- Column names may have inconsistent spacing
- Date format: MM/DD/YYYY
- Time format: H:MM or HH:MM (need to normalize to HH:MM)

### Date/Time Handling
- All times are in Central Time (CT)
- Week starts on Sunday
- Saturday night shifts (starting 20:30-23:30) continue into Sunday morning
- Following Sunday's early morning blocks (00:30-01:30) belong to previous week's schedule

## Milo's Role

Milo should be able to:
1. **Answer questions** about schedules, drivers, and blocks
2. **Provide insights** like "Do I have enough drivers for Solo2 next week?"
3. **Suggest assignments** based on driver availability and HOS rules
4. **Troubleshoot issues** with CSV imports or schedule conflicts
5. **Explain business logic** like why certain blocks weren't imported
6. **Guide users** through the schedule management workflow

## Context from Development History

### Key Learnings
- Amazon CSV format has subtle variations (double spaces in column names)
- BOM character causes parsing failures if not handled
- Exact time matching is critical (no "closest match" logic)
- Week boundaries must include following Sunday for Saturday night shifts
- Block grouping by Block ID prevents duplicate imports
- Date filtering must be precise to get correct block count

### User Expectations
- Simple, intuitive workflow
- Visual confirmation at each step
- Accurate block counts matching Amazon's export
- No technical jargon in error messages
- Mobile-friendly interface for field use

