import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Plus, Pencil, Trash2, Upload, Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import Papa from "papaparse";

export default function Drivers() {
  const { user } = useAuth();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [importResult, setImportResult] = useState<{ success: number; failed: number; errors: string[] } | null>(null);
  const [editingDriver, setEditingDriver] = useState<any>(null);
  const [sortColumn, setSortColumn] = useState<string>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [aiCommand, setAiCommand] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  
  const aiCommandMutation = trpc.ai.processCommand.useMutation();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    licenseNumber: "",
    driverType: "" as "Solo1" | "Solo2" | "Both" | "",
    preferredStartTime: "",
    availableDays: [] as string[],
    availabilitySlots: [] as { dayOfWeek: string; startTime: string }[],
    status: "active" as "active" | "inactive" | "on_leave",
  });

  const utils = trpc.useUtils();
  const { data: drivers, isLoading } = trpc.drivers.list.useQuery();
  
  const createMutation = trpc.drivers.create.useMutation({
    onSuccess: () => {
      utils.drivers.list.invalidate();
      setIsAddOpen(false);
      resetForm();
      toast.success("Driver added successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to add driver: ${error.message}`);
    },
  });

  const updateMutation = trpc.drivers.update.useMutation({
    onSuccess: () => {
      utils.drivers.list.invalidate();
      setEditingDriver(null);
      resetForm();
      toast.success("Driver updated successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to update driver: ${error.message}`);
    },
  });

  const importMutation = trpc.import.drivers.useMutation({
    onSuccess: (result) => {
      utils.drivers.list.invalidate();
      setImportResult(result);
      toast.success(`Imported ${result.success} drivers successfully!`);
      if (result.failed > 0) {
        toast.error(`Failed to import ${result.failed} drivers`);
      }
    },
    onError: (error) => {
      toast.error(`Import failed: ${error.message}`);
    },
  });

  const deleteMutation = trpc.drivers.delete.useMutation({
    onSuccess: () => {
      utils.drivers.list.invalidate();
      toast.success("Driver deleted successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to delete driver: ${error.message}`);
    },
  });

  const saveAvailabilitySlotsMutation = trpc.drivers.saveAvailabilitySlots.useMutation({
    onSuccess: () => {
      toast.success("Availability saved successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to save availability: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      licenseNumber: "",
      driverType: "",
      preferredStartTime: "",
      availableDays: [],
      availabilitySlots: [],
      status: "active",
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter out empty driverType
    const submitData = {
      ...formData,
      driverType: formData.driverType || undefined,
    };
    
    if (editingDriver) {
      await updateMutation.mutateAsync({
        id: editingDriver.id,
        ...submitData,
      });
      // Save availability slots after updating driver
      if (formData.availabilitySlots.length > 0) {
        await saveAvailabilitySlotsMutation.mutateAsync({
          driverId: editingDriver.id,
          slots: formData.availabilitySlots,
        });
      }
      setIsAddOpen(false);
      setEditingDriver(null);
      resetForm();
    } else {
      const newDriver = await createMutation.mutateAsync(submitData);
      // Save availability slots after creating driver
      if (formData.availabilitySlots.length > 0 && newDriver) {
        await saveAvailabilitySlotsMutation.mutateAsync({
          driverId: (newDriver as any).id,
          slots: formData.availabilitySlots,
        });
      }
      setIsAddOpen(false);
      resetForm();
    }
  };

  const handleEdit = async (driver: any) => {
    setEditingDriver(driver);
    
    // Load existing availability slots
    let slots: { dayOfWeek: string; startTime: string }[] = [];
    try {
      const existingSlots = await utils.client.drivers.getAvailabilitySlots.query({ driverId: driver.id });
      slots = existingSlots.map(slot => ({
        dayOfWeek: slot.dayOfWeek,
        startTime: slot.startTime,
      }));
    } catch (error) {
      console.error('Failed to load availability slots:', error);
    }
    
    setFormData({
      name: driver.name,
      email: driver.email || "",
      phone: driver.phone || "",
      licenseNumber: driver.licenseNumber || "",
      driverType: driver.driverType || "",
      preferredStartTime: driver.preferredStartTime || "",
      availableDays: driver.availableDays ? JSON.parse(driver.availableDays) : [],
      availabilitySlots: slots,
      status: driver.status,
    });
  };

  const handleImport = async () => {
    if (!csvFile) {
      toast.error("Please select a CSV file");
      return;
    }

    try {
      const text = await csvFile.text();
      
      // Use papaparse for robust CSV parsing
      Papa.parse(text, {
        header: true,
        skipEmptyLines: true,
        transformHeader: (header: string) => {
          // Map CSV headers to API field names
          const h = header.trim().toLowerCase();
          const headerMap: Record<string, string> = {
            // Amazon Relay export format
            'first name': 'firstName',
            'last name': 'lastName',
            'email address': 'email',
            'mobile phone number': 'phone',
            'relay status': 'status',
            'domiciles': 'domicile',
            // Standard format
            'name': 'name',
            'email': 'email',
            'phone': 'phone',
            'license_number': 'licenseNumber',
            'licensenumber': 'licenseNumber',
            'driver_type': 'driverType',
            'drivertype': 'driverType',
            'preferred_start_time': 'preferredStartTime',
            'preferredstarttime': 'preferredStartTime',
            'max_consecutive_days': 'maxConsecutiveDays',
            'maxconsecutivedays': 'maxConsecutiveDays',
            'status': 'status'
          };
          return headerMap[h] || header.trim();
        },
        complete: async (results) => {
          if (!results.data || results.data.length === 0) {
            toast.error("CSV file is empty or invalid");
            return;
          }
          
          // Transform data: combine firstName + lastName into name
          const transformedData = (results.data as any[])
            .map((row: any) => {
              const transformed: any = { ...row };
              
              // Combine first and last name if they exist
              if (row.firstName || row.lastName) {
                transformed.name = `${row.firstName || ''} ${row.lastName || ''}`.trim();
                delete transformed.firstName;
                delete transformed.lastName;
              }
              
              // Map Relay status to our status enum
              if (row.status) {
                const statusMap: Record<string, string> = {
                  'active': 'active',
                  'inactive': 'inactive',
                  'on leave': 'on_leave',
                  'onboarding': 'onboarding'
                };
                transformed.status = statusMap[row.status.toLowerCase()] || 'active';
              }
              
              return transformed;
            })
            .filter((row: any) => {
              // Skip rows without names
              if (!row.name || row.name.trim() === '') return false;
              
              // Only import Active and Inactive drivers (skip Onboarding)
              const status = row.status?.toLowerCase() || 'active';
              return status === 'active' || status === 'inactive';
            });
          
          try {
            await importMutation.mutateAsync({ data: transformedData });
            setIsImportOpen(false);
            setCsvFile(null);
          } catch (error: any) {
            toast.error(`Import failed: ${error.message}`);
          }
        },
        error: (error: any) => {
          toast.error(`Failed to parse CSV: ${error.message}`);
        }
      });
    } catch (error: any) {
      toast.error(`Failed to read file: ${error.message}`);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this driver?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const sortedDrivers = drivers ? [...drivers].sort((a: any, b: any) => {
    const aValue = a[sortColumn] || '';
    const bValue = b[sortColumn] || '';
    
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc' 
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }
    
    return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
  }) : [];

  const handleAiCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiCommand.trim()) return;

    try {
      const result = await aiCommandMutation.mutateAsync({
        command: aiCommand,
        context: {
          weekStart: new Date().toISOString(),
          driverCount: drivers?.length || 0,
          driverNames: drivers?.map(d => d.name) || [],
          scheduleSlotCount: 0,
          startTimeCount: 0,
          drivers: drivers || [],
          tractors: [],
          schedules: [],
        },
      });
      setAiResponse(result.response);
      setAiCommand('');
    } catch (error) {
      console.error('AI command error:', error);
      setAiResponse("Sorry, I encountered an error. Please try again.");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Milo AI Assistant */}
        <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50/50 to-blue-50/50">
          <CardContent className="pt-6">
            <form onSubmit={handleAiCommand} className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  <img 
                    src="/milo-logo.png" 
                    alt="Milo" 
                    className="w-12 h-12 opacity-80"
                  />
                </div>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={aiCommand}
                    onChange={(e) => setAiCommand(e.target.value)}
                    placeholder="Ask Milo anything... (e.g., 'Do I have enough drivers for Solo2 next week?')"
                    className="w-full px-4 py-3 pr-12 rounded-lg border-2 border-purple-300 focus:border-purple-500 focus:outline-none bg-white/80 text-lg placeholder:text-slate-400"
                    disabled={aiCommandMutation.isPending}
                  />
                  <button
                    type="submit"
                    disabled={aiCommandMutation.isPending || !aiCommand.trim()}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
              {aiResponse && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm font-semibold text-purple-700 mb-2">Milo:</p>
                  <p className="text-slate-700 whitespace-pre-wrap">{aiResponse}</p>
                </div>
              )}
              {aiCommandMutation.isPending && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm text-slate-500 animate-pulse">Milo is thinking...</p>
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Driver Management</h1>
            <p className="text-muted-foreground mt-2">
              Manage your driver roster and availability
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsImportOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Import CSV
            </Button>
            <Button onClick={() => setIsAddOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Driver
            </Button>
          </div>
        </div>

        {/* Import Dialog */}
        <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Import Drivers from CSV</DialogTitle>
              <DialogDescription>
                Upload a CSV file with driver information. Required columns: name. Optional: email, phone, licenseNumber, driverType (Solo1/Solo2/PartTime), preferredStartTime, status.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="csvFile">CSV File</Label>
                <Input
                  id="csvFile"
                  type="file"
                  accept=".csv"
                  onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                />
              </div>
              {importResult && (
                <div className="rounded-lg border p-4">
                  <p className="text-sm font-medium">Import Results:</p>
                  <p className="text-sm text-green-600">✓ Successfully imported: {importResult.success}</p>
                  {importResult.failed > 0 && (
                    <p className="text-sm text-red-600">✗ Failed: {importResult.failed}</p>
                  )}
                  {importResult.errors.length > 0 && (
                    <div className="mt-2 max-h-32 overflow-y-auto">
                      <p className="text-xs font-medium">Errors:</p>
                      {importResult.errors.map((error, i) => (
                        <p key={i} className="text-xs text-muted-foreground">{error}</p>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button
                onClick={handleImport}
                disabled={!csvFile || importMutation.isPending}
              >
                {importMutation.isPending ? "Importing..." : "Import"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add/Edit Driver Dialog */}
        <Dialog open={isAddOpen || !!editingDriver} onOpenChange={(open) => {
            setIsAddOpen(open);
            if (!open) {
              setEditingDriver(null);
              resetForm();
            }
          }}>
  
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>{editingDriver ? "Edit Driver" : "Add New Driver"}</DialogTitle>
                  <DialogDescription>
                    {editingDriver ? "Update driver information" : "Add a new driver to your roster"}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="license">License Number</Label>
                    <Input
                      id="license"
                      value={formData.licenseNumber}
                      onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="driverType">Driver Type</Label>
                    <Select
                      value={formData.driverType}
                      onValueChange={(value: any) => setFormData({ ...formData, driverType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select driver type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Solo1">Solo1</SelectItem>
                        <SelectItem value="Solo2">Solo2</SelectItem>
                        <SelectItem value="Both">Both</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="preferredStartTime">Preferred Start Time</Label>
                    <Input
                      id="preferredStartTime"
                      placeholder="e.g., 16:30"
                      value={formData.preferredStartTime}
                      onChange={(e) => setFormData({ ...formData, preferredStartTime: e.target.value })}
                    />
                  </div>
                  
                  {/* Availability Calendar */}
                  <div className="grid gap-2 border-t pt-4">
                    <div className="flex items-center justify-between mb-2">
                      <Label>Available Days</Label>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setFormData({ 
                              ...formData, 
                              availableDays: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] 
                            });
                          }}
                          className="text-xs"
                        >
                          Select All Days
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setFormData({ ...formData, availableDays: [] });
                          }}
                          className="text-xs"
                        >
                          Clear Days
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].map(day => (
                        <label key={day} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formData.availableDays.includes(day)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormData({ ...formData, availableDays: [...formData.availableDays, day] });
                              } else {
                                setFormData({ ...formData, availableDays: formData.availableDays.filter(d => d !== day) });
                              }
                            }}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm">{day.slice(0, 3)}</span>
                        </label>
                      ))}
                    </div>
                    
                    {/* Time Slots - Show only for selected days */}
                    {formData.availableDays.length > 0 && (
                      <div className="mt-4">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <Label className="text-sm text-gray-600">Available Start Times (15-min intervals)</Label>
                            <p className="text-xs text-gray-500">Select times when this driver can start shifts</p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                // Generate all 96 time slots for all selected days
                                const allSlots = formData.availableDays.flatMap(day =>
                                  Array.from({ length: 96 }, (_, i) => {
                                    const hours = Math.floor(i / 4);
                                    const minutes = (i % 4) * 15;
                                    const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
                                    return { dayOfWeek: day, startTime: timeStr };
                                  })
                                );
                                setFormData({ ...formData, availabilitySlots: allSlots });
                              }}
                              className="text-xs"
                            >
                              Select All Times
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setFormData({ ...formData, availabilitySlots: [] });
                              }}
                              className="text-xs"
                            >
                              Clear All
                            </Button>
                          </div>
                        </div>
                        <div className="max-h-40 overflow-y-auto border rounded p-2 grid grid-cols-4 gap-1">
                          {Array.from({ length: 96 }, (_, i) => {
                            const hours = Math.floor(i / 4);
                            const minutes = (i % 4) * 15;
                            const timeStr = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
                            const isSelected = formData.availabilitySlots.some(slot => slot.startTime === timeStr);
                            return (
                              <button
                                key={timeStr}
                                type="button"
                                onClick={() => {
                                  if (isSelected) {
                                    setFormData({
                                      ...formData,
                                      availabilitySlots: formData.availabilitySlots.filter(s => s.startTime !== timeStr)
                                    });
                                  } else {
                                    // Add this time for all selected days
                                    const newSlots = formData.availableDays.map(day => ({
                                      dayOfWeek: day,
                                      startTime: timeStr
                                    }));
                                    setFormData({
                                      ...formData,
                                      availabilitySlots: [...formData.availabilitySlots, ...newSlots]
                                    });
                                  }
                                }}
                                className={`text-xs px-2 py-1 rounded ${
                                  isSelected
                                    ? 'bg-blue-500 text-white'
                                    : 'bg-gray-100 hover:bg-gray-200'
                                }`}
                              >
                                {timeStr}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value: any) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                        <SelectItem value="on_leave">On Leave</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                    {editingDriver ? "Update" : "Add"} Driver
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

        {/* Drivers Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Drivers</CardTitle>
            <CardDescription>
              {drivers?.length || 0} drivers in your roster
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-muted-foreground">Loading drivers...</p>
            ) : drivers && drivers.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('name')}>
                      Name {sortColumn === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('email')}>
                      Email {sortColumn === 'email' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('phone')}>
                      Phone {sortColumn === 'phone' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('licenseNumber')}>
                      License # {sortColumn === 'licenseNumber' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('status')}>
                      Status {sortColumn === 'status' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedDrivers.map((driver) => (
                    <TableRow key={driver.id}>
                      <TableCell className="font-medium">{driver.name}</TableCell>
                      <TableCell>{driver.email || "—"}</TableCell>
                      <TableCell>{driver.phone || "—"}</TableCell>
                      <TableCell>{driver.licenseNumber || "—"}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          driver.status === "active" ? "bg-green-100 text-green-800" :
                          driver.status === "inactive" ? "bg-red-100 text-red-800" :
                          driver.status === "on_leave" ? "bg-yellow-100 text-yellow-800" :
                          "bg-gray-100 text-gray-800"
                        }`}>
                          {driver.status.replace("_", " ")}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(driver)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(driver.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">No drivers yet</p>
                <Button onClick={() => setIsAddOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Your First Driver
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

