import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";
import { Link } from "wouter";

export default function Pricing() {
  const plans = [
    {
      name: "Starter Plan",
      price: "$10",
      period: "per user per month",
      description: "Basic features perfect for getting started.",
      features: [
        "Customizable template",
        "24/7 email support",
        "Basic analytics",
        "Up to 5 users"
      ],
      cta: "Select Plan",
      variant: "outline" as const
    },
    {
      name: "Pro Plan",
      price: "$25",
      period: "per user per month",
      description: "Pro features perfect for professional users.",
      features: [
        "Everything in starter plan, plus..",
        "Advanced integrations",
        "SEO optimization tools",
        "Priority support",
        "Up to 20 users"
      ],
      cta: "Start 7-Day Free Trial",
      variant: "default" as const,
      popular: true
    },
    {
      name: "Enterprise Plan",
      price: "$50",
      period: "per user per month",
      description: "Enterprise features for wide-scale companies.",
      features: [
        "Everything in pro plan, plus..",
        "Unlimited integrations",
        "Dedicated account manager",
        "Custom SLA",
        "Unlimited users"
      ],
      cta: "Contact Us",
      variant: "outline" as const
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-12 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4 text-primary">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 2L2 6L10 10L18 6L10 2Z" opacity="0.6"/>
              </svg>
              <span className="text-sm font-semibold uppercase">Affordable Plans</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-4 font-serif">
              Preferred by startups and<br />growing businesses
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Trusted by thousands of entrepreneurs and teams to deliver high value at a competitive price.
            </p>
          </div>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <Button variant="default" size="lg" className="rounded-full">
              Monthly
            </Button>
            <Button variant="outline" size="lg" className="rounded-full">
              Annual -20%
            </Button>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <Card key={index} className={`p-8 ${plan.popular ? 'border-2 border-primary shadow-lg' : 'border'}`}>
                {plan.popular && (
                  <div className="bg-primary text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full inline-block mb-4">
                    MOST POPULAR
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-5xl font-bold">{plan.price}</span>
                  <div className="text-sm text-muted-foreground">
                    {plan.period.split(' ').map((word, i) => (
                      <div key={i}>{word}</div>
                    ))}
                  </div>
                </div>
                <p className="text-muted-foreground mb-6">{plan.description}</p>
                <Button 
                  asChild 
                  variant={plan.variant} 
                  size="lg" 
                  className={`w-full rounded-full mb-6 ${plan.popular ? 'bg-accent hover:bg-accent/90' : ''}`}
                >
                  <Link href="/contact">{plan.cta}</Link>
                </Button>
                <div className="space-y-3">
                  <p className="text-sm font-semibold text-muted-foreground mb-3">
                    {plan.features[0]}
                  </p>
                  {plan.features.slice(1).map((feature, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <svg className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-20 bg-muted">
        <div className="container max-w-6xl">
          <h2 className="text-4xl font-bold mb-12 text-center font-serif">Let's compare the plans</h2>
          <Card className="p-8">
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                Detailed feature comparison table coming soon. Contact us to learn more about specific features.
              </p>
            </div>
          </Card>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 font-serif">The globe's top reliable enterprise</h2>
            <p className="text-lg text-muted-foreground">
              Praised by innovators and entrepreneurs
            </p>
          </div>
          <div className="grid md:grid-cols-5 gap-8 max-w-4xl mx-auto items-center opacity-50">
            {['Company 1', 'Company 2', 'Company 3', 'Company 4', 'Company 5'].map((company, i) => (
              <div key={i} className="text-center font-bold text-2xl text-muted-foreground">
                {company}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-muted">
        <div className="container max-w-3xl">
          <h2 className="text-4xl font-bold mb-12 text-center font-serif">Frequently asked questions</h2>
          <p className="text-center text-muted-foreground">
            Have a question? Browse our FAQ section for detailed explanations and solutions.
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}

