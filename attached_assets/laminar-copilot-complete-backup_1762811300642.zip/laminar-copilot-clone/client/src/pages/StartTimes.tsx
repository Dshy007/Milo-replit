import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Upload, Send } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import Papa from "papaparse";

export default function StartTimes() {
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [sortColumn, setSortColumn] = useState<string>('startTime');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [aiCommand, setAiCommand] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  
  const aiCommandMutation = trpc.ai.processCommand.useMutation();

  const { data: tractors, refetch } = trpc.tractors.listStartTimes.useQuery();
  const importMutation = trpc.tractors.importStartTimes.useMutation({
    onSuccess: () => {
      toast.success("Start times imported successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(`Import failed: ${error.message}`);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setCsvFile(e.target.files[0]);
    }
  };

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const sortedTractors = tractors ? [...tractors].sort((a: any, b: any) => {
    const aValue = a[sortColumn] || '';
    const bValue = b[sortColumn] || '';
    
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc' 
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }
    
    return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
  }) : [];

  const handleImport = async () => {
    console.log('Import started', { csvFile: !!csvFile, importText: !!importText });
    setIsImporting(true);
    try {
      let data: any[] = [];

      if (csvFile) {
        // Parse CSV file
        const text = await csvFile.text();
        Papa.parse(text, {
          header: true,
          skipEmptyLines: true,
          transformHeader: (header: string) => {
            const h = header.trim().toLowerCase();
            const headerMap: Record<string, string> = {
              'start time': 'startTime',
              'starttime': 'startTime',
              'tractor': 'tractorNumber',
              'driver type': 'contractType',
              'drivertype': 'contractType',
              'domicile': 'domicile',
              'domiciles': 'domicile',
              'status': 'status',
            };
            return headerMap[h] || header.trim();
          },
          complete: async (results) => {
            if (!results.data || results.data.length === 0) {
              toast.error("CSV file is empty or invalid");
              return;
            }

            // Transform data
            const transformedData = (results.data as any[])
              .map((row: any) => ({
                tractorNumber: row.tractorNumber?.replace(/^Tractor_/, '') || '',
                startTime: row.startTime?.replace(' CT', '').trim() || '',
                contractType: row.contractType || 'Solo1',
                domicile: row.domicile || 'MKC',
                status: (row.status?.toLowerCase() === 'active' ? 'active' : 'maintenance') as "active" | "maintenance" | "out_of_service",
              }))
              .filter((row: any) => row.tractorNumber && row.startTime);

            try {
              console.log('Importing data:', transformedData);
              await importMutation.mutateAsync({ data: transformedData });
              await refetch(); // Force refetch
              setIsImportOpen(false);
              setCsvFile(null);
              setIsImporting(false);
            } catch (error: any) {
              console.error('Import mutation error:', error);
              toast.error(`Import failed: ${error.message}`);
              setIsImporting(false);
            }
          },
          error: (error: any) => {
            toast.error(`Failed to parse CSV: ${error.message}`);
          }
        });
      } else if (importText.trim()) {
        // Parse pasted text (supports tab-separated, comma-separated, or vertical format)
        const lines = importText.trim().split('\n').filter(line => line.trim());
        
        // Check if it's vertical format (one value per line, no separators)
        const firstLine = lines[0];
        const hasTabOrComma = /[,\t]/.test(firstLine);
        
        if (!hasTabOrComma && lines.length >= 5) {
          // Vertical format: every 5 lines is one record
          // Format: Start Time, Status, Tractor, Driver Type, Domicile
          for (let i = 0; i < lines.length; i += 5) {
            if (i + 4 < lines.length) {
              data.push({
                startTime: lines[i].replace(' CT', '').trim(),
                status: lines[i + 1].toLowerCase() === 'active' ? 'active' : 'maintenance',
                tractorNumber: lines[i + 2].replace(/^Tractor_/, ''),
                contractType: lines[i + 3],
                domicile: lines[i + 4] || 'MKC',
              });
            }
          }
        } else {
          // Tab or comma separated format
          const headers = lines[0].split(/[,\t]/).map(h => h.trim());
          
          for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(/[,\t]/).map(v => v.trim());
            if (values.length >= 4) {
              data.push({
                startTime: values[0].replace(' CT', '').trim(),
                status: values[1].toLowerCase() === 'active' ? 'active' : 'maintenance',
                tractorNumber: values[2].replace(/^Tractor_/, ''),
                contractType: values[3],
                domicile: values[4] || 'MKC',
              });
            }
          }
        }

        console.log('Importing pasted data:', data);
        await importMutation.mutateAsync({ data });
        await refetch(); // Force refetch
        setIsImportOpen(false);
        setImportText("");
        setIsImporting(false);
      } else {
        toast.error("Please provide CSV file or paste data");
      }
    } catch (error: any) {
      console.error('Import error:', error);
      toast.error(`Import failed: ${error.message}`);
      setIsImporting(false);
    }
  };

  const handleAiCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiCommand.trim()) return;

    try {
      const result = await aiCommandMutation.mutateAsync({
        command: aiCommand,
        context: {
          weekStart: new Date().toISOString(),
          driverCount: 0,
          driverNames: [],
          scheduleSlotCount: 0,
          startTimeCount: tractors?.length || 0,
          drivers: [],
          tractors: tractors || [],
          schedules: [],
        },
      });
      setAiResponse(result.response);
      setAiCommand('');
    } catch (error) {
      console.error('AI command error:', error);
      setAiResponse("Sorry, I encountered an error. Please try again.");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Milo AI Assistant */}
        <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50/50 to-blue-50/50">
          <CardContent className="pt-6">
            <form onSubmit={handleAiCommand} className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  <img 
                    src="/milo-logo.png" 
                    alt="Milo" 
                    className="w-12 h-12 opacity-80"
                  />
                </div>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={aiCommand}
                    onChange={(e) => setAiCommand(e.target.value)}
                    placeholder="Ask Milo anything... (e.g., 'Do I have enough drivers for Solo2 next week?')"
                    className="w-full px-4 py-3 pr-12 rounded-lg border-2 border-purple-300 focus:border-purple-500 focus:outline-none bg-white/80 text-lg placeholder:text-slate-400"
                    disabled={aiCommandMutation.isPending}
                  />
                  <button
                    type="submit"
                    disabled={aiCommandMutation.isPending || !aiCommand.trim()}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
              {aiResponse && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm font-semibold text-purple-700 mb-2">Milo:</p>
                  <p className="text-slate-700 whitespace-pre-wrap">{aiResponse}</p>
                </div>
              )}
              {aiCommandMutation.isPending && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm text-slate-500 animate-pulse">Milo is thinking...</p>
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Start Times</h1>
            <p className="text-muted-foreground mt-1">
              Import and manage your Amazon Relay start times and tractor assignments
            </p>
          </div>
          <Button onClick={() => setIsImportOpen(true)}>
            <Upload className="mr-2 h-4 w-4" />
            Import Start Times
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All Start Times</CardTitle>
            <CardDescription>
              {tractors?.length || 0} tractor assignments configured
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!tractors || tractors.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>No start times configured yet.</p>
                <p className="text-sm mt-2">Import your Amazon Relay start times to get started.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('startTime')}>
                      Start Time {sortColumn === 'startTime' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('tractorNumber')}>
                      Tractor {sortColumn === 'tractorNumber' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('contractType')}>
                      Contract Type {sortColumn === 'contractType' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('domicile')}>
                      Domicile {sortColumn === 'domicile' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('status')}>
                      Status {sortColumn === 'status' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedTractors
                    .map((tractor) => (
                      <TableRow key={tractor.id}>
                        <TableCell className="font-medium">{tractor.startTime || '—'}</TableCell>
                        <TableCell>{tractor.tractorNumber}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            tractor.contractType === 'Solo1' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                          }`}>
                            {tractor.contractType || 'Solo1'}
                          </span>
                        </TableCell>
                        <TableCell>{tractor.domicile || '—'}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            tractor.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                          }`}>
                            {tractor.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                // TODO: Open edit dialog
                                toast.info("Edit functionality coming soon");
                              }}
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                              </svg>
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                // TODO: Delete tractor
                                toast.info("Delete functionality coming soon");
                              }}
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-red-600" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                              </svg>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Import Start Times</DialogTitle>
              <DialogDescription>
                Upload a CSV file or paste your Amazon Relay start times table.
                Expected columns: Start Time, Status, Tractor, Driver Type, Domicile
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">CSV File</label>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="mt-1 block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-md file:border-0
                    file:text-sm file:font-semibold
                    file:bg-primary file:text-primary-foreground
                    hover:file:bg-primary/90"
                />
                {csvFile && (
                  <p className="text-sm text-muted-foreground mt-1">
                    Selected: {csvFile.name}
                  </p>
                )}
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">Or paste data</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Paste Table Data</label>
                <Textarea
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder="Start Time	Status	Tractor	Driver Type	Domicile
00:30 CT	Active	Tractor_8	Solo1	MKC
01:30 CT	Active	Tractor_6	Solo1	MKC"
                  className="mt-1 font-mono text-sm"
                  rows={5}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsImportOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleImport} disabled={(!csvFile && !importText.trim()) || isImporting}>
                  {isImporting ? 'Importing...' : 'Import'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}

