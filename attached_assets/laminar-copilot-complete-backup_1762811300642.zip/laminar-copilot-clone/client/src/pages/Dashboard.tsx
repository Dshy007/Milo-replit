import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Users, Truck, Calendar, TrendingUp } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: drivers, isLoading: driversLoading } = trpc.drivers.list.useQuery();
  const { data: tractors, isLoading: tractorsLoading } = trpc.tractors.list.useQuery();
  const { data: schedules, isLoading: schedulesLoading } = trpc.schedules.list.useQuery();
  
  // Milo AI is now global (floating button) - removed from Dashboard

  const activeDrivers = drivers?.filter(d => d.status === "active").length || 0;
  const activeTractors = tractors?.filter(t => t.status === "active").length || 0;
  const upcomingSchedules = schedules?.filter(s => s.status === "scheduled").length || 0;
  
  // Driver type breakdown
  const solo1Drivers = drivers?.filter(d => d.status === "active" && d.driverType === "Solo1").length || 0;
  const solo2Drivers = drivers?.filter(d => d.status === "active" && d.driverType === "Solo2").length || 0;
  const bothDrivers = drivers?.filter(d => d.status === "active" && d.driverType === "Both").length || 0;
  const inactiveDrivers = drivers?.filter(d => d.status !== "active").length || 0;
  
  // Tractor type breakdown
  const solo1Tractors = tractors?.filter(t => t.status === "active" && t.contractType === "Solo1").length || 0;
  const solo2Tractors = tractors?.filter(t => t.status === "active" && t.contractType === "Solo2").length || 0;
  const inactiveTractors = tractors?.filter(t => t.status !== "active").length || 0;

  // Milo AI handler removed - using global floating Milo instead

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Welcome back, {user?.name || "User"}!</h1>
          <p className="text-muted-foreground mt-2">
            Here's what's happening with your AFP operations today.
          </p>
        </div>

        {/* Milo AI is now available via the floating chat button (bottom-right) */}

        {/* Stats Cards with Actions */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {/* Active Drivers Card */}
          <Link href="/drivers">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow hover:border-blue-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Drivers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="mb-4 pb-4 border-b">
                <Button className="w-full" size="sm">Manage Drivers</Button>
              </div>
              <div className="text-2xl font-bold">{activeDrivers}</div>
              <p className="text-xs text-muted-foreground mb-2">
                {drivers?.length || 0} total drivers{inactiveDrivers > 0 && ` (${inactiveDrivers} inactive)`}
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Solo1:</span>
                  <span className="font-medium">{solo1Drivers}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Solo2:</span>
                  <span className="font-medium">{solo2Drivers}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Both:</span>
                  <span className="font-medium">{bothDrivers}</span>
                </div>
              </div>
            </CardContent>
            </Card>
          </Link>

          {/* Active Tractors Card */}
          <Link href="/tractors">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow hover:border-blue-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Tractors</CardTitle>
              <Truck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="mb-4 pb-4 border-b">
                <Button className="w-full" size="sm">Manage Tractors</Button>
              </div>
              <div className="text-2xl font-bold">{activeTractors}</div>
              <p className="text-xs text-muted-foreground mb-2">
                {tractors?.length || 0} total tractors{inactiveTractors > 0 && ` (${inactiveTractors} inactive)`}
              </p>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Solo1:</span>
                  <span className="font-medium">{solo1Tractors}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Solo2:</span>
                  <span className="font-medium">{solo2Tractors}</span>
                </div>
              </div>
            </CardContent>
            </Card>
          </Link>

          {/* Upcoming Schedules Card */}
          <Link href="/schedules">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow hover:border-blue-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Upcoming Schedules</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="mb-4 pb-4 border-b">
                <Button className="w-full" size="sm">Make Schedules</Button>
              </div>
              <div className="text-2xl font-bold">{upcomingSchedules}</div>
              <p className="text-xs text-muted-foreground">
                This week
              </p>
            </CardContent>
            </Card>
          </Link>

          {/* Routes Scheduled Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Routes Scheduled</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">20,000+</div>
              <p className="text-xs text-muted-foreground">
                All time
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Schedules</CardTitle>
            <CardDescription>
              Latest schedule assignments and updates
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              No schedules yet. Create your first schedule to get started!
            </p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

