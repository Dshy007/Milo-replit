import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";

export default function Features() {
  const features = [
    {
      icon: "⚡",
      tag: "DYNAMIC SCHEDULER",
      title: "Weekly schedules automatically created",
      description: "Milo builds your weekly driver schedules for you in seconds, taking into account driver shift preferences, planned maintenance, and time-off requests.",
      image: "📊"
    },
    {
      icon: "🚗",
      tag: "REAL-TIME DRIVER/TRACTOR AVAILABILITY",
      title: "Driver/tractor down? We got you.",
      description: "Instantly reallocates routes when a driver/tractor is down – stay on track without the manual scramble.",
      image: "📅"
    },
    {
      icon: "💬",
      tag: "AUTOMATED TEXTS TO DRIVERS",
      title: "Automated reminder texts for peace of mind",
      description: "Drivers receive confirmation texts and truck assignments sent directly to them. If drivers do not confirm, operators/managers receive texts to address potential risk.",
      image: "📱"
    },
    {
      icon: "👥",
      tag: "TEAM MANAGEMENT",
      title: "Integrated driver preferences",
      description: "Milo keeps your driver preferences in mind when providing suggestions. Whether its preferred working days, shift times, planned PTO, or one off schedule accommodations, it's all accounted for.",
      image: "📋"
    },
    {
      icon: "📊",
      tag: "AUDIT PANEL",
      title: "Stay up to date and address daily risks",
      description: "Manage all potential risk such as driver and tractor unavailability in one organized space, without having to track everything yourself.",
      image: "🔍"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-12 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4 text-primary">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 2L2 6L10 10L18 6L10 2Z" opacity="0.6"/>
              </svg>
              <span className="text-sm font-semibold uppercase">All Features</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold font-serif">
              A look inside <span className="text-primary">Milo</span>
            </h1>
          </div>
        </div>
      </section>

      {/* Features List */}
      <section className="py-12 bg-white">
        <div className="container max-w-6xl">
          <div className="space-y-24">
            {features.map((feature, index) => (
              <div key={index} className={`grid md:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
                <div className={index % 2 === 1 ? 'md:order-2' : ''}>
                  <div className="flex items-center gap-2 mb-4 text-primary">
                    <span className="text-2xl">{feature.icon}</span>
                    <span className="text-sm font-semibold uppercase">{feature.tag}</span>
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">{feature.title}</h2>
                  <p className="text-lg text-muted-foreground">{feature.description}</p>
                </div>
                <div className={index % 2 === 1 ? 'md:order-1' : ''}>
                  <Card className="p-8 bg-muted border-2 border-border">
                    <div className="aspect-video flex items-center justify-center bg-white rounded-lg">
                      <div className="text-8xl">{feature.image}</div>
                    </div>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Waitlist Form */}
      <section className="py-20 bg-secondary text-secondary-foreground">
        <div className="container max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6 font-serif">Join the waitlist</h2>
              <p className="text-lg mb-4">
                For general questions or inquiries, email us at <strong>info@manus.com</strong>
              </p>
              <p className="text-sm text-secondary-foreground/70 mb-2">*Must currently be an active AFP.</p>
              <p className="text-sm text-secondary-foreground/70">
                **Due to current demand, Milo is onboarding based on a waitlist. Expected onboarding timelines will be communicated and is subject to change.
              </p>
            </div>

            <Card className="p-6 bg-white">
              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Name*</Label>
                    <Input id="name" placeholder="Full name" required />
                  </div>
                  <div>
                    <Label htmlFor="email">Email*</Label>
                    <Input id="email" type="email" placeholder="jane@example.com" required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Phone*</Label>
                    <Input id="phone" type="tel" placeholder="(123) 456 7890" required />
                  </div>
                  <div>
                    <Label htmlFor="company">Company</Label>
                    <Input id="company" placeholder="Company" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="domicile">Domicile*</Label>
                    <Input id="domicile" placeholder="Domicile" required />
                  </div>
                  <div>
                    <Label htmlFor="contract">Contract Type(s)*</Label>
                    <Select required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="solo2">Solo 2 Only</SelectItem>
                        <SelectItem value="both">Solo 1 and Solo 2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="scac">SCAC Code*</Label>
                    <Input id="scac" placeholder="SCAC Code" required />
                  </div>
                  <div>
                    <Label htmlFor="yard">Home Yard Code*</Label>
                    <Input id="yard" placeholder="Home Yard Code" required />
                  </div>
                </div>
                <Button type="submit" className="w-full rounded-full" size="lg">
                  Submit
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

