import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  // Generate calendar dates for backdrop
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dates = Array.from({ length: 35 }, (_, i) => i + 1);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 flex items-center justify-center relative overflow-hidden">
      {/* Animated Background Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-100/20 via-transparent to-blue-100/20 animate-pulse" style={{ animationDuration: '8s' }}></div>

      {/* Realistic Calendar Backdrop with Month Header */}
      <div className="absolute inset-0 flex items-center justify-center opacity-20 p-8 md:p-20">
        <div className="w-full max-w-5xl">
          {/* Month Header */}
          <div className="text-center mb-6">
            <h3 className="text-2xl md:text-3xl font-bold text-slate-400">November 2025</h3>
          </div>
          {/* Calendar Header */}
          <div className="grid grid-cols-7 gap-2 md:gap-3 mb-4">
            {daysOfWeek.map((day) => (
              <div key={day} className="text-center text-sm md:text-base font-semibold text-slate-400 p-2">
                {day}
              </div>
            ))}
          </div>
          {/* Calendar Dates */}
          <div className="grid grid-cols-7 gap-2 md:gap-3">
            {dates.map((date) => (
              <div 
                key={date} 
                className="aspect-square border-2 border-slate-300 rounded-lg p-2 md:p-3 bg-white/30 hover:bg-white/50 transition-all cursor-pointer"
              >
                <div className="text-xs md:text-sm text-slate-400 font-medium">{date}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Giant Milo with Floating Animation */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <img 
          src="/milo-logo.png" 
          alt="Milo Background" 
          className="w-[800px] md:w-[1200px] h-[800px] md:h-[1200px] opacity-18 animate-float"
          style={{
            animation: 'float 6s ease-in-out infinite',
          }}
        />
      </div>

      {/* Floating Animation Keyframes */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
      `}</style>

      {/* Content - Foreground */}
      <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
        {/* Meet Milo - Hero Size with Text Shadow */}
        <div className="mb-12 md:mb-16">
          <h1 className="text-5xl sm:text-7xl md:text-9xl lg:text-[10rem] font-black bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 bg-clip-text text-transparent mb-6 drop-shadow-lg" style={{ letterSpacing: '-0.02em' }}>
            meet... Milo
          </h1>
          <div className="w-32 md:w-48 h-1.5 md:h-2 bg-gradient-to-r from-purple-600 to-blue-600 mx-auto rounded-full shadow-lg"></div>
        </div>

        {/* Main Headline with Better Typography */}
        <h2 className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold text-slate-900 mb-6 md:mb-12 leading-tight drop-shadow-sm px-4" style={{ letterSpacing: '-0.01em' }}>
          Stop wasting hours
          <br />
          every week on scheduling
        </h2>

        {/* Subheadline - Enhanced */}
        <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-slate-700 mb-8 md:mb-16 leading-relaxed max-w-4xl mx-auto px-4">
          You don't need another tool — you need a teammate. Milo plans, builds, and publishes your entire schedule automatically, so you stay in control while everything gets done effortlessly.
        </p>

        {/* CTA Button with Enhanced Shadow */}
        <div className="mb-8 md:mb-12">
          <Link href="/dashboard">
            <Button 
              size="lg" 
              className="text-lg sm:text-xl md:text-2xl px-8 sm:px-12 md:px-16 py-5 sm:py-7 md:py-9 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-2xl hover:shadow-purple-500/50 hover:scale-105 transition-all duration-300 rounded-full font-semibold"
            >
              Get Started Free
            </Button>
          </Link>
        </div>

        {/* Social Proof */}
        <p className="text-sm md:text-base text-slate-500">
          No credit card required • 5 minute setup
        </p>
      </div>
    </div>
  );
}

