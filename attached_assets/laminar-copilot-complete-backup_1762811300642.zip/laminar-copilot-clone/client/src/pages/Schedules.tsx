import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { validate10HourBreak, calculateShiftEndTime } from "@/lib/hosValidation";
import { useAuth } from "@/_core/hooks/useAuth";
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, PointerSensor, useDraggable, useDroppable, useSensor, useSensors } from "@dnd-kit/core";
import { Calendar, ChevronLeft, ChevronRight, Plus, Sparkles, Send } from "lucide-react";
import { useState, useMemo } from "react";
import { AISchedulingChat } from "@/components/AISchedulingChat";
import { AISchedulingService } from "@/lib/aiSchedulingService";
import { parseBlockCSV } from "@/lib/blockImportParser";
import BlocksTableView from "@/components/BlocksTableView";
import { autoBuildFromLastWeek } from "@/lib/autoBuildService";
import { toast } from "sonner";


// Time slots will be loaded dynamically from Start Times table

const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function Schedules() {
  const { user } = useAuth();
  const aiCommandMutation = trpc.ai.processCommand.useMutation();
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const today = new Date();
    const day = today.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    // Calculate days since last Sunday (0 if today is Sunday)
    const daysSinceSunday = day;
    const thisSunday = new Date(today);
    thisSunday.setDate(today.getDate() - daysSinceSunday);
    thisSunday.setHours(0, 0, 0, 0);
    return thisSunday;
  });
  
  const [activeDriver, setActiveDriver] = useState<any>(null);
  const [scheduleData, setScheduleData] = useState<Record<string, any>>({});
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    existingDriver: string;
    newDriver: string;
    onConfirm: () => void;
  }>({ open: false, existingDriver: "", newDriver: "", onConfirm: () => {} });
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importData, setImportData] = useState("");
  const [parsedBlocks, setParsedBlocks] = useState<any[]>([]);
  const [parseErrors, setParseErrors] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"calendar" | "table">("calendar");
  const [calendarExpanded, setCalendarExpanded] = useState(true);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [csvContent, setCsvContent] = useState<string>("");
  const [driverSearch, setDriverSearch] = useState<string>("");
  
  // Query blocks by current week
  const utils = trpc.useUtils();
  const weekStartStr = currentWeekStart.toISOString().split('T')[0];
  const { data: importedBlocks = [] } = trpc.import.getBlocksByWeek.useQuery({
    weekStartDate: weekStartStr,
  });
  
  const importBlocksMutation = trpc.import.amazonBlocks.useMutation({
    onSuccess: (result) => {
      toast.success(`Imported ${result.imported} blocks successfully`);
      setViewMode("table"); // Switch to table view after import
      setImportDialogOpen(false);
      // Refetch blocks for current week
      utils.import.getBlocksByWeek.invalidate();
    },
    onError: (error) => {
      toast.error(`Import failed: ${error.message}`);
    },
  });
  
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      console.log('[CSV Upload] No file selected');
      return;
    }
    
    console.log('[CSV Upload] File selected:', file.name, 'Size:', file.size, 'bytes');
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      const csvContent = event.target?.result as string;
      console.log('[CSV Upload] File read successfully, length:', csvContent.length);
      console.log('[CSV Upload] First 200 chars:', csvContent.substring(0, 200));
      console.log('[CSV Upload] Calling import mutation...');
      importBlocksMutation.mutate({ csvContent });
    };
    reader.onerror = (error) => {
      console.error('[CSV Upload] File read error:', error);
      toast.error('Failed to read CSV file');
    };
    reader.readAsText(file);
  };
  const [aiPrompt, setAiPrompt] = useState("");
  const [warningsDialogOpen, setWarningsDialogOpen] = useState(false);
  const [buildWarnings, setBuildWarnings] = useState<string[]>([]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const { data: drivers } = trpc.drivers.list.useQuery();
  const { data: schedules } = trpc.schedules.list.useQuery();
  
  // Create calendar rows by grouping imported blocks by time+type+tractor
  // Extract tractor number from truckFilter to create separate rows for each tractor
  const calendarRows = useMemo(() => {
    // Extract unique time+type+tractor combinations from imported blocks
    const uniqueTimeTypes = new Map<string, { startTime: string; contractType: string; tractorNum: string }>();
    
    importedBlocks.forEach(block => {
      // Extract tractor number from truckFilter (e.g., "FTIM_MKC_Solo1_Tractor_9_d2" -> "9")
      const tractorMatch = block.truckFilter?.match(/Tractor_(\d+)/);
      const tractorNum = tractorMatch ? tractorMatch[1] : 'Unknown';
      
      const key = `${block.startTime}_${block.contractType}_${tractorNum}`;
      if (!uniqueTimeTypes.has(key)) {
        uniqueTimeTypes.set(key, {
          startTime: block.startTime,
          contractType: block.contractType,
          tractorNum: tractorNum
        });
      }
    });
    
    // Convert to array and sort
    return Array.from(uniqueTimeTypes.values())
      .map(item => ({
        key: `${item.startTime}_${item.contractType}_${item.tractorNum}`,
        startTime: item.startTime,
        contractType: item.contractType,
        tractorNum: item.tractorNum
      }))
      .sort((a, b) => 
        a.startTime.localeCompare(b.startTime) || 
        a.contractType.localeCompare(b.contractType) ||
        a.tractorNum.localeCompare(b.tractorNum)
      );
  }, [importedBlocks]);
  
  const autoAssignMutation = trpc.hos.autoAssign.useMutation({
    onSuccess: (generatedShifts) => {
      toast.success(`Auto-assigned ${generatedShifts.length} shifts!`);
      // Add generated shifts to schedule data
      generatedShifts.forEach((shift: any) => {
        const date = new Date(shift.startTime);
        const day = DAYS_OF_WEEK[date.getDay()];
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const timeSlot = `${hours}:${minutes}`;
        const key = `${day}_${timeSlot}`;
        
        setScheduleData(prev => ({
          ...prev,
          [key]: drivers?.find(d => d.id === shift.driverId)
        }));
      });
    },
    onError: (error) => {
      toast.error(`Auto-assignment failed: ${error.message}`);
    },
  });

  const sendNotificationMutation = trpc.notifications.send.useMutation({
    onSuccess: () => {
      toast.success("Driver notified!");
    },
  });

  const autoBuildMutation = trpc.autoScheduler.buildWeekly.useMutation({
    onSuccess: (result) => {
      toast.success(`Auto-built schedule with ${result.schedule.length} assignments!`);
      
      // Populate schedule data
      const newScheduleData: Record<string, any> = {};
      result.schedule.forEach(slot => {
        const key = `${slot.day}_${slot.timeSlot}`;
        const driver = drivers?.find(d => d.id === slot.driverId);
        if (driver) {
          newScheduleData[key] = driver;
        }
      });
      setScheduleData(newScheduleData);
      
      // Show warnings if any
      if (result.warnings.length > 0) {
        result.warnings.forEach(warning => toast.warning(warning));
      }
      
      // Show violations if any
      if (result.violations.length > 0) {
        toast.error(`${result.violations.length} HOS violations detected!`);
      }
    },
    onError: (error) => {
      toast.error(`Auto-build failed: ${error.message}`);
    },
  });

  const publishScheduleMutation = trpc.notifications.publishSchedule.useMutation({
    onSuccess: (result) => {
      toast.success(`Schedule published! ${result.notified} drivers notified.`);
    },
  });

  const clearScheduleMutation = trpc.schedules.clearAll.useMutation({
    onSuccess: () => {
      setScheduleData({});
      toast.success("Schedule cleared successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to clear schedule: ${error.message}`);
    },
  });

  const createScheduleMutation = trpc.schedules.create.useMutation({
    onSuccess: () => {
      toast.success("Schedule created successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to create schedule: ${error.message}`);
    },
  });

  const getWeekDates = () => {
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(currentWeekStart.getTime()); // Use getTime() to avoid mutation
      date.setDate(date.getDate() + i); // Increment from the copied date, not currentWeekStart
      dates.push(date);
    }
    return dates;
  };

  const weekDates = getWeekDates();

  const handlePreviousWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentWeekStart(newDate);
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentWeekStart(newDate);
  };

  const handleDragStart = (event: DragStartEvent) => {
    const driver = drivers?.find(d => d.id.toString() === event.active.id);
    setActiveDriver(driver);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over) {
      setActiveDriver(null);
      return;
    }

    const driver = drivers?.find(d => d.id.toString() === active.id);
    const parts = (over.id as string).split('_');
    const day = parts[0];
    const timeSlot = parts[1];
    const contractType = parts[2];
    
    if (!driver) {
      setActiveDriver(null);
      return;
    }

    // Validate driver type matches contract type (allow "Both" and null in any slot)
    const effectiveDriverType = driver.driverType || "Both"; // Treat null as "Both"
    if (effectiveDriverType !== contractType && effectiveDriverType !== "Both") {
      toast.error(`Driver type ${effectiveDriverType} doesn't match slot type ${contractType}`);
      setActiveDriver(null);
      return;
    }

    // Validate 10-hour break rule
    const dayIndex = DAYS_OF_WEEK.indexOf(day);
    const weekDate = weekDates[dayIndex];
    const [hours, minutes] = timeSlot.split(':').map(Number);
    const newShiftStart = new Date(weekDate);
    newShiftStart.setHours(hours, minutes, 0, 0);
    
    // Convert existing schedule data to shifts format for validation
    const existingShifts = Object.entries(scheduleData)
      .filter(([_, assignedDriver]) => assignedDriver) // Only include assigned slots
      .map(([key, assignedDriver]) => {
        const [shiftDay, shiftTime, shiftContract] = key.split('_');
        const dayIdx = DAYS_OF_WEEK.indexOf(shiftDay);
        const date = weekDates[dayIdx];
        const [h, m] = shiftTime.split(':').map(Number);
        const startTime = new Date(date);
        startTime.setHours(h, m, 0, 0);
        const endTime = calculateShiftEndTime(startTime, shiftContract as "Solo1" | "Solo2");
        
        return {
          driverId: assignedDriver.id,
          startTime,
          endTime,
          blockType: shiftContract as "Solo1" | "Solo2"
        };
      });
    
    const validation = validate10HourBreak(
      driver.id,
      newShiftStart,
      contractType as "Solo1" | "Solo2",
      existingShifts
    );
    
    if (!validation.valid) {
      toast.error(validation.message || "10-hour break rule violated", {
        duration: 5000,
        description: "Driver must have at least 10 hours rest between shifts"
      });
      setActiveDriver(null);
      return;
    }

    // Check if slot already has a driver assigned
    const key = `${day}_${timeSlot}_${contractType}`;
    const existingAssignment = scheduleData[key];
    
    // Function to perform the assignment
    const performAssignment = () => {
      setScheduleData(prev => {
        const updated = {
          ...prev,
          [key]: driver
        };
        
        // Auto-populate based on driver type
        if (driver.driverType === "Solo1" || driver.driverType === "Solo2") {
          const matchingSlots = Object.keys(updated).filter(k => {
            const [d, t, c] = k.split('_');
            return d === day && t === timeSlot && c === driver.driverType && !updated[k];
          });
          
          matchingSlots.forEach(slotKey => {
            updated[slotKey] = driver;
          });
        }
        
        return updated;
      });
      
      toast.success(`Assigned ${driver.name} to ${day} ${timeSlot}`);
      setActiveDriver(null);
    };
    
    if (existingAssignment) {
      setConfirmDialog({
        open: true,
        existingDriver: existingAssignment.name,
        newDriver: driver.name,
        onConfirm: performAssignment
      });
      setActiveDriver(null);
      return;
    }

    // No existing assignment, proceed directly
    performAssignment();
    
    // Send auto-assign mutation and notifications
    if (driver.driverType === "Solo1" || driver.driverType === "Solo2") {
      // Call auto-assign mutation (existingShifts already created above for validation)
      autoAssignMutation.mutate({
        driverId: driver.id,
        driverType: driver.driverType as "Solo1" | "Solo2" | "PartTime",
        startDate: weekDate,
        startTime: timeSlot,
        existingShifts
      });

      // Send notification to driver
      const shiftEndTime = new Date(weekDate);
      const [hours, minutes] = timeSlot.split(':').map(Number);
      shiftEndTime.setHours(hours + (driver.driverType === "Solo1" ? 14 : 38), minutes, 0, 0);

      sendNotificationMutation.mutate({
        driverId: driver.id,
        type: "shift_assigned",
        shiftDetails: {
          startTime: weekDate,
          endTime: shiftEndTime,
          location: "MKC",
          tractorNumber: undefined
        }
      });
    } else {
      // For part-time or manual assignment, just send notification
      const shiftEndTime = new Date(weekDate);
      const [hours2, minutes2] = timeSlot.split(':').map(Number);
      shiftEndTime.setHours(hours2 + 8, minutes2, 0, 0); // Default 8-hour shift

      sendNotificationMutation.mutate({
        driverId: driver.id,
        type: "shift_assigned",
        shiftDetails: {
          startTime: weekDate,
          endTime: shiftEndTime,
          location: "MKC",
          tractorNumber: undefined
        }
      });
    }

    setActiveDriver(null);
  };

  const handleDragCancel = () => {
    setActiveDriver(null);
  };

  const activeDrivers = drivers?.filter(d => d.status === "active") || [];
  // Show all active drivers in sidebar (allow assigning same driver to multiple slots)
  const availableDrivers = activeDrivers.filter(driver => 
    driver.name.toLowerCase().includes(driverSearch.toLowerCase())
  );

  const [aiCommand, setAiCommand] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [conversationHistory, setConversationHistory] = useState<Array<{role: string, content: string}>>([]);

  const handleAiCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiCommand.trim()) return;

    try {
      const result = await aiCommandMutation.mutateAsync({
        command: aiCommand,
        conversationHistory, // Pass conversation history for context
        context: {
          weekStart: currentWeekStart.toISOString(),
          driverCount: drivers?.length || 0,
          driverNames: drivers?.map(d => d.name) || [],
          scheduleSlotCount: schedules?.length || 0,
          startTimeCount: 0,
          drivers: drivers || [],
          tractors: [],
          schedules: schedules || [],
        },
      });
      
      // Update conversation history
      setConversationHistory(prev => [
        ...prev,
        { role: 'user', content: aiCommand },
        { role: 'assistant', content: result.response }
      ]);
      
      setAiResponse(result.response);
      setAiCommand('');
    } catch (error) {
      console.error('AI command error:', error);
      setAiResponse("Sorry, I encountered an error. Please try again.");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Milo AI Assistant */}
        <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50/50 to-blue-50/50">
          <CardContent className="pt-6">
            <form onSubmit={handleAiCommand} className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  <img 
                    src="/milo-logo.png" 
                    alt="Milo" 
                    className="w-12 h-12 opacity-80"
                  />
                </div>
                {conversationHistory.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setConversationHistory([]);
                      setAiResponse('');
                    }}
                    className="text-xs text-slate-500 hover:text-slate-700 underline"
                  >
                    Clear chat
                  </button>
                )}
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={aiCommand}
                    onChange={(e) => setAiCommand(e.target.value)}
                    placeholder="Ask Milo anything... (e.g., 'Do I have enough drivers for Solo2 next week?')"
                    className="w-full px-4 py-3 pr-12 rounded-lg border-2 border-purple-300 focus:border-purple-500 focus:outline-none bg-white/80 text-lg placeholder:text-slate-400"
                    disabled={aiCommandMutation.isPending}
                  />
                  <button
                    type="submit"
                    disabled={aiCommandMutation.isPending || !aiCommand.trim()}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
              {/* Conversation History */}
              {conversationHistory.length > 0 && (
                <div className="ml-15 space-y-3 max-h-96 overflow-y-auto">
                  {conversationHistory.map((msg, idx) => (
                    <div key={idx} className={`p-3 rounded-lg border ${
                      msg.role === 'user' 
                        ? 'bg-blue-50/60 border-blue-200 ml-8' 
                        : 'bg-white/60 border-purple-200'
                    }`}>
                      <p className={`text-xs font-semibold mb-1 ${
                        msg.role === 'user' ? 'text-blue-700' : 'text-purple-700'
                      }`}>
                        {msg.role === 'user' ? 'You:' : 'Milo:'}
                      </p>
                      <p className="text-sm text-slate-700 whitespace-pre-wrap">{msg.content}</p>
                    </div>
                  ))}
                </div>
              )}
              {aiCommandMutation.isPending && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm text-slate-500 animate-pulse">Milo is thinking...</p>
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Weekly Schedule</h1>
            <p className="text-muted-foreground mt-2">
              Drag drivers to assign shifts and manage your weekly schedule
            </p>
            {importedBlocks.length > 0 && (() => {
              // Calculate work week display from weekStartDate (always Sunday)
              if (importedBlocks.length > 0) {
                const weekStartDate = new Date(importedBlocks[0].weekStartDate + 'T00:00:00');
                const weekEndDate = new Date(weekStartDate);
                weekEndDate.setDate(weekStartDate.getDate() + 6); // Saturday is 6 days after Sunday
                
                const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                const startMonth = monthNames[weekStartDate.getMonth()];
                const endMonth = monthNames[weekEndDate.getMonth()];
                const startDay = weekStartDate.getDate();
                const endDay = weekEndDate.getDate();
                
                // Calculate unassigned blocks (blocks without drivers)
  // Count unassigned start times (rows without any driver assigned)
  const unassignedCount = calendarRows.filter(row => {
    // Check if any day in this week has an assigned driver for this start time
    const hasAssignment = DAYS_OF_WEEK.some(day => {
      const key = `${day}_${row.startTime}_${row.contractType}`;
      return scheduleData[key];
    });
    return !hasAssignment;
  }).length;

                return (
                  <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm font-semibold text-blue-900">
                      Work Week: Sunday {startMonth} {startDay} - Saturday {endMonth} {endDay}
                    </p>
                    <div className="mt-1">
                      <span className={`text-sm font-medium ${
                        unassignedCount === 0 ? 'text-green-600' : 
                        unassignedCount < 10 ? 'text-yellow-600' : 
                        'text-orange-600'
                      }`}>
                        {unassignedCount} unassigned blocks
                      </span>
                    </div>
                  </div>
                );
              }
              return null;
            })()}
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => {
                autoBuildMutation.mutate({ weekStartDate: weekDates[0] });
              }}
              disabled={autoBuildMutation.isPending}
              variant="default"
            >
              {autoBuildMutation.isPending ? "Building..." : "Auto-Build Schedule"}
            </Button>
            <div>
              <input
                id="csv-upload"
                type="file"
                accept=".csv,.xls,.xlsx"
                onChange={handleFileUpload}
                className="hidden"
                disabled={importBlocksMutation.isPending}
              />
              <Button
                variant="outline"
                className="border-green-500 text-green-600 hover:bg-green-50"
                onClick={() => document.getElementById('csv-upload')?.click()}
                disabled={importBlocksMutation.isPending}
              >
                <Plus className="h-4 w-4 mr-2" />
                {importBlocksMutation.isPending ? "Importing..." : "Import CSV"}
              </Button>
            </div>
            <Button
              onClick={() => {
                const driverIds = drivers?.map(d => d.id) || [];
                publishScheduleMutation.mutate({
                  driverIds,
                  weekStartDate: weekDates[0]
                });
              }}
              variant="outline"
            >
              Publish & Notify All
            </Button>

          </div>
        </div>

        {/* View Toggle & Week Navigator */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              {importedBlocks.length > 0 && (
                <div className="flex gap-2">
                  <Button
                    variant={viewMode === "table" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("table")}
                  >
                    Table View
                  </Button>
                  <Button
                    variant={viewMode === "calendar" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("calendar")}
                  >
                    Calendar View
                  </Button>
                </div>
              )}
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">
                  {(() => {
                    // Calculate US standard week number (Sunday-Saturday)
                    const year = currentWeekStart.getFullYear();
                    const oneJan = new Date(year, 0, 1);
                    
                    // Adjust to Sunday of the first week
                    const firstSunday = new Date(oneJan);
                    const dayOfWeek = oneJan.getDay();
                    if (dayOfWeek !== 0) {
                      firstSunday.setDate(oneJan.getDate() + (7 - dayOfWeek));
                    }
                    
                    // Calculate days from first Sunday to current week start
                    const daysSinceFirstSunday = Math.floor((currentWeekStart.getTime() - firstSunday.getTime()) / (24 * 60 * 60 * 1000));
                    const weekNumber = Math.floor(daysSinceFirstSunday / 7) + 1;
                    
                    return `week ${weekNumber}`;
                  })()}
                </span>
              </div>
              <div className="flex-1" />
              <Button variant="outline" size="sm" onClick={handlePreviousWeek}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <span className="font-semibold">
                  {(() => {
                    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    const startMonth = monthNames[currentWeekStart.getMonth()];
                    const endMonth = monthNames[weekDates[6].getMonth()];
                    const startDay = currentWeekStart.getDate();
                    const endDay = weekDates[6].getDate();
                    const year = currentWeekStart.getFullYear();
                    return `${startMonth} ${startDay} - ${endMonth} ${endDay}, ${year}`;
                  })()}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={handleNextWeek}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Table View */}
        {viewMode === "table" && importedBlocks.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Imported Blocks</CardTitle>
              <CardDescription>
                {importedBlocks.length} blocks imported - assign drivers below
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BlocksTableView
                blocks={importedBlocks}
                drivers={drivers || []}
                onAssignDriver={(blockId, driverId) => {
                  // TODO: Update block assignment
                  toast.success("Driver assigned!");
                }}
              />
            </CardContent>
          </Card>
        )}



        {/* Calendar View */}
        {viewMode === "calendar" && (
          <DndContext
            sensors={sensors}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            onDragCancel={handleDragCancel}
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Available Drivers Sidebar */}
            <Card className="lg:col-span-3 bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
              <CardHeader>
                <CardTitle>Available Drivers</CardTitle>
                <CardDescription>
                  {availableDrivers.length} drivers ready to assign
                </CardDescription>
                {/* Search Input */}
                <div className="mt-3">
                  <input
                    type="text"
                    placeholder="Search drivers..."
                    value={driverSearch}
                    onChange={(e) => setDriverSearch(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-purple-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 bg-white/80 backdrop-blur-sm"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-1.5 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                  {availableDrivers.map((driver) => (
                    <DriverCard key={driver.id} driver={driver} />
                  ))}
                  {availableDrivers.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      {driverSearch ? 'No drivers found' : 'All drivers assigned'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

          {/* Schedule Grid */}
          <Card className="lg:col-span-9 border-purple-100 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCalendarExpanded(!calendarExpanded)}
                    className="font-medium"
                  >
                    {calendarExpanded ? '▼' : '▶'} Calendar
                  </Button>
                  {calendarExpanded && (
                    <div>
                      <CardTitle>Weekly Schedule Grid</CardTitle>
                      <CardDescription>
                        Drag drivers from the sidebar to assign shifts
                      </CardDescription>
                    </div>
                  )}
                </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <Button
                onClick={() => {
                  // TODO: Implement AI auto-fill logic
                  toast.info("Auto-Fill coming soon!");
                }}
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              >
                <span className="mr-2">✨</span>
                Auto-Fill
              </Button>
              <Button
                onClick={() => {
                  // TODO: Implement copy last week logic
                  toast.info("Copy Last Week coming soon!");
                }}
                variant="outline"
                className="border-purple-300 hover:bg-purple-50"
              >
                <span className="mr-2">📋</span>
                Copy Last Week
              </Button>
              <Button
                onClick={() => setImportDialogOpen(true)}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Import Blocks
              </Button>
              <Button
                onClick={() => {
                  if (confirm("Are you sure you want to clear all schedule assignments? This cannot be undone.")) {
                    clearScheduleMutation.mutate();
                  }
                }}
                variant="outline"
                className="border-red-300 hover:bg-red-50 text-red-600"
                disabled={clearScheduleMutation.isPending}
              >
                {clearScheduleMutation.isPending ? "Clearing..." : "Clear Schedule"}
              </Button>
            </div>
              </div>
            </CardHeader>
            {calendarExpanded && (
            <CardContent>
              <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-300px)] scrollbar-visible" style={{ scrollbarWidth: 'auto', scrollbarColor: '#9333ea #f3e8ff' }}>
                <div className="min-w-[800px]">
                  {/* Header Row */}
                  <div className="grid grid-cols-8 gap-2 mb-3 pb-2 border-b-2 border-purple-100">
                    <div className="font-semibold text-sm text-purple-700 flex items-center">Time</div>
                    {weekDates.map((date, i) => (
                      <div key={i} className="text-center bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg py-2 px-1">
                        <div className="font-semibold text-sm text-purple-700">{DAYS_OF_WEEK[i]}</div>
                        <div className="text-xs text-purple-500 font-medium">
                          {date.getMonth() + 1}/{date.getDate()}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Time Slot Rows - Loaded from configured start times */}
                  <div className="space-y-2">
                    {calendarRows && calendarRows.length > 0 ? (
                      // Render one row per configured start time (17 permanent rows)
                      calendarRows.map((row) => {
                          const { key: groupKey, startTime: timeSlot, contractType, tractorNum } = row;
                          
                          return (
                            <div key={groupKey} className="grid grid-cols-8 gap-2 py-1">
                              <div className="flex flex-col justify-center text-sm bg-gradient-to-r from-purple-100 to-transparent rounded-l-lg pl-3 py-2">
                                <div className="font-bold text-purple-700">{timeSlot}</div>
                                <div className="text-xs font-medium">
                                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                                    contractType === 'Solo1' 
                                      ? 'bg-emerald-100 text-emerald-700'
                                      : 'bg-amber-100 text-amber-700'
                                  }`}>{contractType}</span>
                                </div>
                              </div>
                              {weekDates.map((date, dayIndex) => {
                                const slotKey = `${DAYS_OF_WEEK[dayIndex]}_${timeSlot}_${contractType}_${tractorNum}`;
                                let assignedDriver = scheduleData[slotKey];
                                
                                // Find ALL matching imported blocks for this start time, tractor, and day of week
                                const matchingBlocks = importedBlocks.filter(block => {
                                  const blockTractorMatch = block.truckFilter?.match(/Tractor_(\d+)/);
                                  const blockTractorNum = blockTractorMatch ? blockTractorMatch[1] : 'Unknown';
                                  
                                  // Match by day of week (0=Sunday, 1=Monday, ..., 6=Saturday)
                                  // IMPORTANT: Parse date in UTC to avoid timezone shifts
                                  const blockDateStr = block.startDate.split('T')[0]; // Get YYYY-MM-DD part
                                  const [year, month, day] = blockDateStr.split('-').map(Number);
                                  const blockDate = new Date(Date.UTC(year, month - 1, day));
                                  const blockDayOfWeek = blockDate.getUTCDay();
                                  const calendarDayOfWeek = date.getDay();
                                  
                                  return block.startTime === timeSlot &&
                                    block.contractType === contractType &&
                                    blockTractorNum === tractorNum &&
                                    blockDayOfWeek === calendarDayOfWeek;
                                });
                                
                                // For Solo2, also check if previous day has a Solo2 driver assigned
                                // (Solo2 spans 2 days, so driver should appear on both days)
                                if (!assignedDriver && contractType === 'Solo2' && dayIndex > 0) {
                                  const prevDayKey = `${DAYS_OF_WEEK[dayIndex - 1]}_${timeSlot}_${contractType}_${tractorNum}`;
                                  const prevDayDriver = scheduleData[prevDayKey];
                                  if (prevDayDriver) {
                                    assignedDriver = prevDayDriver; // Show same driver on day 2
                                  }
                                }
                                
                                return (
                                  <TimeSlot
                                    key={slotKey}
                                    id={slotKey}
                                    driver={assignedDriver}
                                    blocks={matchingBlocks}
                                    onRemove={() => {
                                      setScheduleData(prev => {
                                        const newData = { ...prev };
                                        delete newData[slotKey];
                                        // For Solo2, also remove from next day if it exists
                                        if (contractType === 'Solo2' && dayIndex < 6) {
                                          const nextDayKey = `${DAYS_OF_WEEK[dayIndex + 1]}_${timeSlot}_${contractType}_${tractorNum}`;
                                          delete newData[nextDayKey];
                                        }
                                        return newData;
                                      });
                                    }}
                                  />
                                );
                              })}
                            </div>
                          );
                        })
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        No start times configured. Please import start times first.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
            )}
          </Card>
          </div>
          <DragOverlay>
            {activeDriver && (
              <div className="bg-primary text-primary-foreground p-3 rounded-lg shadow-lg">
                <p className="font-medium">{activeDriver.name}</p>
                <p className="text-xs opacity-90">{activeDriver.driverType || "Driver"}</p>
              </div>
            )}
          </DragOverlay>
        </DndContext>
        )}
      
      {/* Confirmation Dialog */}
      <Dialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog(prev => ({ ...prev, open }))}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Replace Driver?</DialogTitle>
            <DialogDescription>
              This slot is already assigned to <strong>{confirmDialog.existingDriver}</strong>.
              <br /><br />
              Do you want to replace them with <strong>{confirmDialog.newDriver}</strong>?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setConfirmDialog(prev => ({ ...prev, open: false }))}
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                confirmDialog.onConfirm();
                setConfirmDialog(prev => ({ ...prev, open: false }));
              }}
            >
              Replace
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* CSV Import Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Import Weekly Shifts</DialogTitle>
            <DialogDescription>
              Upload or paste your weekly shift schedule. The AI will auto-assign team members based on last week's schedule and your custom instructions.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium mb-2">Upload CSV File</label>
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  e.currentTarget.classList.add('border-purple-500', 'bg-purple-50');
                }}
                onDragLeave={(e) => {
                  e.currentTarget.classList.remove('border-purple-500', 'bg-purple-50');
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.currentTarget.classList.remove('border-purple-500', 'bg-purple-50');
                  const file = e.dataTransfer.files?.[0];
                  if (file && file.name.endsWith('.csv')) {
                    setSelectedFile(file);
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      const content = event.target?.result as string;
                      setCsvContent(content);
                    };
                    reader.readAsText(file);
                  }
                }}
                className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-purple-400 transition-colors"
              >
                <input
                  type="file"
                  id="csv-upload"
                  accept=".csv"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setSelectedFile(file);
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const content = event.target?.result as string;
                        setCsvContent(content);
                      };
                      reader.readAsText(file);
                    }
                  }}
                  className="hidden"
                />
                <label htmlFor="csv-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center gap-2">
                    <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <p className="text-sm font-medium text-gray-700">Drag and drop your CSV file here</p>
                    <p className="text-xs text-gray-500">or click to browse</p>
                  </div>
                </label>              </div>
            </div>

            {/* Selected File Preview */}
            {selectedFile && (
              <div className="border rounded-lg p-4 bg-blue-50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 rounded-full p-2">
                    <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium text-sm">{selectedFile.name}</p>
                    <p className="text-xs text-gray-500">{(selectedFile.size / 1024).toFixed(1)} KB</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedFile(null);
                    setCsvContent("");
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            )}

            {/* Parsed Blocks Preview */}
            {parsedBlocks.length > 0 && (
              <div className="border rounded-lg p-4 bg-green-50">
                <h4 className="font-semibold text-green-800 mb-2">✓ {parsedBlocks.length} Blocks Found</h4>
                <div className="max-h-60 overflow-y-auto space-y-2">
                  {parsedBlocks.slice(0, 10).map((block, i) => (
                    <div key={i} className="text-sm bg-white p-2 rounded border">
                      <span className="font-mono text-purple-600">{block.startTime}</span>
                      {" • "}
                      <span className="font-semibold">{block.contractType}</span>
                      {" • "}
                      <span className="text-gray-600">{block.domicile}</span>
                      {block.suggestedDriver && (
                        <span className="ml-2 text-blue-600">→ {block.suggestedDriver}</span>
                      )}
                    </div>
                  ))}
                  {parsedBlocks.length > 10 && (
                    <p className="text-xs text-gray-500 text-center">+ {parsedBlocks.length - 10} more blocks...</p>
                  )}
                </div>
              </div>
            )}
            {parseErrors.length > 0 && (
              <div className="border rounded-lg p-4 bg-red-50">
                <h4 className="font-semibold text-red-800 mb-2">⚠ {parseErrors.length} Errors</h4>
                <ul className="text-sm text-red-700 space-y-1">
                  {parseErrors.map((error, i) => (
                    <li key={i}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="border-t pt-4">
              <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-purple-600" />
                AI Instructions (Optional)
              </label>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder='Give the AI custom instructions for scheduling...\n\nExamples:\n• "Keep Firas under 4 days"\n• "Prioritize Solo1 drivers"\n• "Balance workload evenly"\n• "Avoid back-to-back shifts for John"'
                className="w-full h-32 p-3 border rounded-md text-sm bg-purple-50/30 focus:bg-white transition-colors"
              />
              <p className="text-xs text-muted-foreground mt-2">
                The AI will follow these instructions when auto-building the schedule
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (!selectedFile || !csvContent) {
                  toast.error("Please select a CSV file to import");
                  return;
                }
                
                // Import the CSV
                importBlocksMutation.mutate({ csvContent });
              }}
              disabled={!selectedFile || importBlocksMutation.isPending}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {importBlocksMutation.isPending ? "Importing..." : "Import Blocks"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Warnings Dialog */}
      <Dialog open={warningsDialogOpen} onOpenChange={setWarningsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Auto-Build Warnings ({buildWarnings.length})</DialogTitle>
            <DialogDescription>
              The following issues were encountered during auto-build:
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-4">
            {buildWarnings.map((warning, index) => (
              <div key={index} className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg text-sm">
                {warning}
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button onClick={() => setWarningsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* AI Scheduling Chat */}
      <AISchedulingChat
        isOpen={aiChatOpen}
        onClose={() => setAiChatOpen(false)}
        onCommand={async (command) => {
          try {
            const result = await aiCommandMutation.mutateAsync({
              command,
              context: {
                weekStart: currentWeekStart.toISOString(),
                driverCount: (drivers || []).length,
                driverNames: (drivers || []).map(d => d.name),
                scheduleSlotCount: Object.keys(scheduleData).length,
                startTimeCount: 0,
                userId: user?.id,
                drivers: drivers || [],
                scheduleData,
                startTimes: [],
              },
            });
            return result.response;
          } catch (error) {
            console.error('AI command error:', error);
            return 'Sorry, I encountered an error processing your request. Please try again.';
          }
        }}
      />
      </div>
    </DashboardLayout>
  );
}

// Driver Card Component (Draggable)
function DriverCard({ driver }: { driver: any }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: driver.id.toString(),
    data: { driver },
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={`relative overflow-hidden bg-gradient-to-br from-purple-400/85 via-purple-500/85 to-blue-500/85 rounded-lg p-1.5 cursor-move hover:shadow-xl hover:scale-[1.03] transition-all duration-200 shadow-md ${
        isDragging ? 'opacity-50 scale-95' : ''
      }`}
    >
      {/* 3D Depth layers */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-black/10"></div>
      <div className="absolute inset-0 bg-white/15 backdrop-blur-md"></div>
      
      {/* Inner shadow for depth */}
      <div className="absolute inset-0 shadow-[inset_0_2px_8px_rgba(255,255,255,0.3),inset_0_-2px_8px_rgba(0,0,0,0.2)] rounded-lg"></div>
      
      {/* Content */}
      <div className="relative z-10">
        <p className="font-bold text-[11px] text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)] truncate">{driver.name}</p>
        <div className="flex items-center justify-between mt-0.5">
          <span className="text-[10px] text-white/95 font-medium drop-shadow-sm">
            {driver.driverType || "Driver"}
          </span>
          {driver.preferredStartTime && (
            <span className="text-[9px] bg-white/25 backdrop-blur-sm text-white px-1.5 py-0.5 rounded-full font-semibold shadow-sm">
              {driver.preferredStartTime}
            </span>
          )}
        </div>
      </div>
      
      {/* Shine effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none"></div>
      
      {/* Edge highlight */}
      <div className="absolute inset-0 rounded-lg border border-white/20"></div>
    </div>
  );
}

// Time Slot Component (Drop Zone)
function TimeSlot({ id, driver, blocks, onRemove }: { id: string; driver?: any; blocks?: any[]; onRemove: () => void }) {
  const { setNodeRef, isOver } = useDroppable({
    id: id,
  });

  return (
    <div
      ref={setNodeRef}
      className={`min-h-[50px] rounded-lg flex items-center justify-center transition-all duration-200 relative overflow-hidden ${
        isOver 
          ? "bg-purple-100 shadow-lg scale-[1.05] ring-2 ring-purple-400 ring-offset-2" 
          : driver 
            ? "border-2 border-solid border-blue-400 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-md" 
            : blocks && blocks.length > 0
              ? "bg-gradient-to-br from-yellow-100/90 via-orange-100/80 to-red-100/70 shadow-lg hover:shadow-xl backdrop-blur-sm"
              : "bg-gradient-to-br from-purple-50/40 via-blue-50/30 to-indigo-50/40 hover:from-purple-100/50 hover:via-blue-100/40 hover:to-indigo-100/50 shadow-sm hover:shadow-md"
      }`}
    >
      {driver ? (
        <div className="text-center p-2 relative group w-full">
          <p className="text-xs font-semibold text-gray-800 truncate">{driver.name}</p>
          <p className="text-xs text-blue-600 font-medium mt-0.5">{driver.driverType}</p>
          <button
            onClick={onRemove}
            className="absolute top-0.5 right-0.5 opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:bg-red-100 rounded-full w-5 h-5 flex items-center justify-center text-sm font-bold"
          >
            ×
          </button>
        </div>
      ) : blocks && blocks.length > 0 ? (
        <div className="flex flex-col gap-1 p-1.5 w-full relative z-10">
          {blocks.map((block, idx) => (
            <div key={block.id || idx} className="text-center">
              <p className="text-[11px] font-bold text-orange-800 drop-shadow-sm">{block.blockId}</p>
              <p className="text-[9px] text-red-700 mt-0.5 font-medium">{block.origin} → {block.destination}</p>
            </div>
          ))}
          {/* 3D depth layers */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/30 to-transparent pointer-events-none rounded-lg"></div>
          <div className="absolute inset-0 shadow-inner pointer-events-none rounded-lg"></div>
        </div>
      ) : (
        <p className="text-xs text-purple-400/60 font-medium">Drop here</p>
      )}
    </div>
  );
}

