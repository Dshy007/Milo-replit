import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";

export default function Contact() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />

      {/* Waitlist Section */}
      <section className="pt-32 pb-20 bg-secondary text-secondary-foreground">
        <div className="container max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6 font-serif">Join the waitlist</h1>
              <p className="text-lg mb-4">
                For general questions or inquiries, email us at <strong>info@manus.com</strong>
              </p>
              <p className="text-sm text-secondary-foreground/70 mb-2">*Must currently be an active AFP.</p>
              <p className="text-sm text-secondary-foreground/70">
                **Due to current demand, Milo is onboarding based on a waitlist. Expected onboarding timelines will be communicated and is subject to change.
              </p>
            </div>

            <Card className="p-6 bg-white">
              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Name*</Label>
                    <Input id="name" placeholder="Full name" required />
                  </div>
                  <div>
                    <Label htmlFor="email">Email*</Label>
                    <Input id="email" type="email" placeholder="jane@example.com" required />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Phone*</Label>
                    <Input id="phone" type="tel" placeholder="(123) 456 7890" required />
                  </div>
                  <div>
                    <Label htmlFor="company">Company</Label>
                    <Input id="company" placeholder="Company" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="domicile">Domicile*</Label>
                    <Input id="domicile" placeholder="Domicile" required />
                  </div>
                  <div>
                    <Label htmlFor="contract">Contract Type(s)*</Label>
                    <Select required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="solo2">Solo 2 Only</SelectItem>
                        <SelectItem value="both">Solo 1 and Solo 2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="scac">SCAC Code*</Label>
                    <Input id="scac" placeholder="SCAC Code" required />
                  </div>
                  <div>
                    <Label htmlFor="yard">Home Yard Code*</Label>
                    <Input id="yard" placeholder="Home Yard Code" required />
                  </div>
                </div>
                <Button type="submit" className="w-full rounded-full" size="lg">
                  Submit
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* General Inquiry Section */}
      <section className="py-20 bg-white">
        <div className="container max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-4xl font-bold mb-6 font-serif">General Inquiry</h2>
              <p className="text-lg text-muted-foreground">
                Get in touch with our team for any additional inquiries. Note: Onboarding submissions will not be considered through this form.
              </p>
            </div>

            <Card className="p-6 border-2">
              <form className="space-y-4">
                <div>
                  <Label htmlFor="inquiry-name">Name</Label>
                  <Input id="inquiry-name" placeholder="Enter your name" />
                </div>
                <div>
                  <Label htmlFor="inquiry-email">Email</Label>
                  <Input id="inquiry-email" type="email" placeholder="Enter your email" />
                </div>
                <div>
                  <Label htmlFor="inquiry-message">Message</Label>
                  <Textarea id="inquiry-message" placeholder="Enter your message" rows={6} />
                </div>
                <Button type="submit" className="w-full rounded-full" size="lg">
                  Send Message
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

