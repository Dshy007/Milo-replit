import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Plus, Pencil, Trash2, Upload, Send } from "lucide-react";
import Papa from "papaparse";
import { useState } from "react";
import { toast } from "sonner";

export default function Tractors() {
  const { user } = useAuth();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [editingTractor, setEditingTractor] = useState<any>(null);
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [aiCommand, setAiCommand] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  
  const aiCommandMutation = trpc.ai.processCommand.useMutation();
  const [formData, setFormData] = useState({
    tractorNumber: "",
    make: "",
    model: "",
    year: "",
    vin: "",
    licensePlate: "",
    status: "active" as "active" | "maintenance" | "out_of_service",
  });

  const utils = trpc.useUtils();
  const { data: tractors, isLoading } = trpc.tractors.list.useQuery();
  
  // Sort handler
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };
  
  // Sorted tractors
  const sortedTractors = tractors ? [...tractors].sort((a: any, b: any) => {
    if (!sortColumn) return 0;
    
    const aVal = a[sortColumn];
    const bVal = b[sortColumn];
    
    if (aVal === null || aVal === undefined) return 1;
    if (bVal === null || bVal === undefined) return -1;
    
    if (typeof aVal === 'string') {
      return sortDirection === 'asc' 
        ? aVal.localeCompare(bVal)
        : bVal.localeCompare(aVal);
    }
    
    return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
  }) : [];
  
  const createMutation = trpc.tractors.create.useMutation({
    onSuccess: () => {
      utils.tractors.list.invalidate();
      setIsAddOpen(false);
      resetForm();
      toast.success("Tractor added successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to add tractor: ${error.message}`);
    },
  });

  const updateMutation = trpc.tractors.update.useMutation({
    onSuccess: () => {
      utils.tractors.list.invalidate();
      setEditingTractor(null);
      resetForm();
      toast.success("Tractor updated successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to update tractor: ${error.message}`);
    },
  });

  const deleteMutation = trpc.tractors.delete.useMutation({
    onSuccess: () => {
      utils.tractors.list.invalidate();
      toast.success("Tractor deleted successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to delete tractor: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      tractorNumber: "",
      make: "",
      model: "",
      year: "",
      vin: "",
      licensePlate: "",
      status: "active",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const data = {
      ...formData,
      year: formData.year ? parseInt(formData.year) : undefined,
    };
    
    if (editingTractor) {
      updateMutation.mutate({
        id: editingTractor.id,
        ...data,
      });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (tractor: any) => {
    setEditingTractor(tractor);
    setFormData({
      tractorNumber: tractor.tractorNumber,
      make: tractor.make || "",
      model: tractor.model || "",
      year: tractor.year?.toString() || "",
      vin: tractor.vin || "",
      licensePlate: tractor.licensePlate || "",
      status: tractor.status,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this tractor?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleImport = async () => {
    console.log('Starting import...');
    setIsImporting(true);
    try {
      const data: any[] = [];

      if (csvFile) {
        console.log('Parsing CSV file:', csvFile.name);
        // Parse CSV file
        Papa.parse(csvFile, {
          header: true,
          complete: async (results: any) => {
            console.log('CSV parsed, rows:', results.data.length);
            const transformedData = results.data
              .map((row: any) => ({
                tractorNumber: row['Asset ID'] || row.assetId || row.tractorNumber,
                make: row['Make'] || row.make,
                model: row['Type'] || row.type || row.model,
                vin: row['VIN'] || row.vin,
                licensePlate: row['License'] || row.license || row.licensePlate,
                status: (row['Status']?.toLowerCase() === 'active' ? 'active' : 'maintenance') as "active" | "maintenance" | "out_of_service",
              }))
              .filter((row: any) => row.tractorNumber);

            console.log('Transformed data:', transformedData);
            try {
              for (const tractor of transformedData) {
                console.log('Creating tractor:', tractor);
                await createMutation.mutateAsync(tractor);
              }
              toast.success(`Imported ${transformedData.length} tractors`);
              utils.tractors.list.invalidate();
              setIsImportOpen(false);
              setCsvFile(null);
              setIsImporting(false);
            } catch (err: any) {
              console.error('Import error:', err);
              toast.error(`Import failed: ${err.message}`);
              setIsImporting(false);
            }
          },
          error: (error: any) => {
            toast.error(`Failed to parse CSV: ${error.message}`);
            setIsImporting(false);
          }
        });
      } else if (importText.trim()) {
        console.log('Parsing pasted text, lines:', importText.split('\n').length);
        // Parse pasted text (vertical format)
        const lines = importText.trim().split('\n').filter(line => line.trim());
        console.log('Filtered lines:', lines.length);
        const hasTabOrComma = /[,\t]/.test(lines[0]);

        // Amazon Relay format with blank lines:
        // Line 0: Asset ID
        // Line 1: "Tractor"
        // Line 2: Fleet type ("Fleet" or "Permaloaner")
        // Line 3: Make ("Volvo", "Kenworth", etc.)
        // Line 4: Type ("Day cab", "Sleeper")
        // Line 5: Combined line with tabs: Fuel, License, VIN, Location
        // Line 6: Status
        
        // Group lines into records (7 non-empty lines per tractor)
        const records: string[][] = [];
        let currentRecord: string[] = [];
        
        for (const line of lines) {
          currentRecord.push(line);
          if (currentRecord.length === 7) {
            records.push(currentRecord);
            currentRecord = [];
          }
        }
        
        console.log('Found records:', records.length);
        
        for (const record of records) {
          const [assetId, tractorLabel, fleetType, make, type, combinedLine, status] = record;
          
          // Parse combined line (has tabs): "CNG\t3184420\t4V4NC9UG7NN317748\t39.091005, -94.731402"
          console.log('Combined line:', combinedLine);
          const parts = combinedLine.split('\t').filter(p => p.trim());
          console.log('Split parts:', parts);
          const fuel = parts[0] || ''; // CNG or DIESEL
          const license = parts[1] || '';
          const vin = parts[2] || '';
          console.log('Extracted - Fuel:', fuel, 'License:', license, 'VIN:', vin);
          
          // Extract year from make field if it contains a year (e.g., "2020 Volvo")
          let year: number | undefined;
          const yearMatch = make?.match(/\b(19|20)\d{2}\b/);
          if (yearMatch) {
            year = parseInt(yearMatch[0]);
          }
          
          if (assetId) {
            data.push({
              tractorNumber: assetId,
              make: make?.replace(/\b(19|20)\d{2}\s*/, '').trim() || '', // Remove year from make
              model: type || '',
              year: year,
              fuel: fuel,
              licensePlate: license,
              vin: vin,
              status: status?.toLowerCase() === 'active' ? 'active' : (status?.toLowerCase() === 'unavailable' ? 'out_of_service' : 'maintenance'),
            });
          }
        }

        console.log('Parsed tractors:', data);
        for (const tractor of data) {
          console.log('Creating tractor:', tractor);
          await createMutation.mutateAsync(tractor);
        }
        toast.success(`Imported ${data.length} tractors`);
        utils.tractors.list.invalidate();
        setIsImportOpen(false);
        setImportText("");
        setIsImporting(false);
      } else {
        toast.error("Please provide CSV file or paste data");
        setIsImporting(false);
      }
    } catch (error: any) {
      toast.error(`Import failed: ${error.message}`);
      setIsImporting(false);
    }
  };

  const handleAiCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiCommand.trim()) return;

    try {
      const result = await aiCommandMutation.mutateAsync({
        command: aiCommand,
        context: {
          weekStart: new Date().toISOString(),
          driverCount: 0,
          driverNames: [],
          scheduleSlotCount: 0,
          startTimeCount: 0,
          drivers: [],
          tractors: tractors || [],
          schedules: [],
        },
      });
      setAiResponse(result.response);
      setAiCommand('');
    } catch (error) {
      console.error('AI command error:', error);
      setAiResponse("Sorry, I encountered an error. Please try again.");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Milo AI Assistant */}
        <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50/50 to-blue-50/50">
          <CardContent className="pt-6">
            <form onSubmit={handleAiCommand} className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  <img 
                    src="/milo-logo.png" 
                    alt="Milo" 
                    className="w-12 h-12 opacity-80"
                  />
                </div>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={aiCommand}
                    onChange={(e) => setAiCommand(e.target.value)}
                    placeholder="Ask Milo anything... (e.g., 'Do I have enough drivers for Solo2 next week?')"
                    className="w-full px-4 py-3 pr-12 rounded-lg border-2 border-purple-300 focus:border-purple-500 focus:outline-none bg-white/80 text-lg placeholder:text-slate-400"
                    disabled={aiCommandMutation.isPending}
                  />
                  <button
                    type="submit"
                    disabled={aiCommandMutation.isPending || !aiCommand.trim()}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
              {aiResponse && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm font-semibold text-purple-700 mb-2">Milo:</p>
                  <p className="text-slate-700 whitespace-pre-wrap">{aiResponse}</p>
                </div>
              )}
              {aiCommandMutation.isPending && (
                <div className="ml-15 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <p className="text-sm text-slate-500 animate-pulse">Milo is thinking...</p>
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Fleet Management</h1>
            <p className="text-muted-foreground mt-2">
              Manage your tractor fleet and maintenance
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsImportOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Import Fleet
            </Button>
            <Dialog open={isAddOpen || !!editingTractor} onOpenChange={(open) => {
              setIsAddOpen(open);
              if (!open) {
                setEditingTractor(null);
                resetForm();
              }
            }}>
              <DialogTrigger asChild>
                <Button onClick={() => setIsAddOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Tractor
                </Button>
              </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>{editingTractor ? "Edit Tractor" : "Add New Tractor"}</DialogTitle>
                  <DialogDescription>
                    {editingTractor ? "Update tractor information" : "Add a new tractor to your fleet"}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="tractorNumber">Tractor Number *</Label>
                    <Input
                      id="tractorNumber"
                      value={formData.tractorNumber}
                      onChange={(e) => setFormData({ ...formData, tractorNumber: e.target.value })}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="make">Make</Label>
                      <Input
                        id="make"
                        value={formData.make}
                        onChange={(e) => setFormData({ ...formData, make: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="model">Model</Label>
                      <Input
                        id="model"
                        value={formData.model}
                        onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="year">Year</Label>
                    <Input
                      id="year"
                      type="number"
                      value={formData.year}
                      onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="vin">VIN</Label>
                    <Input
                      id="vin"
                      value={formData.vin}
                      onChange={(e) => setFormData({ ...formData, vin: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="licensePlate">License Plate</Label>
                    <Input
                      id="licensePlate"
                      value={formData.licensePlate}
                      onChange={(e) => setFormData({ ...formData, licensePlate: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value: any) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="out_of_service">Out of Service</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                    {editingTractor ? "Update" : "Add"} Tractor
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          </div>
        </div>

        {/* Tractors Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Tractors</CardTitle>
            <CardDescription>
              {tractors?.length || 0} tractors in your fleet
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-muted-foreground">Loading tractors...</p>
            ) : tractors && tractors.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('tractorNumber')}>
                      Tractor # {sortColumn === 'tractorNumber' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('make')}>
                      Make {sortColumn === 'make' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('model')}>
                      Model {sortColumn === 'model' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('fuel')}>
                      Fuel {sortColumn === 'fuel' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('vin')}>
                      VIN {sortColumn === 'vin' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('licensePlate')}>
                      License {sortColumn === 'licensePlate' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="cursor-pointer" onClick={() => handleSort('status')}>
                      Status {sortColumn === 'status' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedTractors.map((tractor) => (
                    <TableRow key={tractor.id}>
                      <TableCell className="font-medium">{tractor.tractorNumber}</TableCell>
                      <TableCell>{tractor.make || "—"}</TableCell>
                      <TableCell>{tractor.model || "—"}</TableCell>
                      <TableCell>{tractor.fuel || "—"}</TableCell>
                      <TableCell>{tractor.vin || "—"}</TableCell>
                      <TableCell>{tractor.licensePlate || "—"}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          tractor.status === "active" ? "bg-green-100 text-green-800" :
                          tractor.status === "maintenance" ? "bg-yellow-100 text-yellow-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {tractor.status.replace("_", " ")}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(tractor)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(tractor.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">No tractors yet</p>
                <Button onClick={() => setIsAddOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Your First Tractor
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Import Dialog */}
        <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Import Fleet Data</DialogTitle>
              <DialogDescription>
                Upload a CSV file or paste your Amazon Relay fleet data
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="csv-file">CSV File</Label>
                <Input
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                />
              </div>
              <div className="text-center text-sm text-muted-foreground">OR</div>
              <div>
                <Label htmlFor="paste-data">Paste Data</Label>
                <textarea
                  id="paste-data"
                  className="w-full h-32 p-2 border rounded-md font-mono text-sm"
                  placeholder="Paste your Amazon Relay fleet data here..."
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={handleImport}
                disabled={isImporting || (!csvFile && !importText.trim())}
              >
                {isImporting ? "Importing..." : "Import"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}

