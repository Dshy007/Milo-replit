/**
 * Hours of Service (HOS) validation utilities
 * Enforces 10-hour minimum break rule between shifts
 */

export interface Shift {
  driverId: number;
  startTime: Date;
  endTime: Date;
  blockType: "Solo1" | "Solo2";
}

/**
 * Calculate shift end time based on contract type
 * Solo1: 14 hours, Solo2: 38 hours
 */
export function calculateShiftEndTime(startTime: Date, contractType: "Solo1" | "Solo2"): Date {
  const endTime = new Date(startTime);
  const hours = contractType === "Solo1" ? 14 : 38;
  endTime.setHours(endTime.getHours() + hours);
  return endTime;
}

/**
 * Check if 10 hours have passed between two times
 */
export function has10HourBreak(endTime: Date, nextStartTime: Date): boolean {
  const hoursDiff = (nextStartTime.getTime() - endTime.getTime()) / (1000 * 60 * 60);
  return hoursDiff >= 10;
}

/**
 * Find the most recent shift for a driver before a given time
 */
export function findPreviousShift(
  driverId: number,
  beforeTime: Date,
  allShifts: Shift[]
): Shift | null {
  const driverShifts = allShifts
    .filter(shift => shift.driverId === driverId && shift.startTime < beforeTime)
    .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
  
  return driverShifts.length > 0 ? driverShifts[0] : null;
}

/**
 * Validate if a driver can be assigned to a shift without violating 10-hour rule
 */
export function validate10HourBreak(
  driverId: number,
  newShiftStart: Date,
  contractType: "Solo1" | "Solo2",
  existingShifts: Shift[]
): {
  valid: boolean;
  message?: string;
  previousShiftEnd?: Date;
} {
  const previousShift = findPreviousShift(driverId, newShiftStart, existingShifts);
  
  if (!previousShift) {
    return { valid: true };
  }
  
  const hasBreak = has10HourBreak(previousShift.endTime, newShiftStart);
  
  if (!hasBreak) {
    const hoursSinceLastShift = (newShiftStart.getTime() - previousShift.endTime.getTime()) / (1000 * 60 * 60);
    return {
      valid: false,
      message: `Driver needs 10-hour break. Last shift ended at ${previousShift.endTime.toLocaleTimeString()}, only ${hoursSinceLastShift.toFixed(1)} hours ago.`,
      previousShiftEnd: previousShift.endTime,
    };
  }
  
  return { valid: true };
}

/**
 * Get all shifts for a driver in chronological order
 */
export function getDriverShifts(driverId: number, allShifts: Shift[]): Shift[] {
  return allShifts
    .filter(shift => shift.driverId === driverId)
    .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
}

/**
 * Format hours difference for display
 */
export function formatHoursDifference(hours: number): string {
  if (hours < 1) {
    return `${Math.round(hours * 60)} minutes`;
  }
  return `${hours.toFixed(1)} hours`;
}

