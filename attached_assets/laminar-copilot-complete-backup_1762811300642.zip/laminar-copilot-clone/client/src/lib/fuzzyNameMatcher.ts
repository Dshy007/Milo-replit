/**
 * Intelligent fuzzy name matching for driver names
 * Handles partial names, misspellings, nicknames, and various formats
 */

export interface Driver {
  id: number;
  name: string;
  driverType?: "Solo1" | "Solo2" | "Both" | null;
  status?: string;
}

export interface MatchResult {
  driver: Driver;
  confidence: number; // 0-100
  matchType: string; // "exact", "last_name", "first_name", "fuzzy", etc.
}

// Common nickname mappings
const NICKNAMES: Record<string, string[]> = {
  robert: ['bob', 'rob', 'bobby'],
  mathew: ['matt', 'matthew', 'mat'],
  matthew: ['matt', 'mathew', 'mat'],
  william: ['will', 'bill', 'billy'],
  richard: ['rick', 'dick', 'rich'],
  brian: ['bryan'],
  michael: ['mike', 'mich'],
  joshua: ['josh'],
  raymond: ['ray'],
};

/**
 * Calculate Levenshtein distance between two strings (for typo tolerance)
 */
function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

/**
 * Normalize a name for comparison
 */
function normalizeName(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[.,;]/g, '') // Remove punctuation
    .replace(/\s+/g, ' '); // Normalize spaces
}

/**
 * Split name into parts
 */
function splitName(name: string): string[] {
  return normalizeName(name).split(/[\s;]+/).filter(p => p.length > 0);
}

/**
 * Check if a search term matches a name part (with nickname support)
 */
function matchesWithNickname(searchTerm: string, namePart: string): boolean {
  const searchLower = searchTerm.toLowerCase();
  const nameLower = namePart.toLowerCase();
  
  // Direct match
  if (nameLower === searchLower || nameLower.includes(searchLower) || searchLower.includes(nameLower)) {
    return true;
  }
  
  // Check nicknames
  const nicknames = NICKNAMES[nameLower] || [];
  if (nicknames.includes(searchLower)) {
    return true;
  }
  
  // Check if searchTerm is a nickname for namePart
  for (const [fullName, nicks] of Object.entries(NICKNAMES)) {
    if (nicks.includes(searchLower) && nameLower === fullName) {
      return true;
    }
  }
  
  return false;
}

/**
 * Find best matching driver for a search name
 */
export function findDriverByName(
  drivers: Driver[],
  searchName: string,
  minConfidence: number = 50
): MatchResult | null {
  const searchNormalized = normalizeName(searchName);
  const searchParts = splitName(searchName);
  
  const matches: MatchResult[] = [];

  for (const driver of drivers) {
    const driverNormalized = normalizeName(driver.name);
    const driverParts = splitName(driver.name);
    
    // 1. Exact match (100% confidence)
    if (driverNormalized === searchNormalized) {
      matches.push({ driver, confidence: 100, matchType: 'exact' });
      continue;
    }
    
    // 2. Full fuzzy match (95% confidence if very close)
    if (driverNormalized.includes(searchNormalized) || searchNormalized.includes(driverNormalized)) {
      matches.push({ driver, confidence: 95, matchType: 'contains' });
      continue;
    }
    
    // 3. Last name match (90% confidence)
    const driverLastName = driverParts[driverParts.length - 1];
    const searchLastName = searchParts[searchParts.length - 1];
    
    if (searchParts.length === 1 && matchesWithNickname(searchParts[0], driverLastName)) {
      matches.push({ driver, confidence: 90, matchType: 'last_name' });
      continue;
    }
    
    // 4. First name match (85% confidence)
    const driverFirstName = driverParts[0];
    const searchFirstName = searchParts[0];
    
    if (searchParts.length === 1 && matchesWithNickname(searchParts[0], driverFirstName)) {
      matches.push({ driver, confidence: 85, matchType: 'first_name' });
      continue;
    }
    
    // 5. Multi-part semicolon match (for "Robert Charles; JR Dixon")
    const semicolonParts = searchName.split(';').map(p => p.trim());
    for (const part of semicolonParts) {
      const partNormalized = normalizeName(part);
      const partParts = splitName(part);
      
      if (partParts.length >= 2 && driverParts.length >= 2) {
        const partLastName = partParts[partParts.length - 1];
        const partFirstName = partParts[0];
        
        // Match last name + first initial or first name
        if (driverLastName === partLastName && 
            (matchesWithNickname(partFirstName, driverFirstName) || 
             driverFirstName[0] === partFirstName[0])) {
          matches.push({ driver, confidence: 88, matchType: 'last_first' });
          break;
        }
      }
    }
    
    // 6. Levenshtein distance match (typo tolerance)
    const distance = levenshteinDistance(searchNormalized, driverNormalized);
    const maxLen = Math.max(searchNormalized.length, driverNormalized.length);
    const similarity = ((maxLen - distance) / maxLen) * 100;
    
    if (similarity >= 70) {
      matches.push({ driver, confidence: similarity, matchType: 'fuzzy' });
    }
    
    // 7. Partial word matches
    let partialMatchCount = 0;
    for (const searchPart of searchParts) {
      for (const driverPart of driverParts) {
        if (matchesWithNickname(searchPart, driverPart)) {
          partialMatchCount++;
          break;
        }
      }
    }
    
    if (partialMatchCount > 0) {
      const partialConfidence = (partialMatchCount / searchParts.length) * 80;
      if (partialConfidence >= minConfidence) {
        matches.push({ driver, confidence: partialConfidence, matchType: 'partial' });
      }
    }
  }
  
  // Return best match above minimum confidence
  if (matches.length === 0) {
    return null;
  }
  
  matches.sort((a, b) => b.confidence - a.confidence);
  const bestMatch = matches[0];
  
  return bestMatch.confidence >= minConfidence ? bestMatch : null;
}

/**
 * Find all possible matches (for "Did you mean...?" suggestions)
 */
export function findAllMatches(
  drivers: Driver[],
  searchName: string,
  minConfidence: number = 50,
  maxResults: number = 5
): MatchResult[] {
  const matches: MatchResult[] = [];
  
  for (const driver of drivers) {
    const result = findDriverByName([driver], searchName, 0);
    if (result && result.confidence >= minConfidence) {
      matches.push(result);
    }
  }
  
  matches.sort((a, b) => b.confidence - a.confidence);
  return matches.slice(0, maxResults);
}

