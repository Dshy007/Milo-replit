import { ImportedBlock } from "./blockImportParser";

export interface Driver {
  id: number;
  name: string;
  driverType: "Solo1" | "Solo2" | "Both" | null;
  status: string;
}

export interface ScheduleAssignment {
  day: string;
  time: string;
  contractType: "Solo1" | "Solo2";
  driverId: number;
  driverName: string;
}

export interface AssignmentDetail {
  block: ImportedBlock;
  driver: Driver | null;
  reason: string;
  success: boolean;
}

export interface AutoBuildResult {
  assignments: Record<string, Driver>; // key: "day_time_contractType"
  unassignedBlocks: ImportedBlock[];
  warnings: string[];
  assignmentDetails: AssignmentDetail[];
}

/**
 * Improved auto-build with detailed logging and validation
 */
export function autoBuildImproved(
  blocks: ImportedBlock[],
  lastWeekSchedule: ScheduleAssignment[],
  availableDrivers: Driver[],
  currentWeekStart: Date,
  aiPrompt?: string
): AutoBuildResult {
  const assignments: Record<string, Driver> = {};
  const unassignedBlocks: ImportedBlock[] = [];
  const warnings: string[] = [];
  const assignmentDetails: AssignmentDetail[] = [];
  
  console.log(`[AutoBuild] Starting auto-build for week of ${currentWeekStart.toLocaleDateString()}`);
  console.log(`[AutoBuild] Processing ${blocks.length} blocks with ${availableDrivers.length} drivers`);
  
  if (aiPrompt) {
    warnings.push(`AI Instructions: ${aiPrompt}`);
  }

  // Create a lookup map of last week's assignments by time + contract type
  const lastWeekMap = new Map<string, ScheduleAssignment[]>();
  lastWeekSchedule.forEach(assignment => {
    const key = `${assignment.time}_${assignment.contractType}`;
    if (!lastWeekMap.has(key)) {
      lastWeekMap.set(key, []);
    }
    lastWeekMap.get(key)!.push(assignment);
  });

  // Process each block
  blocks.forEach((block, index) => {
    console.log(`\n[AutoBuild] Block ${index + 1}/${blocks.length}: ${block.startTime} ${block.contractType} on ${block.dayOfWeek} (${block.startDate})`);
    
    if (!block.dayOfWeek) {
      const msg = `Block ${block.startTime} ${block.contractType} has no day assigned`;
      warnings.push(msg);
      unassignedBlocks.push(block);
      assignmentDetails.push({ block, driver: null, reason: "No day of week", success: false });
      console.log(`[AutoBuild] ❌ ${msg}`);
      return;
    }

    const key = `${block.dayOfWeek}_${block.startTime}_${block.contractType}`;
    const lookupKey = `${block.startTime}_${block.contractType}`;

    // PRIORITY 1: Check if block has a suggested driver from CSV
    if (block.suggestedDriver) {
      console.log(`[AutoBuild] Suggested driver: ${block.suggestedDriver}`);
      const suggestedDriver = findDriverByName(availableDrivers, block.suggestedDriver);
      
      if (suggestedDriver) {
        console.log(`[AutoBuild] Found match: ${suggestedDriver.name} (ID: ${suggestedDriver.id})`);
        
        if (isDriverAvailable(suggestedDriver, block, assignments)) {
          assignments[key] = suggestedDriver;
          assignmentDetails.push({
            block,
            driver: suggestedDriver,
            reason: `Suggested driver from CSV: ${block.suggestedDriver}`,
            success: true
          });
          console.log(`[AutoBuild] ✅ Assigned ${suggestedDriver.name} to ${block.dayOfWeek} ${block.startTime}`);
          return;
        } else {
          const msg = `Suggested driver ${block.suggestedDriver} not available for ${block.dayOfWeek} ${block.startTime}`;
          warnings.push(msg);
          console.log(`[AutoBuild] ⚠️ ${msg}`);
        }
      } else {
        const msg = `Suggested driver ${block.suggestedDriver} not found in driver list`;
        warnings.push(msg);
        console.log(`[AutoBuild] ⚠️ ${msg}`);
        console.log(`[AutoBuild] Available drivers: ${availableDrivers.map(d => d.name).join(', ')}`);
      }
    }

    // PRIORITY 2: Find last week's assignments for this time/type
    const lastWeekAssignments = lastWeekMap.get(lookupKey) || [];
    console.log(`[AutoBuild] Last week had ${lastWeekAssignments.length} assignments for ${lookupKey}`);

    if (lastWeekAssignments.length > 0) {
      // Try to match with the same driver from last week (same day of week)
      const sameDayAssignment = lastWeekAssignments.find(a => a.day === block.dayOfWeek);
      if (sameDayAssignment) {
        const driver = availableDrivers.find(d => d.id === sameDayAssignment.driverId);
        if (driver && isDriverAvailable(driver, block, assignments)) {
          assignments[key] = driver;
          assignmentDetails.push({
            block,
            driver,
            reason: `Same driver from last week (${driver.name})`,
            success: true
          });
          console.log(`[AutoBuild] ✅ Assigned ${driver.name} (same as last week)`);
          return;
        }
      }

      // If same day doesn't work, try any driver from last week's assignments
      for (const assignment of lastWeekAssignments) {
        const driver = availableDrivers.find(d => d.id === assignment.driverId);
        if (driver && isDriverAvailable(driver, block, assignments)) {
          assignments[key] = driver;
          assignmentDetails.push({
            block,
            driver,
            reason: `Driver from last week (${driver.name})`,
            success: true
          });
          console.log(`[AutoBuild] ✅ Assigned ${driver.name} (from last week's pool)`);
          return;
        }
      }
    }

    // PRIORITY 3: Find any suitable driver
    const suitableDriver = findSuitableDriver(block, availableDrivers, assignments);
    if (suitableDriver) {
      assignments[key] = suitableDriver;
      assignmentDetails.push({
        block,
        driver: suitableDriver,
        reason: `Auto-selected suitable driver (${suitableDriver.name})`,
        success: true
      });
      console.log(`[AutoBuild] ✅ Assigned ${suitableDriver.name} (auto-selected)`);
    } else {
      const msg = `Could not assign driver for ${block.dayOfWeek} ${block.startTime} ${block.contractType}`;
      warnings.push(msg);
      unassignedBlocks.push(block);
      assignmentDetails.push({ block, driver: null, reason: "No suitable driver available", success: false });
      console.log(`[AutoBuild] ❌ ${msg}`);
    }
  });

  // Add profitability warnings
  const driverWorkload = new Map<number, { solo1: number; solo2: number; name: string }>();
  Object.entries(assignments).forEach(([key, driver]) => {
    if (!driverWorkload.has(driver.id)) {
      driverWorkload.set(driver.id, { solo1: 0, solo2: 0, name: driver.name });
    }
    const [, , contractType] = key.split('_');
    const workload = driverWorkload.get(driver.id)!;
    if (contractType === 'Solo1') workload.solo1++;
    if (contractType === 'Solo2') workload.solo2++;
  });
  
  driverWorkload.forEach((workload, driverId) => {
    console.log(`[AutoBuild] ${workload.name}: ${workload.solo1} Solo1, ${workload.solo2} Solo2`);
    
    if (workload.solo1 >= 5) {
      warnings.push(`⚠️ ${workload.name}: ${workload.solo1} Solo1 shifts - Doable but not profitable`);
    }
    if (workload.solo2 >= 3) {
      warnings.push(`⚠️ ${workload.name}: ${workload.solo2} Solo2 shifts - Doable but not profitable`);
    }
    if (workload.solo1 === 3 && workload.solo2 === 2) {
      warnings.push(`✅ ${workload.name}: Optimal schedule (3 Solo1 + 2 Solo2)`);
    }
  });
  
  console.log(`\n[AutoBuild] Complete: ${Object.keys(assignments).length} assigned, ${unassignedBlocks.length} unassigned`);
  
  return {
    assignments,
    unassignedBlocks,
    warnings,
    assignmentDetails,
  };
}

/**
 * Improved driver name matching with comprehensive fuzzy logic
 */
function findDriverByName(drivers: Driver[], searchName: string): Driver | undefined {
  const searchLower = searchName.toLowerCase().trim();
  
  // Split on semicolon for multi-driver names (e.g., "Robert Charles; JR Dixon")
  const nameParts = searchName.split(';').map(n => n.trim());
  
  return drivers.find(d => {
    const driverNameLower = d.name.toLowerCase().trim();
    
    // 1. Exact match
    if (driverNameLower === searchLower) {
      console.log(`[Match] Exact match: ${d.name} === ${searchName}`);
      return true;
    }
    
    // 2. Full fuzzy match
    if (driverNameLower.includes(searchLower) || searchLower.includes(driverNameLower)) {
      console.log(`[Match] Fuzzy match: ${d.name} ~ ${searchName}`);
      return true;
    }
    
    // 3. Try matching any part of semicolon-separated names
    for (const part of nameParts) {
      const partLower = part.toLowerCase().trim();
      
      // Simple contains match
      if (driverNameLower.includes(partLower) || partLower.includes(driverNameLower)) {
        console.log(`[Match] Part match: ${d.name} ~ ${part}`);
        return true;
      }
      
      // 4. Smart matching: "R. Dixon" (database) with "JR Dixon" (CSV)
      const dbParts = driverNameLower.split(/[\s.,]+/).filter(p => p.length > 0);
      const csvParts = partLower.split(/[\s.,]+/).filter(p => p.length > 0);
      
      if (dbParts.length >= 2 && csvParts.length >= 2) {
        const dbLastName = dbParts[dbParts.length - 1];
        const dbFirstPart = dbParts[0];
        const dbFirstInitial = dbFirstPart[0];
        
        const csvLastName = csvParts[csvParts.length - 1];
        const csvFirstPart = csvParts[0];
        const csvFirstInitial = csvFirstPart[0];
        
        // Match if last names match AND first initials match
        if (dbLastName === csvLastName) {
          // Check if first initials match (handles "R. Dixon" vs "JR Dixon")
          if (dbFirstInitial === csvFirstInitial || 
              csvFirstPart.includes(dbFirstInitial) || 
              dbFirstPart.includes(csvFirstInitial)) {
            console.log(`[Match] Last name + initial: ${d.name} ~ ${part} (${dbLastName} + ${dbFirstInitial}/${csvFirstInitial})`);
            return true;
          }
        }
      }
    }
    
    return false;
  });
}

/**
 * Check if a driver is available for a block
 */
function isDriverAvailable(
  driver: Driver,
  block: ImportedBlock,
  currentAssignments: Record<string, Driver>
): boolean {
  // Check if driver is active
  if (driver.status !== "active") {
    console.log(`[Availability] ${driver.name} is not active (status: ${driver.status})`);
    return false;
  }

  // Check if driver type matches
  if (driver.driverType && driver.driverType !== "Both" && driver.driverType !== block.contractType) {
    console.log(`[Availability] ${driver.name} type mismatch (${driver.driverType} vs ${block.contractType})`);
    return false;
  }

  // Check if driver is already assigned to this time slot on this day
  const key = `${block.dayOfWeek}_${block.startTime}_${block.contractType}`;
  if (currentAssignments[key]?.id === driver.id) {
    console.log(`[Availability] ${driver.name} already assigned to ${key}`);
    return false;
  }

  return true;
}

/**
 * Find a suitable driver for a block
 */
function findSuitableDriver(
  block: ImportedBlock,
  availableDrivers: Driver[],
  currentAssignments: Record<string, Driver>
): Driver | undefined {
  // Filter drivers by type and availability
  const candidates = availableDrivers.filter(d => 
    isDriverAvailable(d, block, currentAssignments)
  );
  
  console.log(`[FindSuitable] ${candidates.length} candidates for ${block.contractType} block`);
  
  // Prefer drivers with matching type (not "Both")
  const exactTypeMatch = candidates.find(d => d.driverType === block.contractType);
  if (exactTypeMatch) {
    console.log(`[FindSuitable] Found exact type match: ${exactTypeMatch.name}`);
    return exactTypeMatch;
  }
  
  // Return first available driver
  if (candidates.length > 0) {
    console.log(`[FindSuitable] Using first available: ${candidates[0].name}`);
    return candidates[0];
  }
  
  console.log(`[FindSuitable] No suitable driver found`);
  return undefined;
}

