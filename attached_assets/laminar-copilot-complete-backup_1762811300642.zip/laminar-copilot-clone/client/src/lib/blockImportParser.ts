import Papa from "papaparse";

export interface ImportedBlock {
  startTime: string; // e.g., "16:30"
  tractor: string;
  contractType: "Solo1" | "Solo2";
  domicile: string;
  dayOfWeek?: string; // e.g., "Monday", "Tuesday", etc.
  startDate?: string; // e.g., "10/29/2025"
  suggestedDriver?: string; // Optional: only present in learning mode CSVs
}

export function parseBlockCSV(csvData: string): {
  blocks: ImportedBlock[];
  errors: string[];
} {
  const blocks: ImportedBlock[] = [];
  const errors: string[] = [];

  try {
    // Parse CSV without header transformation - we'll handle columns by index
    const result = Papa.parse(csvData, {
      header: false, // Don't use first row as header
      skipEmptyLines: true,
    });

    if (result.errors.length > 0) {
      errors.push(...result.errors.map(e => e.message));
    }

    const rows = result.data as string[][];
    
    // Skip header row (index 0) and process data rows
    rows.slice(1).forEach((row, index) => {
      // Only process rows where column 2 (index 2) = "Block"
      if (row[2]?.trim() !== "Block") {
        return; // Skip Trip rows, only process Block rows
      }

      // Extract data from specific columns (0-indexed)
      // Column 0: Block ID
      // Column 8: Driver Name
      // Column 18: Truck Filter (FTIM field with contract type)
      // Column 28: Stop 1 (Location)
      // Column 30: Stop 1 Planned Arrival Date
      // Column 31: Stop 1 Planned Arrival Time
      const blockId = row[0]?.trim() || "";
      const driverName = row[8]?.trim() || "";
      const contractTypeField = row[18]?.trim() || ""; // e.g., "FTIM_MKC_Solo1_Tractor_1_d1"
      const startLocation = row[28]?.trim() || "KANSAS CITY";
      const startDate = row[30]?.trim() || "";
      const startTime = row[31]?.trim() || "";

      // Validate required fields
      if (!startTime) {
        errors.push(`Row ${index + 2}: Missing start time for block ${blockId}`);
        return;
      }

      // Extract contract type from the FTIM field
      let contractType: "Solo1" | "Solo2";
      if (contractTypeField.includes("Solo1")) {
        contractType = "Solo1";
      } else if (contractTypeField.includes("Solo2")) {
        contractType = "Solo2";
      } else {
        // Skip rows without recognizable contract type
        return;
      }

      // Extract day of week from start date (e.g., "10/29/2025" -> "Tuesday")
      let dayOfWeek: string | undefined;
      if (startDate) {
        try {
          const date = new Date(startDate);
          const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          dayOfWeek = days[date.getDay()];
        } catch (e) {
          // If date parsing fails, leave dayOfWeek undefined
        }
      }

      const block: ImportedBlock = {
        startTime: startTime,
        tractor: blockId, // Use Block ID as tractor identifier
        contractType: contractType,
        domicile: startLocation,
        dayOfWeek: dayOfWeek,
        startDate: startDate,
      };
      
      // If driver name is present, add it as a suggestion (learning mode)
      if (driverName) {
        block.suggestedDriver = driverName;
      }
      
      blocks.push(block);
    });

    if (blocks.length === 0 && errors.length === 0) {
      errors.push("No valid blocks found in CSV. Make sure the file contains Block rows (not just Trip rows).");
    }

  } catch (error) {
    errors.push(`Failed to parse CSV: ${error instanceof Error ? error.message : String(error)}`);
  }

  return { blocks, errors };
}

