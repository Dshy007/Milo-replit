import { ImportedBlock } from "./blockImportParser";
import { findDriverByName } from "./fuzzyNameMatcher";

export interface Driver {
  id: number;
  name: string;
  driverType: "Solo1" | "Solo2" | "Both" | null;
  status: string;
}

export interface ScheduleAssignment {
  day: string;
  time: string;
  contractType: "Solo1" | "Solo2";
  driverId: number;
  driverName: string;
}

export interface AutoBuildResult {
  assignments: Record<string, Driver>; // key: "day_time_contractType"
  unassignedBlocks: ImportedBlock[];
  warnings: string[];
}

/**
 * Auto-build schedule from imported blocks using last week's assignments
 */
export function autoBuildFromLastWeek(
  blocks: ImportedBlock[],
  lastWeekSchedule: ScheduleAssignment[],
  availableDrivers: Driver[],
  aiPrompt?: string
): AutoBuildResult {
  const assignments: Record<string, Driver> = {};
  const unassignedBlocks: ImportedBlock[] = [];
  const warnings: string[] = [];
  
  // Parse AI prompt for constraints
  const constraints = parseAIPrompt(aiPrompt);
  if (aiPrompt) {
    warnings.push(`AI Instructions: ${aiPrompt}`);
  }

  // Create a lookup map of last week's assignments by time + contract type
  const lastWeekMap = new Map<string, ScheduleAssignment[]>();
  lastWeekSchedule.forEach(assignment => {
    const key = `${assignment.time}_${assignment.contractType}`;
    if (!lastWeekMap.has(key)) {
      lastWeekMap.set(key, []);
    }
    lastWeekMap.get(key)!.push(assignment);
  });

  // Process each block
  blocks.forEach(block => {
    if (!block.dayOfWeek) {
      warnings.push(`Block ${block.startTime} ${block.contractType} has no day assigned`);
      unassignedBlocks.push(block);
      return;
    }

    const key = `${block.dayOfWeek}_${block.startTime}_${block.contractType}`;
    const lookupKey = `${block.startTime}_${block.contractType}`;

    // PRIORITY 1: Check if block has a suggested driver from CSV
    if (block.suggestedDriver) {
      const matchResult = findDriverByName(availableDrivers as any[], block.suggestedDriver, 70);
      const suggestedDriver = matchResult?.driver as Driver | undefined;
      
      if (suggestedDriver && isDriverAvailable(suggestedDriver, block, assignments)) {
        assignments[key] = suggestedDriver;
        return; // Successfully assigned suggested driver
      } else if (suggestedDriver) {
        warnings.push(`Suggested driver ${block.suggestedDriver} not available for ${block.dayOfWeek} ${block.startTime}`);
      } else {
        warnings.push(`Suggested driver ${block.suggestedDriver} not found in driver list`);
      }
    }

    // PRIORITY 2: Find last week's assignments for this time/type
    const lastWeekAssignments = lastWeekMap.get(lookupKey) || [];

    if (lastWeekAssignments.length === 0) {
      // No history for this slot - try to find a suitable driver
      const suitableDriver = findSuitableDriver(block, availableDrivers, assignments, constraints);
      if (suitableDriver) {
        assignments[key] = suitableDriver;
      } else {
        warnings.push(`No suitable driver found for ${block.dayOfWeek} ${block.startTime} ${block.contractType}`);
        unassignedBlocks.push(block);
      }
      return;
    }

    // Try to match with the same driver from last week (same day of week)
    const sameDayAssignment = lastWeekAssignments.find(a => a.day === block.dayOfWeek);
    if (sameDayAssignment) {
      const driver = availableDrivers.find(d => d.id === sameDayAssignment.driverId);
      if (driver && isDriverAvailable(driver, block, assignments)) {
        assignments[key] = driver;
        return;
      }
    }

    // If same day doesn't work, try any driver from last week's assignments
    for (const assignment of lastWeekAssignments) {
      const driver = availableDrivers.find(d => d.id === assignment.driverId);
      if (driver && isDriverAvailable(driver, block, assignments)) {
        assignments[key] = driver;
        return;
      }
    }

    // Still no match - find any suitable driver
    const suitableDriver = findSuitableDriver(block, availableDrivers, assignments, constraints);
    if (suitableDriver) {
      assignments[key] = suitableDriver;
    } else {
      warnings.push(`Could not assign driver for ${block.dayOfWeek} ${block.startTime} ${block.contractType}`);
      unassignedBlocks.push(block);
    }
  });

  // Add profitability warnings
  const driverWorkload = new Map<number, { solo1: number; solo2: number; name: string }>();
  Object.entries(assignments).forEach(([key, driver]) => {
    if (!driverWorkload.has(driver.id)) {
      driverWorkload.set(driver.id, { solo1: 0, solo2: 0, name: driver.name });
    }
    const [, , contractType] = key.split('_');
    const workload = driverWorkload.get(driver.id)!;
    if (contractType === 'Solo1') workload.solo1++;
    if (contractType === 'Solo2') workload.solo2++;
  });
  
  driverWorkload.forEach((workload, driverId) => {
    // Warn if 5-6 Solo1 (doable but not profitable)
    if (workload.solo1 >= 5) {
      warnings.push(`⚠️ ${workload.name}: ${workload.solo1} Solo1 shifts - Doable but not profitable`);
    }
    
    // Warn if 3 Solo2 (doable but not profitable)
    if (workload.solo2 >= 3) {
      warnings.push(`⚠️ ${workload.name}: ${workload.solo2} Solo2 shifts - Doable but not profitable`);
    }
    
    // Show optimal assignments
    if (workload.solo1 === 3 && workload.solo2 === 2) {
      warnings.push(`✅ ${workload.name}: Optimal schedule (3 Solo1 + 2 Solo2)`);
    }
  });
  
  return {
    assignments,
    unassignedBlocks,
    warnings,
  };
}

/**
 * Analyze driver capacity and determine if more drivers are needed
 */
export function analyzeDriverCapacity(
  totalBlocks: { Solo1: number; Solo2: number },
  availableDrivers: Driver[],
  optimalPerDriver: { Solo1: number; Solo2: number } = { Solo1: 3, Solo2: 2 }
): {
  needsMoreDrivers: boolean;
  additionalDriversNeeded: number;
  currentCapacity: { Solo1: number; Solo2: number };
  analysis: string;
} {
  const activeDrivers = availableDrivers.filter(d => d.status === 'active');
  const driverCount = activeDrivers.length;
  
  // Calculate total capacity based on optimal assignments
  const currentCapacity = {
    Solo1: driverCount * optimalPerDriver.Solo1,
    Solo2: driverCount * optimalPerDriver.Solo2,
  };
  
  // Calculate shortfall
  const solo1Shortfall = Math.max(0, totalBlocks.Solo1 - currentCapacity.Solo1);
  const solo2Shortfall = Math.max(0, totalBlocks.Solo2 - currentCapacity.Solo2);
  
  // Determine how many additional drivers needed
  const driversNeededForSolo1 = Math.ceil(solo1Shortfall / optimalPerDriver.Solo1);
  const driversNeededForSolo2 = Math.ceil(solo2Shortfall / optimalPerDriver.Solo2);
  const additionalDriversNeeded = Math.max(driversNeededForSolo1, driversNeededForSolo2);
  
  const needsMoreDrivers = additionalDriversNeeded > 0;
  
  // Generate analysis text
  let analysis = '';
  if (needsMoreDrivers) {
    analysis = `You need **${additionalDriversNeeded} more driver(s)** to fill this schedule optimally.\n\n`;
    analysis += `**Current situation:**\n`;
    analysis += `- Active drivers: ${driverCount}\n`;
    analysis += `- Capacity: ${currentCapacity.Solo1} Solo1, ${currentCapacity.Solo2} Solo2\n`;
    analysis += `- Blocks to fill: ${totalBlocks.Solo1} Solo1, ${totalBlocks.Solo2} Solo2\n`;
    analysis += `- Shortfall: ${solo1Shortfall} Solo1, ${solo2Shortfall} Solo2\n\n`;
    analysis += `**Optimal:** ${optimalPerDriver.Solo1} Solo1 + ${optimalPerDriver.Solo2} Solo2 per driver (profitable range)`;
  } else {
    const solo1Surplus = currentCapacity.Solo1 - totalBlocks.Solo1;
    const solo2Surplus = currentCapacity.Solo2 - totalBlocks.Solo2;
    analysis = `✅ **You have enough drivers!**\n\n`;
    analysis += `**Current situation:**\n`;
    analysis += `- Active drivers: ${driverCount}\n`;
    analysis += `- Capacity: ${currentCapacity.Solo1} Solo1, ${currentCapacity.Solo2} Solo2\n`;
    analysis += `- Blocks to fill: ${totalBlocks.Solo1} Solo1, ${totalBlocks.Solo2} Solo2\n`;
    analysis += `- Surplus capacity: ${solo1Surplus} Solo1, ${solo2Surplus} Solo2\n\n`;
    analysis += `You can fill this schedule and stay within the optimal ${optimalPerDriver.Solo1} Solo1 + ${optimalPerDriver.Solo2} Solo2 per driver range.`;
  }
  
  return {
    needsMoreDrivers,
    additionalDriversNeeded,
    currentCapacity,
    analysis,
  };
}

/**
 * Check if a driver is available for a block
 */
function isDriverAvailable(
  driver: Driver,
  block: ImportedBlock,
  currentAssignments: Record<string, Driver>
): boolean {
  // Check if driver is active
  if (driver.status !== "active") {
    return false;
  }

  // Check if driver type matches
  if (driver.driverType && driver.driverType !== "Both" && driver.driverType !== block.contractType) {
    return false;
  }

  // Check if driver is already assigned to this time slot on this day
  const key = `${block.dayOfWeek}_${block.startTime}_${block.contractType}`;
  if (currentAssignments[key]?.id === driver.id) {
    return false;
  }

  // TODO: Add HOS validation here (10-hour break rule)

  return true;
}

/**
 * Parse AI prompt for constraints
 */
interface AIConstraints {
  maxDaysPerDriver?: Record<string, number>; // driver name -> max days
  prioritizeDriverType?: "Solo1" | "Solo2";
  avoidDrivers?: string[]; // driver names to avoid
  balanceWorkload?: boolean;
  contractTypeLimits?: Record<string, { Solo1?: number; Solo2?: number }>; // driver name -> contract limits
  optimalRange?: { Solo1: number; Solo2: number }; // optimal blocks per driver
}

function parseAIPrompt(prompt?: string): AIConstraints {
  if (!prompt) return {};
  
  const lower = prompt.toLowerCase();
  const constraints: AIConstraints = {};
  
  // Parse "Keep [driver] under [X] days"
  const maxDaysMatch = lower.match(/keep\s+(\w+(?:\s+\w+)*)\s+under\s+(\d+)\s+days?/i);
  if (maxDaysMatch) {
    const driverName = maxDaysMatch[1].trim();
    const maxDays = parseInt(maxDaysMatch[2]);
    constraints.maxDaysPerDriver = { [driverName]: maxDays };
  }
  
  // Parse "Prioritize Solo1/Solo2 drivers"
  if (lower.includes('prioritize solo1')) {
    constraints.prioritizeDriverType = 'Solo1';
  } else if (lower.includes('prioritize solo2')) {
    constraints.prioritizeDriverType = 'Solo2';
  }
  
  // Parse "Balance workload"
  if (lower.includes('balance') && (lower.includes('workload') || lower.includes('evenly'))) {
    constraints.balanceWorkload = true;
  }
  
  // Parse "Give [driver] only [X] Solo1" or "Give [driver] only [X] Solo2"
  const contractLimitMatch = lower.match(/give\s+(\w+(?:\s+\w+)*)\s+only\s+(\d+)\s+(solo1|solo2)/i);
  if (contractLimitMatch) {
    const driverName = contractLimitMatch[1].trim();
    const limit = parseInt(contractLimitMatch[2]);
    const contractType = contractLimitMatch[3] as 'solo1' | 'solo2';
    
    if (!constraints.contractTypeLimits) {
      constraints.contractTypeLimits = {};
    }
    
    if (!constraints.contractTypeLimits[driverName]) {
      constraints.contractTypeLimits[driverName] = {};
    }
    
    if (contractType === 'solo1') {
      constraints.contractTypeLimits[driverName].Solo1 = limit;
    } else {
      constraints.contractTypeLimits[driverName].Solo2 = limit;
    }
  }
  
  // Parse "Keep everyone between [X] Solo1 and [Y] Solo2"
  const optimalRangeMatch = lower.match(/keep\s+everyone\s+between\s+(\d+)\s+solo1\s+and\s+(\d+)\s+solo2/i);
  if (optimalRangeMatch) {
    constraints.optimalRange = {
      Solo1: parseInt(optimalRangeMatch[1]),
      Solo2: parseInt(optimalRangeMatch[2]),
    };
  }
  
  return constraints;
}

/**
 * Check if driver violates AI constraints
 */
function violatesConstraints(
  driver: Driver,
  constraints: AIConstraints,
  currentAssignments: Record<string, Driver>,
  block?: ImportedBlock
): boolean {
  // Check max days constraint
  if (constraints.maxDaysPerDriver) {
    for (const [driverName, maxDays] of Object.entries(constraints.maxDaysPerDriver)) {
      if (driver.name.toLowerCase().includes(driverName.toLowerCase())) {
        // Count how many days this driver is already assigned
        const assignedDays = new Set<string>();
        Object.entries(currentAssignments).forEach(([key, assignedDriver]) => {
          if (assignedDriver.id === driver.id) {
            const [day] = key.split('_');
            assignedDays.add(day);
          }
        });
        
        if (assignedDays.size >= maxDays) {
          return true; // Violates max days constraint
        }
      }
    }
  }
  
  // Check contract type limits (e.g., "Give Firas only 1 Solo1")
  if (constraints.contractTypeLimits && block) {
    for (const [driverName, limits] of Object.entries(constraints.contractTypeLimits)) {
      if (driver.name.toLowerCase().includes(driverName.toLowerCase())) {
        // Count how many blocks of this contract type the driver already has
        let solo1Count = 0;
        let solo2Count = 0;
        
        Object.entries(currentAssignments).forEach(([key, assignedDriver]) => {
          if (assignedDriver.id === driver.id) {
            const [, , contractType] = key.split('_');
            if (contractType === 'Solo1') solo1Count++;
            if (contractType === 'Solo2') solo2Count++;
          }
        });
        
        // Check if adding this block would exceed the limit
        if (block.contractType === 'Solo1' && limits.Solo1 !== undefined && solo1Count >= limits.Solo1) {
          return true;
        }
        if (block.contractType === 'Solo2' && limits.Solo2 !== undefined && solo2Count >= limits.Solo2) {
          return true;
        }
      }
    }
  }
  
  // Check optimal range constraint (applies to ALL drivers)
  if (constraints.optimalRange && block) {
    let solo1Count = 0;
    let solo2Count = 0;
    
    Object.entries(currentAssignments).forEach(([key, assignedDriver]) => {
      if (assignedDriver.id === driver.id) {
        const [, , contractType] = key.split('_');
        if (contractType === 'Solo1') solo1Count++;
        if (contractType === 'Solo2') solo2Count++;
      }
    });
    
    // Check if adding this block would exceed optimal range
    if (block.contractType === 'Solo1' && solo1Count >= constraints.optimalRange.Solo1) {
      return true;
    }
    if (block.contractType === 'Solo2' && solo2Count >= constraints.optimalRange.Solo2) {
      return true;
    }
  }
  
  return false;
}

/**
 * Find a suitable driver for a block
 */
function findSuitableDriver(
  block: ImportedBlock,
  availableDrivers: Driver[],
  currentAssignments: Record<string, Driver>,
  constraints: AIConstraints = {}
): Driver | null {
  // Filter drivers by type and availability
  let suitable = availableDrivers.filter(driver =>
    isDriverAvailable(driver, block, currentAssignments) &&
    !violatesConstraints(driver, constraints, currentAssignments, block)
  );

  if (suitable.length === 0) {
    return null;
  }
  
  // Apply prioritization from AI constraints
  if (constraints.prioritizeDriverType) {
    const prioritized = suitable.filter(d => d.driverType === constraints.prioritizeDriverType);
    if (prioritized.length > 0) {
      suitable = prioritized;
    }
  }

  // Prefer drivers with matching type (not "Both")
  const exactMatch = suitable.find(d => d.driverType === block.contractType);
  if (exactMatch) {
    return exactMatch;
  }
  
  // If balancing workload, prefer driver with fewest assignments
  if (constraints.balanceWorkload) {
    const driverWorkload = new Map<number, number>();
    Object.values(currentAssignments).forEach(driver => {
      driverWorkload.set(driver.id, (driverWorkload.get(driver.id) || 0) + 1);
    });
    
    suitable.sort((a, b) => {
      const aLoad = driverWorkload.get(a.id) || 0;
      const bLoad = driverWorkload.get(b.id) || 0;
      return aLoad - bLoad;
    });
  }

  // Return first available (or least loaded if balancing)
  return suitable[0];
}

