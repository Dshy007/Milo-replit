import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Navigation() {
  const { isAuthenticated } = useAuth();
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <img src="/milo-logo.png" alt="Milo" className="w-8 h-8" />
              <span className="text-xl font-semibold text-foreground">Milo</span>
            </div>
          </Link>

          {/* Right Side */}
          <div className="flex items-center gap-6">
            {/* Navigation Links */}
            <nav className="hidden md:flex items-center space-x-6">
              {isAuthenticated && (
                <Link href="/dashboard" className="text-sm font-medium hover:text-primary transition-colors">
                  Dashboard
                </Link>
              )}
              <Link href="/features" className="text-sm font-medium hover:text-primary transition-colors">
                All Features
              </Link>
              <Link href="/contact" className="text-sm font-medium hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            
            <Button asChild size="default" className="rounded-full">
              <Link href="/contact">Get started</Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}

