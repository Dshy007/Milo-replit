import { ArrowLeftRight } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";

export interface ImportedBlock {
  id: number;
  blockId: string;
  driverName: string | null;
  startDate: string;
  startTime: string;
  endDate: string | null;
  endTime: string | null;
  contractType: string;
  duration: string | null;
  payRate: string | null;
  origin: string | null;
  destination: string | null;
  equipmentType: string | null;
  assignedDriverId: number | null;
  truckFilter: string | null;
}

export interface Driver {
  id: number;
  name: string;
}

interface BlocksTableViewProps {
  blocks: ImportedBlock[];
  drivers: Driver[];
  onAssignDriver: (blockId: number, driverId: number) => void;
}

export default function BlocksTableView({
  blocks,
  drivers,
  onAssignDriver,
}: BlocksTableViewProps) {
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };
  
  const sortedBlocks = [...blocks].sort((a, b) => {
    if (!sortColumn) return 0;
    
    const multiplier = sortDirection === 'asc' ? 1 : -1;
    
    switch (sortColumn) {
      case 'blockId':
        return multiplier * a.blockId.localeCompare(b.blockId);
      case 'startsIn': {
        const aStart = new Date(`${a.startDate}T${a.startTime}`).getTime();
        const bStart = new Date(`${b.startDate}T${b.startTime}`).getTime();
        return multiplier * (aStart - bStart);
      }
      case 'origin':
        return multiplier * (a.origin || '').localeCompare(b.origin || '');
      case 'destination':
        return multiplier * (a.destination || '').localeCompare(b.destination || '');
      case 'type':
        return multiplier * a.contractType.localeCompare(b.contractType);
      case 'equipment':
        return multiplier * (a.equipmentType || '').localeCompare(b.equipmentType || '');
      case 'driver': {
        const aDriver = drivers.find(d => d.id === a.assignedDriverId);
        const bDriver = drivers.find(d => d.id === b.assignedDriverId);
        return multiplier * (aDriver?.name || '').localeCompare(bDriver?.name || '');
      }
      default:
        return 0;
    }
  });
  const calculateStartsIn = (dateStr: string, timeStr: string) => {
    const blockStart = new Date(`${dateStr}T${timeStr}`);
    const now = new Date();
    const diffMs = blockStart.getTime() - now.getTime();
    
    if (diffMs < 0) return "Started";
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };

  const formatDateTime = (dateStr: string, timeStr: string) => {
    try {
      const date = new Date(`${dateStr}T${timeStr}`);
      if (isNaN(date.getTime())) {
        return `${dateStr}, ${timeStr}`;
      }
      
      const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      
      const dayName = dayNames[date.getDay()];
      const monthName = monthNames[date.getMonth()];
      const day = date.getDate();
      
      // Format time as HH:MM CST
      const hours = timeStr.split(':')[0];
      const minutes = timeStr.split(':')[1];
      
      return `${dayName}, ${monthName} ${day}, ${hours}:${minutes} CST`;
    } catch (e) {
      return `${dateStr}, ${timeStr}`;
    }
  };

  const calculateDuration = (startDate: string, startTime: string, endDate: string | null, endTime: string | null) => {
    if (!endDate || !endTime) return "—";
    
    try {
      const start = new Date(`${startDate}T${startTime}`);
      const end = new Date(`${endDate}T${endTime}`);
      const diffMs = end.getTime() - start.getTime();
      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      
      return `${hours}h`;
    } catch (e) {
      return "—";
    }
  };

  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[140px]">
              <button onClick={() => handleSort('blockId')} className="flex items-center gap-1 hover:text-foreground">
                Block ID
                {sortColumn === 'blockId' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
            <TableHead className="w-[100px]">
              <button onClick={() => handleSort('startsIn')} className="flex items-center gap-1 hover:text-foreground">
                Starts in
                {sortColumn === 'startsIn' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
            <TableHead className="w-[200px]">
              <button onClick={() => handleSort('origin')} className="flex items-center gap-1 hover:text-foreground">
                Origin
                {sortColumn === 'origin' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
            <TableHead className="w-[50px]"></TableHead>
            <TableHead className="w-[200px]">
              <button onClick={() => handleSort('destination')} className="flex items-center gap-1 hover:text-foreground">
                Destination
                {sortColumn === 'destination' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
            <TableHead className="w-[100px]">
              <button onClick={() => handleSort('type')} className="flex items-center gap-1 hover:text-foreground">
                Type
                {sortColumn === 'type' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
            <TableHead className="w-[120px]">
              <button onClick={() => handleSort('equipment')} className="flex items-center gap-1 hover:text-foreground">
                Equipment
                {sortColumn === 'equipment' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
            <TableHead className="w-[100px]">Requirements</TableHead>
            <TableHead className="w-[200px]">
              <button onClick={() => handleSort('driver')} className="flex items-center gap-1 hover:text-foreground">
                Assign Driver
                {sortColumn === 'driver' ? (sortDirection === 'asc' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
              </button>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedBlocks.map((block) => (
            <TableRow key={block.id}>
              {/* Block ID */}
              <TableCell className="font-medium text-blue-600">
                {block.blockId}
              </TableCell>
              
              {/* Starts in */}
              <TableCell className="text-sm text-muted-foreground">
                Starts in<br />
                {calculateStartsIn(block.startDate, block.startTime)}
              </TableCell>
              
              {/* Origin */}
              <TableCell>
                <div className="font-medium">{block.origin || "—"}</div>
                <div className="text-sm text-muted-foreground">
                  {formatDateTime(block.startDate, block.startTime)}
                </div>
              </TableCell>
              
              {/* Arrow */}
              <TableCell className="text-center">
                <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />
              </TableCell>
              
              {/* Destination */}
              <TableCell>
                <div className="font-medium">{block.destination || "—"}</div>
                <div className="text-sm text-muted-foreground">
                  {block.endDate && block.endTime 
                    ? formatDateTime(block.endDate, block.endTime)
                    : "—"}
                </div>
              </TableCell>
              
              {/* Type */}
              <TableCell>
                <div className="font-medium">{block.contractType}▲</div>
                <div className="text-sm text-muted-foreground">
                  {calculateDuration(block.startDate, block.startTime, block.endDate, block.endTime)}
                </div>
              </TableCell>
              
              {/* Equipment */}
              <TableCell className="text-sm">
                {block.equipmentType || "—"}
              </TableCell>
              
              {/* Requirements (CDL only) */}
              <TableCell className="text-sm">
                CDL
              </TableCell>
              
              {/* Assign Driver */}
              <TableCell>
                <div className="flex items-center gap-2">
                  <Select
                    value={block.assignedDriverId?.toString() || ""}
                    onValueChange={(value) => onAssignDriver(block.id, parseInt(value))}
                  >
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Select driver" />
                    </SelectTrigger>
                    <SelectContent>
                      {drivers.map((driver) => (
                        <SelectItem key={driver.id} value={driver.id.toString()}>
                          {driver.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    disabled={!block.assignedDriverId}
                    onClick={() => {
                      // Assignment is handled by the Select onChange
                    }}
                  >
                    Assign
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

