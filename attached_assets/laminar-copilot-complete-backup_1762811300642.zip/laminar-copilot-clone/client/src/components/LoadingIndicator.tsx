interface LoadingIndicatorProps {
  text?: string;
  size?: "sm" | "md" | "lg";
}

export default function LoadingIndicator({ 
  text = "LOADING...", 
  size = "md" 
}: LoadingIndicatorProps) {
  const dotSizes = {
    sm: "w-2 h-2",
    md: "w-3 h-3",
    lg: "w-4 h-4"
  };

  const textSizes = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base"
  };

  const gapSizes = {
    sm: "gap-1.5",
    md: "gap-2",
    lg: "gap-2.5"
  };

  return (
    <div className={`flex items-center ${gapSizes[size]}`}>
      {/* Animated Dots */}
      <div className={`flex items-center ${gapSizes[size]}`}>
        <div 
          className={`${dotSizes[size]} rounded-full bg-purple-600 animate-pulse-dot`}
          style={{ animationDelay: "0s" }}
        />
        <div 
          className={`${dotSizes[size]} rounded-full bg-purple-600 animate-pulse-dot`}
          style={{ animationDelay: "0.2s" }}
        />
        <div 
          className={`${dotSizes[size]} rounded-full bg-purple-600 animate-pulse-dot`}
          style={{ animationDelay: "0.4s" }}
        />
      </div>
      
      {/* Loading Text */}
      <span className={`${textSizes[size]} font-semibold text-purple-700 tracking-wide`}>
        {text}
      </span>
    </div>
  );
}

