import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Send, X, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

/**
 * Global Milo Assistant - Available on Every Page
 * 
 * Features:
 * - Floating button in bottom-right corner
 * - Click to open/close chat panel
 * - Conversation memory persists across pages (stored in component state)
 * - Connected to knowledge base ("open vein")
 * - Full conversation history display
 */
export default function GlobalMiloAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [aiCommand, setAiCommand] = useState("");
  const [conversationHistory, setConversationHistory] = useState<Array<{role: string, content: string}>>([]);
  
  const aiCommandMutation = trpc.ai.processCommand.useMutation();
  
  // Get current context data
  const { data: drivers } = trpc.drivers.list.useQuery();
  const { data: tractors } = trpc.tractors.list.useQuery();
  const { data: schedules } = trpc.schedules.list.useQuery();
  const { data: startTimes } = trpc.tractors.listStartTimes.useQuery();

  const handleAiCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiCommand.trim()) return;

    try {
      const result = await aiCommandMutation.mutateAsync({
        command: aiCommand,
        conversationHistory, // Pass conversation history for context
        context: {
          weekStart: new Date().toISOString(),
          driverCount: drivers?.length || 0,
          driverNames: drivers?.map(d => d.name) || [],
          scheduleSlotCount: schedules?.length || 0,
          startTimeCount: startTimes?.length || 0,
          drivers: drivers || [],
          tractors: tractors || [],
          schedules: schedules || [],
        },
      });
      
      // Update conversation history
      setConversationHistory(prev => [
        ...prev,
        { role: 'user', content: aiCommand },
        { role: 'assistant', content: result.response }
      ]);
      
      setAiCommand('');
    } catch (error) {
      console.error('AI command error:', error);
      setConversationHistory(prev => [
        ...prev,
        { role: 'user', content: aiCommand },
        { role: 'assistant', content: "Sorry, I encountered an error. Please try again." }
      ]);
      setAiCommand('');
    }
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-110"
          aria-label="Open Milo Assistant"
        >
          <MessageCircle className="w-8 h-8" />
        </button>
      )}

      {/* Chat Panel */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 h-[600px] flex flex-col bg-white rounded-lg shadow-2xl border-2 border-purple-300">
          {/* Header */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
            <div className="flex items-center gap-3">
              <img 
                src="/milo-logo.png" 
                alt="Milo" 
                className="w-10 h-10"
              />
              <div>
                <h3 className="font-bold text-lg">Milo</h3>
                <p className="text-xs opacity-90">Your AI Scheduling Assistant</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-white/20 rounded-full p-1 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Conversation History */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
            {conversationHistory.length === 0 && (
              <div className="text-center text-slate-500 mt-20">
                <img 
                  src="/milo-logo.png" 
                  alt="Milo" 
                  className="w-20 h-20 mx-auto mb-4 opacity-50"
                />
                <p className="text-sm">Ask me anything about your fleet!</p>
                <p className="text-xs mt-2">I know everything from your conversations with Manus.</p>
              </div>
            )}
            
            {conversationHistory.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-lg ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white border border-purple-200'
                }`}>
                  <p className={`text-xs font-semibold mb-1 ${
                    msg.role === 'user' ? 'text-blue-100' : 'text-purple-700'
                  }`}>
                    {msg.role === 'user' ? 'You' : 'Milo'}
                  </p>
                  <p className={`text-sm whitespace-pre-wrap ${
                    msg.role === 'user' ? 'text-white' : 'text-slate-700'
                  }`}>
                    {msg.content}
                  </p>
                </div>
              </div>
            ))}
            
            {aiCommandMutation.isPending && (
              <div className="flex justify-start">
                <div className="bg-white border border-purple-200 p-3 rounded-lg">
                  <p className="text-xs font-semibold text-purple-700 mb-1">Milo</p>
                  <p className="text-sm text-slate-500 animate-pulse">Thinking...</p>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-slate-200 bg-white rounded-b-lg">
            {conversationHistory.length > 0 && (
              <button
                onClick={() => setConversationHistory([])}
                className="text-xs text-slate-500 hover:text-slate-700 underline mb-2"
              >
                Clear conversation
              </button>
            )}
            <form onSubmit={handleAiCommand} className="flex gap-2">
              <input
                type="text"
                value={aiCommand}
                onChange={(e) => setAiCommand(e.target.value)}
                placeholder="Ask Milo anything..."
                className="flex-1 px-3 py-2 rounded-lg border border-slate-300 focus:border-purple-500 focus:outline-none text-sm"
                disabled={aiCommandMutation.isPending}
              />
              <button
                type="submit"
                disabled={aiCommandMutation.isPending || !aiCommand.trim()}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

