import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import LoadingIndicator from "@/components/LoadingIndicator";

export default function AutoSchedulePanel() {
  const [maxDaysPerDriver, setMaxDaysPerDriver] = useState(4);
  const [maxWeeklyHours, setMaxWeeklyHours] = useState(56); // 4 days × 14 hours
  const [respectPreferences, setRespectPreferences] = useState(true);
  const [balanceSolo2, setBalanceSolo2] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  // Mock warnings/violations (will be replaced with real data later)
  const warnings = [
    "John Doe: Scheduled 5 days (prefers 4 days)",
    "Sarah Smith: No preferred start time set"
  ];
  const violations: string[] = [];
  const unassignedBlocks = 0;

  const handleGenerate = () => {
    // TODO: Connect to auto-scheduler API
    setIsGenerating(true);
    console.log("Generate schedule with:", {
      maxDaysPerDriver,
      maxWeeklyHours,
      respectPreferences,
      balanceSolo2
    });
    // Simulate API call
    setTimeout(() => {
      setIsGenerating(false);
    }, 3000);
  };

  const handleClear = () => {
    setMaxDaysPerDriver(4);
    setMaxWeeklyHours(56);
    setRespectPreferences(true);
    setBalanceSolo2(true);
  };

  // Determine hour color based on value
  const getHourColor = () => {
    if (maxWeeklyHours >= 84) return "text-red-600 bg-red-100";
    if (maxWeeklyHours >= 70) return "text-yellow-600 bg-yellow-100";
    return "text-purple-700 bg-purple-100";
  };

  const getSliderColor = () => {
    if (maxWeeklyHours >= 84) return "bg-red-300";
    if (maxWeeklyHours >= 70) return "bg-yellow-300";
    return "bg-blue-200";
  };

  return (
    <div className="space-y-3">
      {/* Main Configuration Card - Compact */}
      <Card className="bg-gradient-to-br from-purple-50/50 via-blue-50/50 to-indigo-50/50 border-purple-200/50 shadow-md">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <CardTitle className="text-base text-purple-900">Auto-Schedule</CardTitle>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleGenerate}
                size="sm"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-sm h-8 text-xs"
              >
                <Sparkles className="w-3 h-3 mr-1" />
                Generate
              </Button>
              <Button
                onClick={handleClear}
                size="sm"
                variant="outline"
                className="border-purple-300 text-purple-700 hover:bg-purple-50 h-8 text-xs"
              >
                Clear
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Max Days Per Driver Slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-purple-900">
                  Max days per driver
                </label>
                <span className="text-sm font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
                  {maxDaysPerDriver}
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="6"
                step="1"
                value={maxDaysPerDriver}
                onChange={(e) => {
                  const days = parseInt(e.target.value);
                  setMaxDaysPerDriver(days);
                  setMaxWeeklyHours(days * 14); // Auto-adjust hours (14 hours per day)
                }}
                className="w-full h-1.5 bg-purple-200 rounded-lg appearance-none cursor-pointer slider-purple"
              />
              <div className="flex justify-between px-0.5">
                {[1, 2, 3, 4, 5, 6].map((day) => (
                  <span
                    key={day}
                    className={`text-[10px] font-medium ${
                      maxDaysPerDriver === day
                        ? "text-purple-700"
                        : "text-purple-400"
                    }`}
                  >
                    {day}
                  </span>
                ))}
              </div>
            </div>

            {/* Max Weekly Hours Slider with Color Warnings */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-purple-900">
                  Max weekly hours
                </label>
                <span className={`text-sm font-bold px-2 py-0.5 rounded-full ${getHourColor()}`}>
                  {maxWeeklyHours}h
                </span>
              </div>
              <input
                type="range"
                min="14"
                max="84"
                step="14"
                value={maxWeeklyHours}
                onChange={(e) => setMaxWeeklyHours(parseInt(e.target.value))}
                className={`w-full h-1.5 ${getSliderColor()} rounded-lg appearance-none cursor-pointer slider-dynamic`}
              />
              <div className="flex justify-between px-0.5">
                {[14, 28, 42, 56, 70, 84].map((hours) => (
                  <span
                    key={hours}
                    className={`text-[10px] font-medium ${
                      maxWeeklyHours === hours
                        ? hours >= 84 ? "text-red-700" : hours >= 70 ? "text-yellow-700" : "text-blue-700"
                        : hours >= 84 ? "text-red-400" : hours >= 70 ? "text-yellow-400" : "text-blue-400"
                    }`}
                  >
                    {hours}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Toggle Switches - Compact */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div className="flex items-center justify-between p-2 bg-white/60 backdrop-blur-sm rounded-md border border-purple-200/50 shadow-sm">
              <label className="text-xs font-medium text-purple-900">
                Respect driver preferences
              </label>
              <button
                onClick={() => setRespectPreferences(!respectPreferences)}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                  respectPreferences ? "bg-purple-600" : "bg-gray-300"
                }`}
              >
                <span
                  className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform shadow-sm ${
                    respectPreferences ? "translate-x-5" : "translate-x-1"
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-2 bg-white/60 backdrop-blur-sm rounded-md border border-purple-200/50 shadow-sm">
              <label className="text-xs font-medium text-purple-900">
                Balance Solo2 load
              </label>
              <button
                onClick={() => setBalanceSolo2(!balanceSolo2)}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                  balanceSolo2 ? "bg-blue-600" : "bg-gray-300"
                }`}
              >
                <span
                  className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform shadow-sm ${
                    balanceSolo2 ? "translate-x-5" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </div>

          {isGenerating ? (
            <div className="flex justify-center py-2">
              <LoadingIndicator text="GENERATING SCHEDULE..." size="sm" />
            </div>
          ) : (
            <p className="text-[10px] text-purple-600 text-center italic">
              Creates a draft proposal. Nothing is published until you confirm.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Status Cards - Compact */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Warnings */}
        <Card className={`border ${warnings.length > 0 ? "border-yellow-300 bg-yellow-50/80" : "border-green-300 bg-green-50/80"} shadow-sm`}>
          <CardHeader className="pb-2 pt-3">
            <div className="flex items-center gap-1.5">
              {warnings.length > 0 ? (
                <AlertCircle className="w-4 h-4 text-yellow-600" />
              ) : (
                <CheckCircle className="w-4 h-4 text-green-600" />
              )}
              <CardTitle className="text-xs font-semibold">Warnings</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            {warnings.length > 0 ? (
              <ul className="space-y-0.5">
                {warnings.map((warning, i) => (
                  <li key={i} className="text-[10px] text-yellow-800">
                    • {warning}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-[10px] text-green-700">No warnings</p>
            )}
          </CardContent>
        </Card>

        {/* Violations */}
        <Card className={`border ${violations.length > 0 ? "border-red-300 bg-red-50/80" : "border-green-300 bg-green-50/80"} shadow-sm`}>
          <CardHeader className="pb-2 pt-3">
            <div className="flex items-center gap-1.5">
              {violations.length > 0 ? (
                <XCircle className="w-4 h-4 text-red-600" />
              ) : (
                <CheckCircle className="w-4 h-4 text-green-600" />
              )}
              <CardTitle className="text-xs font-semibold">Violations</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            {violations.length > 0 ? (
              <ul className="space-y-0.5">
                {violations.map((violation, i) => (
                  <li key={i} className="text-[10px] text-red-800">
                    • {violation}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-[10px] text-green-700">No violations</p>
            )}
          </CardContent>
        </Card>

        {/* Unassigned Blocks */}
        <Card className={`border ${unassignedBlocks > 0 ? "border-orange-300 bg-orange-50/80" : "border-green-300 bg-green-50/80"} shadow-sm`}>
          <CardHeader className="pb-2 pt-3">
            <div className="flex items-center gap-1.5">
              {unassignedBlocks > 0 ? (
                <AlertCircle className="w-4 h-4 text-orange-600" />
              ) : (
                <CheckCircle className="w-4 h-4 text-green-600" />
              )}
              <CardTitle className="text-xs font-semibold">Unassigned Blocks</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pb-3">
            {unassignedBlocks > 0 ? (
              <p className="text-[10px] text-orange-800">
                {unassignedBlocks} blocks need assignment
              </p>
            ) : (
              <p className="text-[10px] text-green-700">All covered</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

