# Deployment & Setup Guide for Replit

This guide provides step-by-step instructions for deploying the Driver Flo / Milo application on Replit.

## **Prerequisites**

Before you begin, ensure you have:

- A Replit account
- An OpenAI API key (for Milo AI)
- Access to a MySQL database (Replit provides this)

## **Step 1: Create a New Replit Project**

1. Go to [Replit](https://replit.com) and create a new Repl.
2. Choose the **"Node.js"** template.
3. Name your project (e.g., "driver-flo-milo").

## **Step 2: Upload the Project Files**

You have two options:

**Option A: Upload from GitHub**
1. If you have the project in a GitHub repository, you can import it directly into Replit.
2. Click "Import from GitHub" and paste your repository URL.

**Option B: Manual Upload**
1. Upload all the files from the `laminar-copilot-clone` directory to your Replit.
2. Ensure the directory structure matches the one outlined in `PROJECT_STRUCTURE.md`.

## **Step 3: Install Dependencies**

1. Open the Replit shell.
2. Run the following command:

```bash
pnpm install
```

This will install all the required Node.js packages.

## **Step 4: Set Up the Database**

1. In Replit, go to the "Database" tab and create a new MySQL database.
2. Copy the connection string (it will look like `mysql://user:pass@host:port/db`).
3. Create a `.env` file in the root of your project (if it doesn't exist).
4. Add the following line to your `.env` file:

```
DATABASE_URL=mysql://user:pass@host:port/db
```

Replace `mysql://user:pass@host:port/db` with your actual connection string.

## **Step 5: Run Database Migrations**

1. In the Replit shell, run:

```bash
pnpm db:push
```

This will create all the necessary tables in your database.

## **Step 6: Configure Environment Variables**

Add the following variables to your `.env` file:

```
VITE_APP_ID=proj_milo_test
VITE_OAUTH_PORTAL_URL=https://vida.butterfly-effect.dev
VITE_APP_TITLE="Milo - Driver Scheduling"
VITE_APP_LOGO="https://placehold.co/40x40/3b82f6/ffffff?text=M"
OAUTH_SERVER_URL=https://vidabiz.butterfly-effect.dev
DATABASE_URL=mysql://user:pass@host:port/db
JWT_SECRET=your-super-secret-jwt-key-change-this
BUILT_IN_FORGE_API_KEY=your-openai-api-key-here
BUILT_IN_FORGE_API_URL=https://api.openai.com/v1
PORT=3000
```

**Important:**
- Replace `your-openai-api-key-here` with your actual OpenAI API key.
- Replace `your-super-secret-jwt-key-change-this` with a strong, random string.

## **Step 7: Seed the Database (Optional)**

If you have historical data (like the `october(1).xlsx` file), you can import it into the database:

1. Create a script to parse the Excel file and insert data into the `drivers`, `tractors`, and `schedules` tables.
2. Run the script to populate your database.

## **Step 8: Start the Application**

1. In the Replit shell, run:

```bash
pnpm dev
```

2. The application will start on port 3000 (or the port specified in your `.env` file).
3. Open the webview to see your application running.

## **Step 9: Test Milo AI**

1. Navigate to the Dashboard.
2. Type a command in the Milo search bar (e.g., "hello" or "how many drivers do I have?").
3. Milo should respond with an intelligent answer.

## **Troubleshooting**

- **Database Connection Error:** Ensure your `DATABASE_URL` is correct and that the MySQL database is running.
- **OpenAI API Error:** Verify that your `BUILT_IN_FORGE_API_KEY` is valid and that you have sufficient API credits.
- **Python Script Not Found:** Ensure the `server/prediction/` directory and all Python files are uploaded correctly.

## **Next Steps**

- Customize the UI to match your branding.
- Add more data to the database.
- Enhance Milo's knowledge base with additional business rules.
- Deploy to production when ready.

This guide should get you up and running on Replit. If you encounter any issues, refer to the other documentation files in this handoff package.
