# Replit Handoff: Driver Flo / Milo AI Scheduling Assistant

**Objective:** Continue development of the Driver Flo / Milo AI Scheduling Assistant on Replit. This document provides the full context, technical stack, architecture, and instructions to get started.

## **1. Project Overview**

Driver Flo is a full-stack web application designed for AFP trucking to manage driver schedules, fleet operations, and predictive forecasting. It features a conversational AI assistant named Milo that can understand natural language commands, access live database information, and make intelligent scheduling decisions.

**Live Demo (from previous session):** https://3008-ihgl9q9y1vkck0ovas5e4-705182db.manus.computer

## **2. Core Features**

- **Driver & Fleet Management:** CRUD operations for drivers and tractors.
- **Weekly Scheduling:** A visual calendar for assigning drivers to blocks.
- **Predictive Forecasting:** An ML model that predicts future block availability.
- **Milo AI Assistant:** A conversational AI that can:
    - Answer questions about drivers, schedules, and predictions.
    - Make real-time schedule adjustments.
    - Understand complex, multi-step commands.
    - Learn from user preferences and historical data.

## **3. Full Technical Stack**

- **Frontend:** React 19, TypeScript, tRPC, Tailwind CSS
- **Backend:** Node.js 22, TypeScript, tRPC
- **Database:** MySQL (Drizzle ORM)
- **AI/LLM:** OpenAI GPT-4.1-mini
- **ML/Python:** Python 3.11, Pandas, Scikit-learn

## **4. Getting Started on Replit**

### **Step 1: Set up the Environment**

1.  **Create a new Replit:** Use the "Node.js" template.
2.  **Upload the code:** Upload the entire `laminar-copilot-clone` directory to your Replit.
3.  **Install dependencies:** Open the shell and run `pnpm install`.

### **Step 2: Configure Environment Variables**

Create a `.env` file in the root of your project with the following variables:

```
VITE_APP_ID=proj_milo_test
VITE_OAUTH_PORTAL_URL=https://vida.butterfly-effect.dev
VITE_APP_TITLE="Milo - Driver Scheduling"
VITE_APP_LOGO="https://placehold.co/40x40/3b82f6/ffffff?text=M"
OAUTH_SERVER_URL=https://vidabiz.butterfly-effect.dev
# DATABASE_URL=mysql://user:pass@host:port/db  <-- IMPORTANT: Use Replit's MySQL database
JWT_SECRET=your-super-secret-jwt-key
BUILT_IN_FORGE_API_KEY=your-openai-api-key
BUILT_IN_FORGE_API_URL=https://api.openai.com/v1
PORT=3000
```

**IMPORTANT:**
- You will need to set up a **MySQL database** in Replit and update the `DATABASE_URL`.
- You will need your own **OpenAI API key** for `BUILT_IN_FORGE_API_KEY`.

### **Step 3: Run the Application**

1.  **Start the server:** Open the shell and run `pnpm dev`.
2.  **View the application:** Open the webview in a new tab.

## **5. Key Files & Directories**

- `laminar-copilot-clone/`: The root directory of the project.
- `server/ai-scheduler.ts`: The core logic for the Milo AI assistant.
- `server/db.ts`: All database functions and Drizzle ORM setup.
- `server/routers/milo.ts`: tRPC router for Milo-related functions.
- `server/routers/predictions.ts`: tRPC router for the prediction engine.
- `server/prediction/`: The Python ML prediction engine.
- `drizzle/`: Database schema and migration files.
- `client/`: The React frontend application.

## **6. Next Steps & Future Development**

- **Database Seeding:** You will need to populate the database with initial data (drivers, tractors, etc.). You can use the `october(1).xlsx` file as a starting point.
- **Enhance Milo:** Continue to build out Milo's knowledge base and add more complex function calling capabilities.
- **Improve Predictions:** Refine the ML model with more data and advanced algorithms.
- **UI/UX Refinements:** Continuously improve the user interface and experience.

This prompt provides a comprehensive starting point for continuing the development of the Driver Flo / Milo application on Replit. All the necessary code, architecture, and documentation are included.
