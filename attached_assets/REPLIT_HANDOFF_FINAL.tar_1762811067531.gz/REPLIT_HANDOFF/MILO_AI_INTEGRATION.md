# Milo AI Integration & Architecture

This document details the implementation of the Milo AI assistant, including the AI scheduler, function calling system, vector database, and ML prediction engine integration.

## **1. Core AI Architecture**

Milo's intelligence is orchestrated by the **AI Scheduler** (`server/ai-scheduler.ts`). This file is the "brain" that processes user commands and decides which actions to take.

**How it Works:**
1.  **User Input:** A user types a command (e.g., "how many drivers do I have?") into the Milo search bar.
2.  **tRPC Call:** The frontend calls the `trpc.ai.processCommand` endpoint.
3.  **AI Scheduler:** The `ai-scheduler.ts` receives the command.
4.  **LLM Invocation:** It sends the command, conversation history, and a list of available "tools" (functions) to the OpenAI GPT-4.1-mini model.
5.  **Function Call Decision:** The LLM decides which function to call (e.g., `get_all_drivers()`).
6.  **Execution:** The `executeFunctionCall` method in `ai-scheduler.ts` runs the corresponding database function from `server/db.ts`.
7.  **Response:** The result is returned to the LLM, which then formulates a natural language response for the user.

## **2. Function Calling System**

Milo can interact with the database and other system components through a set of predefined functions (tools). These are defined in the `tools` array within `ai-scheduler.ts`.

**Available Functions:**

| Function Name                 | Description                                               |
| ----------------------------- | --------------------------------------------------------- |
| `get_all_drivers`             | Get a list of all drivers.                                |
| `get_all_tractors`            | Get a list of all tractors.                               |
| `get_all_schedules`           | Get all schedule assignments.                             |
| `get_all_start_times`         | Get all available contract start times.                   |
| `get_predictions`             | Retrieve ML predictions for a specific week.              |
| `generate_predictions`        | Generate new ML predictions for a specific week.          |
| `search_knowledge`            | Perform a semantic search on the vector database.         |
| `create_driver`               | Add a new driver to the database.                         |
| `update_driver`               | Update an existing driver's information.                  |
| `delete_driver`               | Remove a driver from the database.                        |
| `create_schedule_assignment`  | Assign a driver to a schedule.                            |

## **3. Vector Database (Semantic Search)**

Milo uses a vector database to enable semantic search and long-term memory. This is handled by the `embedding-service.ts`.

**How it Works:**
1.  **Indexing:** When new data is added (e.g., a driver, a schedule, or a document), it is converted into a numerical representation (an embedding) and stored in the `embeddings` table.
2.  **Searching:** When a user asks a question like "who are my best drivers?", the `search_knowledge` function is called.
3.  **Similarity Search:** The user's query is converted into an embedding, and the database is searched for the most similar (semantically related) embeddings.
4.  **Contextual Response:** The search results are passed to the LLM as context, allowing it to provide more accurate and relevant answers.

## **4. ML Prediction Engine Integration**

The `generate_predictions` function provides the bridge between the Node.js backend and the Python ML engine.

**Data Flow:**
1.  **Milo Command:** User asks, "Milo, predict week 49".
2.  **Function Call:** The AI scheduler calls `generate_predictions(49)`.
3.  **tRPC Router (`routers/milo.ts`):** The `generate` procedure is invoked.
4.  **Child Process:** The router spawns a Python child process:
    ```bash
    python3.11 server/prediction/scripts/predict_week.py 49
    ```
5.  **Python Script (`predict_week.py`):**
    - Reads historical data.
    - Calculates prediction probabilities.
    - Writes the results to a CSV file.
6.  **Data Import:** The Node.js backend reads the generated CSV file and inserts the predictions into the `predictions` database table.
7.  **Response:** Milo confirms that the predictions have been generated and are ready to view.

This architecture allows for a powerful, flexible, and scalable AI assistant that can leverage the strengths of both Node.js (for the web backend) and Python (for machine learning).
