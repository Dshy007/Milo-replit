# Driver Flo / Milo - Technical Architecture

This document outlines the full technical stack, architecture, and key implementation details for the Driver Flo / Milo application.

## **1. Core Technology Stack**

| Layer       | Technology                               | Description                                                                                                                              |
|-------------|------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| **Frontend**  | React 19, TypeScript, tRPC, Tailwind CSS | A modern, type-safe, and highly responsive user interface.                                                                               |
| **Backend**   | Node.js 22, TypeScript, tRPC             | A robust, high-performance, and type-safe server environment.                                                                            |
| **Database**  | MySQL (via Manus-managed TiDB Cloud)     | A scalable, reliable, and fully-managed relational database.                                                                             |
| **AI/LLM**    | OpenAI GPT-4.1-mini (via Manus Proxy)    | State-of-the-art language model for natural language understanding and command execution.                                                  |
| **ML/Python** | Python 3.11, Pandas, Scikit-learn        | A powerful machine learning engine for predictive scheduling, integrated via child processes.                                            |
| **Deployment**| Manus Web-DB-User Template               | A production-ready, fully-managed infrastructure with built-in authentication, database, and CI/CD.                                       |

## **2. System Architecture**

The application follows a modern, full-stack, type-safe architecture with a clear separation of concerns:

```mermaid
graph TD
    subgraph Frontend (Browser)
        A[React UI Components] --> B{tRPC Client};
    end

    subgraph Backend (Node.js Server)
        B --> C{tRPC Router};
        C --> D[AI Scheduler];
        C --> E[Database Functions];
        C --> F[Prediction Engine];
    end

    subgraph AI/LLM (Manus Proxy)
        D --> G[OpenAI GPT-4.1-mini];
    end

    subgraph Database (TiDB Cloud)
        E --> H[(MySQL Database)];
    end

    subgraph ML Engine (Python)
        F -- spawns --> I[predict_week.py];
        I -- reads --> J[Historical Data];
        I -- writes --> K[Prediction CSV];
        F -- reads --> K;
        F -- writes --> H;
    end
```

### **Key Components:**

- **tRPC Router (`server/routers.ts`):** The central API gateway that connects the frontend to all backend services. It provides end-to-end type safety between the client and server.

- **AI Scheduler (`server/ai-scheduler.ts`):** The "brain" of Milo. It takes natural language commands, uses the LLM to determine intent, and calls the appropriate database or prediction functions.

- **Database Functions (`server/db.ts`):** A collection of type-safe functions for all database operations (CRUD for drivers, tractors, schedules, etc.). It uses the Drizzle ORM for MySQL.

- **Prediction Engine (`server/routers/predictions.ts`):** A tRPC router that spawns the Python prediction script (`predict_week.py`) as a child process, reads the resulting CSV, and saves the predictions to the database.

## **3. Database Schema**

The database schema is defined in `drizzle/schema.ts` and includes the following key tables:

- `users`: Stores user authentication information.
- `drivers`: The main driver roster with contact details, contract type, and status.
- `tractors`: The fleet of vehicles with their type (Solo1, Solo2) and status.
- `schedules`: The weekly schedule assignments for each driver.
- `predictions`: Stores the ML-generated predictions for future weeks.
- `embeddings`: The vector database for Milo AI, storing embeddings of all data for semantic search.

## **4. AI and ML Integration**

- **AI Function Calling:** The AI scheduler uses a system prompt to teach the LLM what functions are available. When a user enters a command, the LLM decides which function to call (e.g., `get_fleet_summary()`, `create_schedule_assignment()`).

- **Python Integration:** The Node.js backend spawns the Python prediction script as a child process. This allows the system to leverage the power of Python for machine learning while maintaining a modern web stack.

- **Vector Database:** The `embedding-service.ts` creates vector embeddings of all your data (drivers, schedules, etc.) and stores them in the `embeddings` table. This enables Milo to perform semantic search and understand the AI to have contextual memory.
