# Replit Handoff: Driver Flo / Milo AI Scheduling Assistant

**Objective:** Continue development of the Driver Flo / Milo AI Scheduling Assistant on Replit, evolving it into a multi-tenant SaaS platform with an AI agent-style user experience.

## **1. Project Vision: The AI Agent-Style SaaS Platform**

The ultimate goal is to create a **multi-tenant SaaS application** where each customer (e.g., a trucking company) has their own isolated database and AI context. The user experience should be centered around Milo, the AI assistant, making it feel like an **AI agent-style website**.

### **Key Architectural Principles:**

- **Multi-Tenancy:** Each customer's data must be stored in a separate, dedicated database to ensure privacy and security.
- **Dynamic Database Connections:** The backend must be able to dynamically connect to the correct customer database based on the authenticated user.
- **AI as the Interface:** Milo should be the primary way users interact with the application. Instead of clicking through complex UI, users should be able to accomplish tasks by giving natural language commands to Milo.
- **Scalability:** The architecture should be designed to scale horizontally to support a growing number of customers.

## **2. Core Features**

- **Driver & Fleet Management:** CRUD operations for drivers and tractors.
- **Weekly Scheduling:** A visual calendar for assigning drivers to blocks.
- **Predictive Forecasting:** An ML model that predicts future block availability.
- **Milo AI Assistant:** A conversational AI that can:
    - Answer questions about drivers, schedules, and predictions.
    - Make real-time schedule adjustments.
    - Understand complex, multi-step commands.
    - Learn from user preferences and historical data.

## **3. Full Technical Stack**

- **Frontend:** React 19, TypeScript, tRPC, Tailwind CSS
- **Backend:** Node.js 22, TypeScript, tRPC
- **Database:** MySQL (Drizzle ORM)
- **AI/LLM:** OpenAI GPT-4.1-mini
- **ML/Python:** Python 3.11, Pandas, Scikit-learn

## **4. Getting Started on Replit**

### **Step 1: Set up the Environment**

1.  **Create a new Replit:** Use the "Node.js" template.
2.  **Upload the code:** Upload the entire `laminar-copilot-clone` directory to your Replit.
3.  **Install dependencies:** Open the shell and run `pnpm install`.

### **Step 2: Configure Environment Variables**

Create a `.env` file in the root of your project with the following variables:

```
VITE_APP_ID=proj_milo_test
VITE_OAUTH_PORTAL_URL=https://vida.butterfly-effect.dev
VITE_APP_TITLE="Milo - Driver Scheduling"
VITE_APP_LOGO="https://placehold.co/40x40/3b82f6/ffffff?text=M"
OAUTH_SERVER_URL=https://vidabiz.butterfly-effect.dev
# DATABASE_URL is now managed dynamically per-tenant
JWT_SECRET=your-super-secret-jwt-key
BUILT_IN_FORGE_API_KEY=your-openai-api-key
BUILT_IN_FORGE_API_URL=https://api.openai.com/v1
PORT=3000
```

**IMPORTANT:**
- You will need your own **OpenAI API key** for `BUILT_IN_FORGE_API_KEY`.
- The `DATABASE_URL` will be handled dynamically. You'll need a way to manage connection strings for each tenant.

### **Step 3: Run the Application**

1.  **Start the server:** Open the shell and run `pnpm dev`.
2.  **View the application:** Open the webview in a new tab.

## **5. Key Files & Directories**

- `server/ai-scheduler.ts`: The core logic for the Milo AI assistant.
- `server/db.ts`: **NEEDS MODIFICATION** for multi-tenant database connections.
- `server/routers/milo.ts`: tRPC router for Milo-related functions.
- `server/prediction/`: The Python ML prediction engine.
- `drizzle/`: Database schema (will be applied to each tenant database).

## **6. Next Steps & Future Development**

### **Immediate Priority: Multi-Tenant Architecture**

1.  **Database Connection Management:**
    - Create a new database table to store tenant information (e.g., `tenants` table with `id`, `name`, `db_connection_string`).
    - Modify `server/db.ts` to dynamically select the correct database connection string based on the authenticated user's tenant ID.

2.  **User Authentication & Tenant Association:**
    - When a new user signs up, associate them with a tenant (or create a new tenant).
    - Include the `tenantId` in the user's JWT or session data.

3.  **AI Context per Tenant:**
    - Ensure that Milo's conversations and knowledge are scoped to the current tenant. The vector database will need to be partitioned by `tenantId`.

### **Long-Term Vision: The AI Agent Website**

- **Milo as the Primary Interface:** Gradually phase out traditional UI elements (forms, buttons) and replace them with conversational commands to Milo.
- **Proactive Assistance:** Develop capabilities for Milo to proactively identify scheduling conflicts, suggest optimizations, and alert users to potential issues.
- **Personalized Experience:** Allow Milo to learn the preferences and operational patterns of each individual user and tenant.

This prompt provides a comprehensive starting point for evolving the Driver Flo / Milo application into a sophisticated, AI-first SaaS platform on Replit.
