# Driver Flo / Milo - Complete Project Structure

This document outlines the complete file structure and key code implementations for the Driver Flo / Milo application.

## **Directory Structure**

```
laminar-copilot-clone/
├── client/                          # React frontend
│   ├── src/
│   │   ├── components/
│   │   │   ├── DashboardLayout.tsx  # Main layout with navigation
│   │   │   ├── GlobalMiloAssistant.tsx  # Floating AI chat button
│   │   │   └── PredictionsView.tsx  # Predictions calendar component
│   │   ├── pages/
│   │   │   ├── Dashboard.tsx        # Main dashboard with Milo search
│   │   │   ├── Drivers.tsx          # Driver management page
│   │   │   ├── Schedules.tsx        # Weekly schedule page
│   │   │   └── Predictions.tsx      # Predictions page
│   │   ├── App.tsx                  # Main app with routing
│   │   └── main.tsx                 # Entry point
│   └── package.json
├── server/                          # Node.js backend
│   ├── _core/
│   │   ├── index.ts                 # Server entry point
│   │   ├── trpc.ts                  # tRPC setup
│   │   ├── llm.ts                   # LLM integration
│   │   └── env.ts                   # Environment variables
│   ├── routers/
│   │   ├── milo.ts                  # Milo AI functions (predictions, search)
│   │   └── predictions.ts           # Prediction engine router
│   ├── lib/
│   │   └── embedding-service.ts     # Vector database service
│   ├── prediction/                  # Python ML engine
│   │   ├── scripts/
│   │   │   └── predict_week.py      # Main prediction script
│   │   ├── config/
│   │   │   └── contract_mapping.py  # Truck configuration
│   │   └── data/
│   │       ├── raw/                 # Historical data (CSV)
│   │       └── processed/           # Generated predictions
│   ├── ai-scheduler.ts              # Milo AI brain (function calling)
│   ├── db.ts                        # Database functions (Drizzle ORM)
│   └── routers.ts                   # Main tRPC router
├── drizzle/                         # Database schema & migrations
│   ├── schema.ts                    # All table definitions
│   └── 0005_add_predictions.sql     # Predictions table migration
├── .env                             # Environment variables
├── package.json                     # Dependencies
└── tsconfig.json                    # TypeScript configuration
```

## **Key Files & Their Purpose**

### **Frontend (`client/`)**

- **`Dashboard.tsx`:** The main landing page with the Milo AI search bar. Users can type natural language commands here.
- **`PredictionsView.tsx`:** A calendar grid component that displays ML-generated predictions with confidence scores.
- **`GlobalMiloAssistant.tsx`:** A floating purple button that opens a chat interface for Milo AI (alternative to the search bar).

### **Backend (`server/`)**

- **`ai-scheduler.ts`:** The core logic for Milo AI. It contains:
    - System prompt with all business rules and knowledge.
    - Function definitions (tools) that the LLM can call.
    - `executeFunctionCall()` which maps LLM function calls to actual database operations.
- **`db.ts`:** All database CRUD operations using Drizzle ORM.
- **`routers/milo.ts`:** tRPC router for Milo-specific functions (generate predictions, search embeddings).
- **`routers/predictions.ts`:** tRPC router that spawns the Python prediction script.

### **ML Engine (`server/prediction/`)**

- **`predict_week.py`:** The Python script that:
    1. Reads historical data from CSV files.
    2. Analyzes patterns (day of week, start time, truck type).
    3. Calculates probabilities for future blocks.
    4. Outputs predictions to a CSV file.

### **Database (`drizzle/`)**

- **`schema.ts`:** Defines all database tables using Drizzle ORM:
    - `users`, `drivers`, `tractors`, `schedules`, `predictions`, `embeddings`, etc.

## **Data Flow Example: "Predict Week 48"**

1. **User types:** "Predict week 48" in the Milo search bar.
2. **Frontend:** Calls `trpc.ai.processCommand.mutate({ command: "Predict week 48" })`.
3. **Backend (ai-scheduler.ts):** 
    - LLM analyzes the command and decides to call `generate_predictions(48)`.
4. **Backend (routers/milo.ts):**
    - Spawns `python3.11 predict_week.py 48` as a child process.
5. **Python Script:**
    - Reads historical data from `server/prediction/data/raw/`.
    - Generates predictions and writes to `server/prediction/data/processed/week_48_predictions.csv`.
6. **Backend (routers/milo.ts):**
    - Reads the CSV file.
    - Parses the data and inserts into the `predictions` table.
7. **Frontend:** Displays the predictions in the calendar view.

This structure ensures a clean separation of concerns, type safety, and scalability.
