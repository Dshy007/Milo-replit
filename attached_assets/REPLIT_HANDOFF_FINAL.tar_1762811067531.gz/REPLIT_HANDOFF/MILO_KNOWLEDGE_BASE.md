# Milo AI - Built-in Knowledge Base

This document outlines the core business rules, operational logic, and user preferences that have been built into Milo AI. This knowledge is embedded in the AI scheduler's system prompt (`server/ai-scheduler.ts`) to ensure intelligent and context-aware responses.

## **1. Core Business Rules**

These are the fundamental rules that govern all scheduling and operational decisions:

- **Work Week:** The standard work week is **Sunday through Saturday**.
- **Hours of Service (HOS):**
    - Drivers require a minimum of **10 hours off** between shifts.
    - Drivers can work a maximum of **5 consecutive days**.
    - After 5 consecutive days, a **34-hour reset** is mandatory.
- **Solo2 Block Rule:** A Solo2 block counts as **2 days of work** for HOS and rolling 6-day pattern calculations.

## **2. Scheduling Logic & Workflow**

Milo follows a specific workflow to ensure compliant and efficient schedules:

- **Foundation:** The previous week's schedule is always used as the baseline for the current week.
- **HOS Double-Check:** Milo works **backward from Saturday** to verify HOS compliance, ensuring the 34-hour reset is correctly placed.
- **HOS Violation Correction:** The preferred method for fixing HOS violations is a **driver swap**, which preserves the original load times and minimizes disruption.

## **3. User Preferences & Expectations**

Milo has been designed to meet the following user expectations:

- **Manus-Level Intelligence:** Milo is expected to have the same level of intelligence, context awareness, and natural language understanding as the Manus AI assistant.
- **Full Data Access:** Milo has maximum access to all database tables and can perform complex queries to answer questions accurately.
- **Conversational & Proactive:** Milo should be conversational, proactive, and able to make intelligent suggestions based on user patterns and preferences.

## **4. ML Model & Predictions**

- **Training Data:** The ML model is trained on historical data and manual pre-planning information provided by the user.
- **Prediction Logic:** The model analyzes patterns in historical data to predict future block availability and driver assignments.

## **5. Key Terminology**

- **Block ID:** The foundational unit of the schedule, associated with a contractual start time.
- **Trip ID:** Contains the actual route and destination for a specific block, assigned by Amazon closer to the block's start time.

By embedding this knowledge directly into Milo's system prompt, the AI can make intelligent, context-aware decisions that align with your business rules and operational workflow.
